#!/usr/bin/python3

import pytz, torch, math, os
from datetime import datetime

import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import trading_agents.el005.nets as nets
import trading_agents.el005.dataloader as dataloader
import matplotlib.pyplot as plt
from .timefeatures import time_features

from coin_wizard.technical_indicators import TechnicalIndicators

utc = pytz.utc

selected_net = 'EL_Diff.net'
# selected_net = 'backup.net'
# selected_net = 'back.net'

verbose = False
cuda_enabled = True
# cuda_enabled = False
learning_rate = 0.0001
learning_rate = learning_rate*0.03752413921
epoch_counts = 512*2 # 6
batch_counts = 512*2
batch_size = 10
# batch_counts = 1
# batch_size = 1
# batch_size = 64
training_batches_update_epochs = 16

input_period = 960
decode_inference_len = 120
decode_predict_len = 240

confidence_threshold = 0.7
macd_threshold = 0.00008
macd_diff_threshold = 0.00001
win_rate_threshold = 0.5
movement_threshold = 0.00125

moving_average = 15

import coin_wizard.plotter as plotter

ti = TechnicalIndicators()

def calc_confusion_matrix(answers, outputs, labels_length):
    answers = answers.tolist()
    outputs = outputs.tolist()
    array = np.zeros((labels_length, labels_length))
    for i, item in enumerate(answers):
        array[item, outputs[i]] += 1

    # print(array)
    # print(np.sum(array, axis=1))
    array = array / np.sum(array, axis=1)[:, None]
    return array

class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        if not os.path.exists(os.path.join(agent_directory, 'figs')):
            os.makedirs(os.path.join(agent_directory, 'figs'))
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 1
        self.net = None
        self.move_avg_list = [None, None]
        self.position = 2
        self.yeh_n = 0
        self.yeh_m = 240
        self.yeh_steps = 0
        self.total_yeh_steps = 0
        self.buy_cd = 0
        self.sell_cd = 0
        self.current_trade = None
        self.best_profit = 0
        self.dragged_long_conf = 0
        self.dragged_short_conf = 0
        self.max_macd_diff_abs = 0
        self.consider_to_close_trade = False

        self.buy_pl = 0
        self.buy_counts = 0
        self.sell_pl = 0
        self.sell_counts = 0

        self.use_buy = 0
        self.use_sell = 0

        self.confidence = 0.99

        self.test_mode = False

    def _order_canceled_listener(self, order, reason):
        self.position = 2
        self.yeh_steps = 0

    def _order_filled_listener(self, order, trade):
        self.current_trade = trade
        trade.onReduced(self._trade_reduced_listener)
        trade.onClosed(self._trade_closed_listener)

    def _trade_reduced_listener(self, trade, units, realized_pl, close_price, spread, timestamp):
        pass

    def _trade_closed_listener(self, trade, realized_pl, close_price, spread, timestamp):
        # print(self.yeh_steps, self.best_profit)
        print('Trade closed after %d yeh steps. Best profit: %.5f. PL:  %.5f. Max abs macd diff:  %.5f.' % (
            self.total_yeh_steps, self.best_profit, realized_pl, self.max_macd_diff_abs))
        self.position = 2
        self.yeh_steps = 0
        self.max_macd_diff_abs = 0
        self.total_yeh_steps = 0
        self.consider_to_close_trade = False
        if trade.getTradeSettings()['units'] > 0:
            self.buy_pl += realized_pl
            if realized_pl < 0:
                self.confidence -= 0.95*(self.confidence)
                self.confidence = max(self.confidence, confidence_threshold*1.05)
                # self.buy_cd = 0
                self.buy_cd = 5
                self.sell_cd = 0
            else:
                self.confidence += 0.1*(1 - self.confidence)
        else:
            self.sell_pl += realized_pl
            if realized_pl < 0:
                self.confidence -= 0.95*(self.confidence)
                self.confidence = max(self.confidence, confidence_threshold*1.05)
                # self.sell_cd = 0
                self.sell_cd = 5
                self.buy_cd = 0
            else:
                self.confidence += 0.1*(1 - self.confidence)

    def _every_15_second_loop(self, BrokerAPI):

        if not self.eurusd_inst.isTradable():
            return
        # raise


        if not self.test_mode or self.every_15_second_loop_count % 4 == 0:
            # print(self.test_mode, self.every_15_second_loop_count)
            if self.buy_cd > 0:
                self.buy_cd -= 1
            if self.sell_cd > 0:
                self.sell_cd -= 1

            usdchf_hist_data = self.usdchf_inst.getRecent1MCandles(input_period+350)
            # usdchf_hist_data['close_usdchf'] = usdchf_hist_data['close']
            usdchf_hist_data['macd_usdchf'] = ti.macd(usdchf_hist_data.close, 12, 26)
            usdchf_hist_data['rsi_usdchf'] = ti.rsi_ema(usdchf_hist_data.close, 10)/50.0 - 1.0
            usdchf_hist_data['momentum_usdchf'] = ti.momentum(usdchf_hist_data.close, 4)
            del usdchf_hist_data['close']
            del usdchf_hist_data['open']
            del usdchf_hist_data['high']
            del usdchf_hist_data['low']

            eurjpy_hist_data = self.eurjpy_inst.getRecent1MCandles(input_period+350)
            # eurjpy_hist_data['close_eurjpy'] = eurjpy_hist_data['close']
            eurjpy_hist_data['macd_eurjpy'] = ti.macd(eurjpy_hist_data.close, 12, 26)
            eurjpy_hist_data['rsi_eurjpy'] = ti.rsi_ema(eurjpy_hist_data.close, 10)/50.0 - 1.0
            eurjpy_hist_data['momentum_eurjpy'] = ti.momentum(eurjpy_hist_data.close, 4)
            del eurjpy_hist_data['close']
            del eurjpy_hist_data['open']
            del eurjpy_hist_data['high']
            del eurjpy_hist_data['low']

            usdjpy_hist_data = self.usdjpy_inst.getRecent1MCandles(input_period+350)
            # usdjpy_hist_data['close_usdjpy'] = usdjpy_hist_data['close']
            usdjpy_hist_data['macd_usdjpy'] = ti.macd(usdjpy_hist_data.close, 12, 26)
            usdjpy_hist_data['rsi_usdjpy'] = ti.rsi_ema(usdjpy_hist_data.close, 10)/50.0 - 1.0
            usdjpy_hist_data['momentum_usdjpy'] = ti.momentum(usdjpy_hist_data.close, 4)
            del usdjpy_hist_data['close']
            del usdjpy_hist_data['open']
            del usdjpy_hist_data['high']
            del usdjpy_hist_data['low']

            gbpusd_hist_data = self.gbpusd_inst.getRecent1MCandles(input_period+350)
            # gbpusd_hist_data['close_gbpusd'] = gbpusd_hist_data['close']
            gbpusd_hist_data['macd_gbpusd'] = ti.macd(gbpusd_hist_data.close, 12, 26)
            gbpusd_hist_data['rsi_gbpusd'] = ti.rsi_ema(gbpusd_hist_data.close, 10)/50.0 - 1.0
            gbpusd_hist_data['momentum_gbpusd'] = ti.momentum(gbpusd_hist_data.close, 4)
            del gbpusd_hist_data['close']
            del gbpusd_hist_data['open']
            del gbpusd_hist_data['high']
            del gbpusd_hist_data['low']

            xauusd_hist_data = self.xauusd_inst.getRecent1MCandles(input_period+350)
            # xauusd_hist_data['close_xauusd'] = xauusd_hist_data['close']
            xauusd_hist_data['macd_xauusd'] = ti.macd(xauusd_hist_data.close, 12, 26)
            xauusd_hist_data['rsi_xauusd'] = ti.rsi_ema(xauusd_hist_data.close, 10)/50.0 - 1.0
            xauusd_hist_data['momentum_xauusd'] = ti.momentum(xauusd_hist_data.close, 4)
            del xauusd_hist_data['close']
            del xauusd_hist_data['open']
            del xauusd_hist_data['high']
            del xauusd_hist_data['low']

            eurusd_hist_data = self.eurusd_inst.getRecent1MCandles(input_period+350)
            eurusd_hist_data['ma'] = ti.ma(eurusd_hist_data.close, 30)
            eurusd_hist_data['macd'] = ti.macd(eurusd_hist_data.close, 12, 26)
            eurusd_hist_data['macd_diff'] = eurusd_hist_data['macd'] - eurusd_hist_data['macd'].ewm(span=9).mean()
            eurusd_hist_data['roc'] = ti.roc(eurusd_hist_data.close, 2)
            eurusd_hist_data['momentum'] = ti.momentum(eurusd_hist_data.close, 4)
            eurusd_hist_data['rsi'] = ti.rsi_ema(eurusd_hist_data.close, 10)/50.0 - 1.0
            eurusd_hist_data['bb_upper'], eurusd_hist_data['bb_lower'] = ti.bb(eurusd_hist_data.close, 30, 2)
            eurusd_hist_data['cci'] = ti.cci(eurusd_hist_data.high, eurusd_hist_data.low, eurusd_hist_data.close, 20)
            del eurusd_hist_data['open']
            del eurusd_hist_data['high']
            del eurusd_hist_data['low']

            self.first_valid_idex = 26

            hist_data = eurusd_hist_data.merge(usdchf_hist_data, how='inner', on='timestamp')
            hist_data = hist_data.merge(eurjpy_hist_data, how='inner', on='timestamp')
            hist_data = hist_data.merge(usdjpy_hist_data, how='inner', on='timestamp')
            hist_data = hist_data.merge(gbpusd_hist_data, how='inner', on='timestamp')
            hist_data = hist_data.merge(xauusd_hist_data, how='inner', on='timestamp')
            macd = eurusd_hist_data['macd']
            input = np.array([
                hist_data.close.to_list(),
                hist_data.ma.to_list(),
                hist_data.macd.to_list(),
                hist_data.roc.to_list(),
                hist_data.momentum.to_list(),
                hist_data.rsi.to_list(),
                hist_data.bb_upper.to_list(),
                hist_data.bb_lower.to_list(),
                hist_data.cci.to_list(),
                hist_data.macd_usdchf.to_list(),
                hist_data.rsi_usdchf.to_list(),
                hist_data.momentum_usdchf.to_list(),
                hist_data.macd_eurjpy.to_list(),
                hist_data.rsi_eurjpy.to_list(),
                hist_data.momentum_eurjpy.to_list(),
                hist_data.macd_usdjpy.to_list(),
                hist_data.rsi_usdjpy.to_list(),
                hist_data.momentum_usdjpy.to_list(),
                hist_data.macd_gbpusd.to_list(),
                hist_data.rsi_gbpusd.to_list(),
                hist_data.momentum_gbpusd.to_list(),
                hist_data.macd_xauusd.to_list(),
                hist_data.rsi_xauusd.to_list(),
                hist_data.momentum_xauusd.to_list(),
            ], dtype=np.float32)

            input = np.swapaxes(input, 0, 1)
            input = self.data_scaler.transform(input)
            times = time_features(hist_data['timestamp'], freq='t')
            # print(input)
            # input = input[-721:, :]
            encode_inputs_list = []
            encode_times_list = []
            decode_inputs_list = []
            decode_times_list = []

            for i in range(moving_average):
                encode_inputs = (input[-(input_period+(i)):, :])[:input_period, :]
                encode_times = (times[-(input_period+(i)):, :])[:input_period, :]
                # print(encode_inputs.shape)
                decode_inputs = np.zeros((decode_inference_len+decode_predict_len, 24), dtype=float)
                decode_inputs[:decode_inference_len, :] = input[-decode_inference_len:, :]
                decode_times = time_features(pd.date_range(start=eurusd_hist_data['timestamp'].tail(1).iloc[0], periods=decode_predict_len, freq='T'), freq='t')
                decode_times = np.concatenate((times[-decode_inference_len:, :], decode_times))

                encode_inputs_list.append(encode_inputs)
                encode_times_list.append(encode_times)
                decode_inputs_list.append(decode_inputs)
                decode_times_list.append(decode_times)



            encode_inputs = torch.tensor(encode_inputs_list, dtype=torch.float32)
            encode_times = torch.tensor(encode_times_list, dtype=torch.float32)
            decode_inputs = torch.tensor(decode_inputs_list, dtype=torch.float32)
            decode_times = torch.tensor(decode_times_list, dtype=torch.float32)

            if cuda_enabled:
                encode_inputs = encode_inputs.cuda()
                encode_times = encode_times.cuda()
                decode_inputs = decode_inputs.cuda()
                decode_times = decode_times.cuda()

            outputs = self.net(encode_inputs, encode_times, decode_inputs, decode_times)

            del encode_inputs
            del encode_times
            del decode_inputs
            del decode_times

            x = list(range(0, decode_predict_len))
            labels = self.eurusd_inst.foreseeFutureCandles1M(decode_predict_len)
            labels = torch.tensor(labels['close'].tolist())
            labels = labels - eurusd_hist_data['close'].tail(1).iloc[0]
            # print(hist_data['close'].tail(1).iloc[0])
            # print(hist_data.close)
            # print(eurusd_hist_data.close)
            plt.plot(x, labels.tolist(), label='Label')
            # for i in range(moving_average):
            #     plt.plot(x, self.data_scaler.inverse_diff_transform_index(0, outputs[i, :, 0]).tolist(), label='Predict-'+str(i))
            outputs = outputs.sum(0, keepdim=True)/moving_average
            plt.plot(x, self.data_scaler.inverse_diff_transform_index(0, outputs[0, :, 0]).tolist(), label='Predict-'+str(i))
            plt.legend()
            plt.show(block=False)
            # plt.pause(0.25)
            plt.pause(0.001)
            plt.close()


            # output = outputs[-1, 0]
            # long_confidence = output[0].item()*self.use_buy
            # short_confidence = output[1].item()*self.use_sell
            # # short_confidence = 0
            #
            # last_1_macd_diff = eurusd_hist_data['macd_diff'][eurusd_hist_data.index[-1]]
            # last_2_macd_diff = eurusd_hist_data['macd_diff'][eurusd_hist_data.index[-2]]
            # current_macd = macd[macd.index[-1]]
            # long_confidence = output[1].item()
            # short_confidence = output[0].item()
            #
            # self.dragged_long_conf = 0.5 * long_confidence + 0.5 * self.dragged_long_conf
            # self.dragged_short_conf = 0.5 * short_confidence + 0.5 * self.dragged_short_conf
            #
            # self.dragged_long_conf = long_confidence
            # self.dragged_short_conf = short_confidence

            # units = int(0.8 * self.account.getMarginAvailable() / self.account.getMarginRate())

            units = 1000/0.02
            t = self.data_scaler.inverse_diff_transform_index(0, outputs)
            t_max = torch.max(t).item()
            t_min = torch.min(t).item()

            # t_max = 0
            # t_min = 0

            sl = 0.0003
            tp = 0.003

            bid, ask, timestamp = self.eurusd_inst.getCurrentCloseoutBidAsk()

            if self.position == 2:
                if (t_max > tp and t_min > -sl) and self.buy_cd <= 0:
                    self.buy_counts += 1
                    print(timestamp, 'BUY')
                    self.position = 0
                    # self.best_profit = units*movement_threshold*0.1
                    self.best_profit = 0
                    self.yeh_steps = 0
                    # order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                    #                         "units": units, "stop_lost":  round(bid - 0.0015, 8), "trailing_stop_distance": round(t_max.item()/3.0, 8)})
                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": units, "stop_lost":  round(bid - 0.0008, 8), "take_profit": round(bid + 0.0018, 8), "trailing_stop_distance": round(0.0012, 8)})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)
                    if verbose and self.test_mode:
                        plotter.plot_candles(
                            'buy future', self.eurusd_inst.foreseeFutureCandles1M(self.yeh_n + 1*self.yeh_m))
                elif (t_min < -tp and t_max < sl) and self.sell_cd <= 0:
                    self.sell_counts += 1
                    print(timestamp, 'SELL')
                    self.position = 1
                    # self.best_profit = units*movement_threshold*0.1
                    self.best_profit = 0
                    self.yeh_steps = 0
                    # order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                    #                         "units": -units, "stop_lost": round(ask + 0.0015, 8), "trailing_stop_distance": round(-t_min.item()/3.0, 8)})
                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": -units, "stop_lost": round(ask + 0.0008, 8), "take_profit": round(ask - 0.0018, 8), "trailing_stop_distance": round(0.0012, 8)})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)
                    if verbose and self.test_mode:
                        plotter.plot_candles(
                            'sell future', self.eurusd_inst.foreseeFutureCandles1M(self.yeh_n + 1*self.yeh_m))

            elif self.position == 0:
                self.yeh_steps += 1
                self.total_yeh_steps += 1

                if self.yeh_steps >= self.yeh_n + self.yeh_m:
                    print('02')
                    self.current_trade.close()
            elif self.position == 1:
                self.yeh_steps += 1
                self.total_yeh_steps += 1

                if self.yeh_steps >= self.yeh_n + self.yeh_m:
                    print('12')
                    self.current_trade.close()
            # if verbose:
            print(timestamp, ' max: %.6f, min: %.6f ' % (t_max, t_min))
            # print(outputs)
            # output = outputs[0]
            # mv_avg_sum = outputs[0].clone()
            # for i in range(len(self.move_avg_list)-1):
            #     self.move_avg_list[i] = self.move_avg_list[i+1]
            #     if self.move_avg_list[i]!= None:
            #         mv_avg_sum += self.move_avg_list[i]
            # self.move_avg_list[-1] = output
            # # print(mv_avg_sum)
            #
            # mv_avg = mv_avg_sum / len(self.move_avg_list)
            # print(mv_avg)
            # print(self.move_avg_list)
            # plotter.plot_candles('recent_candles', recent_candles_df)

        self.every_15_second_loop_count += 1

    def run(self, BrokerAPI):
        self.test_mode = True
        self.data_scaler = dataloader.StandardScaler()

        net = nets.ElNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            print(net.cuda())

        self.net = net
        BrokerAPI.onEvery15Second(self._every_15_second_loop)
        # BrokerAPI.onLoop(self._every_15_second_loop)
        self.eurusd_inst = BrokerAPI.getInstrument('EUR_USD')
        self.usdchf_inst = BrokerAPI.getInstrument('USD_CHF')
        self.eurjpy_inst = BrokerAPI.getInstrument('EUR_JPY')
        self.usdjpy_inst = BrokerAPI.getInstrument('USD_JPY')
        self.gbpusd_inst = BrokerAPI.getInstrument('GBP_USD')
        self.xauusd_inst = BrokerAPI.getInstrument('XAU_USD')
        self.account = BrokerAPI.getAccount()

        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 1, 1, 0, 0)), utc.localize(datetime(2021, 4, 8, 23, 59)))

    def stop_running(self, BrokerAPI):
        print('Win rate: buy(%.5f), sell(%.5f)' %
              (self.buy_win_rate, self.sell_win_rate))
        print('Buy Pl: %.5f, Counts: %d, Avg: %.5f.\nSell Pl: %.5f, Counts: %d, Avg: %.5f.' % (
            self.buy_pl, self.buy_counts, self.buy_pl/max(self.buy_counts, 1), self.sell_pl, self.sell_counts, self.sell_pl/max(self.sell_counts, 1)))

    def train(self, BrokerAPI):
        global learning_rate
        # dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2002, 1, 1, 0, 0)), utc.localize(datetime(2020, 11, 29, 23, 59)))
        net = nets.ElNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        # net.eval()
        net.train()
        if cuda_enabled:
            print(net.cuda())

        # outputs = net(torch.randn(3, 180, 24).cuda())
        # print(outputs.shape)
        # raise

        dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2009, 1, 1, 0, 0)), utc.localize(datetime(2020, 12, 29, 23, 59)))
        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 1, 1, 0, 0)), utc.localize(datetime(2021, 4, 8, 23, 59)))
        # print(dl.generateBatches(2, 2))

        criterion = torch.nn.MSELoss()
        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        training_batches = dl.generateBatches(batch_counts, batch_size, cuda=cuda_enabled)
        test_batches = test_dl.generateBatches(1, batch_size, cuda=cuda_enabled)
        t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]

        for epoch in range(epoch_counts):
            if (epoch - 1) % training_batches_update_epochs == training_batches_update_epochs-1 and epoch != 0:
                torch.save(net.state_dict(), self.agent_directory +
                           datetime.now().strftime("/backup.net"))

                del training_batches
                training_batches = dl.generateBatches(batch_counts, batch_size, cuda=cuda_enabled)
                learning_rate = learning_rate*0.95
                for param_group in optimizer.param_groups:
                    param_group['lr'] = learning_rate
                print('Training batches updated.')


            running_loss = 0.0
            for encode_inputs, encode_times, decode_inputs, decode_times, labels in training_batches:

                outputs = net(encode_inputs, encode_times, decode_inputs, decode_times)
                optimizer.zero_grad()

                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                running_loss += loss.item()

            x = list(range(0, decode_predict_len))
            plt.plot(x, dl.convertToCloseDiffRaw(labels[0, :, 0]).tolist(), label='Label')
            plt.plot(x, dl.convertToCloseDiffRaw(outputs[0, :, 0]).tolist(), label='Predict')
            plt.legend()
            plt.savefig(self.agent_directory +'/figs/'+ datetime.now().strftime("/EL_%Y_%m_%d_%H_%M.png"))
            plt.clf()

            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)
            # test_loss = criterion(test_outputs, test_labels)
            test_loss = criterion(test_outputs, t_labels)

            print("Epoch: %d, loss: %1.8f, test loss: %1.8f" % (epoch, math.sqrt(running_loss/batch_counts), math.sqrt(test_loss.item())))

        # outputs = net(test_inputs)

        print(self.agent_directory + datetime.now().strftime("/EL_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/EL_%Y_%m_%d_%H_%M.net"))

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        cuda_enabled = False
        self.test_mode = True
        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 1, 1, 0, 0)), utc.localize(datetime(2021, 4, 8, 23, 59)))
        # test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2020, 1, 1, 0, 0)), utc.localize(datetime(2020, 4, 8, 23, 59)))


        net = nets.ElNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            net.cuda()

        while(True):
            test_batches = test_dl.generateBatches(1, batch_size, cuda=cuda_enabled)
            t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]
            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)

            for i in range(batch_size):
                t = test_dl.convertToCloseDiffRaw(test_outputs[i, :, 0])
                t_max = torch.max(t)
                t_min = torch.min(t)
                print(t_max, t_min)
                sl = 0.0003
                tp = 0.003
                if (t_max > tp and t_min > -sl) or (t_min < -tp and t_max < sl):
                    x = list(range(0, decode_predict_len))
                    # x = list(range(0, 60))
                    plt.plot(x, test_dl.convertToCloseDiffRaw(t_labels[i, :, 0]).tolist(), label='Close')
                    # plt.plot(x, test_dl.convertToCloseRaw(t_labels[i, :, 1]).tolist(), label='Upper')
                    # plt.plot(x, test_dl.convertToCloseRaw(t_labels[i, :, 2]).tolist(), label='Lower')
                    plt.plot(x, test_dl.convertToCloseDiffRaw(test_outputs[i, :, 0]).tolist(), label='Predict')
                    plt.legend()
                    plt.show()
            # self.run(BacktestBrokerAPI)

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
