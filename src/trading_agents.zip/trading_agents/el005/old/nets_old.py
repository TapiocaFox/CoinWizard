#!/usr/bin/python3

import torch, math
import torch.nn as nn
from trading_agents.el005.informer.model import Informer

class ElNet(nn.Module):
    def __init__(self):
        super(ElNet, self).__init__()
        self.decode_inference_len = 120
        self.decode_predict_len = 240
        self.informer = Informer(24, 24, 1, self.decode_predict_len, dropout=0.1, embed='timeF', freq='t', factor=6, e_layers=4, d_layers=3)

    def forward(self, encode_input, encode_time, decode_input, decode_time):
        # decode_input = torch.zeros(encode_input.size(0), self.decode_predict_len, 24)
        # decode_input = torch.cat([encode_input[:,-self.decode_inference_len:,:], decode_input], dim=1)
        # decode_time = torch.zeros(encode_input.size(0), self.decode_predict_len, 24)
        x = self.informer(encode_input, encode_time, decode_input, decode_time)
        return x

class ElBoundNet(nn.Module):
    def __init__(self, graph_net):
        super(ElBoundNet, self).__init__()
