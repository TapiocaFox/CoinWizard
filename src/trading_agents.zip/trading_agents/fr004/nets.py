#!/usr/bin/python3

import torch, math
import torch.nn as nn

# http://nlp.seas.harvard.edu/2018/04/03/attention.html

class PositionalEncoding(nn.Module):

    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:x.size(0), :]
        return self.dropout(x)

class FrXShortTermAttention(nn.Module):
    def __init__(self, d_model, dim_feedforward=1024, num_heads=8, dropout=0.1, out_sequence_length=30, layer_norm_eps=1e-5):
        super(FrXShortTermAttention, self).__init__()
        self.out_sequence_length = out_sequence_length
        self.attention = nn.MultiheadAttention(d_model, num_heads=8, dropout=dropout)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.gelu = nn.GELU()

        self.norm1 = nn.LayerNorm(d_model, eps=layer_norm_eps)
        self.norm2 = nn.LayerNorm(d_model, eps=layer_norm_eps)
        self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)

    def forward(self, x):
        x2, _ = self.attention(x[-self.out_sequence_length:, :, :], x, x)

        x = x[-self.out_sequence_length:, :, :] + self.dropout1(x2)
        x = self.norm1(x)

        x2 = self.gelu(self.linear1(x))
        x2 = self.linear2(self.dropout(x2))
        x = x + self.dropout2(x2)
        x = self.norm2(x)
        return x

class FrXNet(nn.Module):
    def __init__(self, input_features=24, output_features=3, out_sequence_length=30, d_model=360, dim_feedforward=1024, num_layers=2, dropout=0.25):
        super(FrXNet, self).__init__()
        self.num_layers = num_layers
        self.hidden_size = int(d_model/2)
        self.out_sequence_length = out_sequence_length
        self.d_model = d_model

        # Short term
        self.s_fc1 = nn.Linear(input_features, d_model)
        self.s_gru = nn.GRU(d_model, self.hidden_size, num_layers=self.num_layers, bidirectional=True, dropout=dropout)
        self.s_pos_encoder = PositionalEncoding(d_model, dropout)
        self.s_attention = FrXShortTermAttention(d_model=d_model, dim_feedforward=dim_feedforward, num_heads=8, out_sequence_length=out_sequence_length, dropout=dropout)

        # Long term
        self.gelu = nn.GELU()
        self.tanh = nn.Tanh()
        self.l_conv1 = nn.Conv1d(input_features, self.hidden_size, 3, stride=1)
        self.l_pool1 = nn.AvgPool1d(60, 30)
        self.l_conv2 = nn.Conv1d(self.hidden_size, self.hidden_size, 5, stride=1)
        self.l_pool2 = nn.AvgPool1d(12, 6)
        self.l_fc1 = nn.Linear(3*self.hidden_size, self.hidden_size)

        # Final
        self.fc1 = nn.Linear(self.hidden_size+d_model, dim_feedforward)
        self.fc2 = nn.Linear(dim_feedforward, output_features)
        self.dropout = nn.Dropout(dropout)
        self.sigmoid = nn.Sigmoid()

    def short_term_forward(self, x):
        if x.get_device() >= 0:
            h_0 = torch.zeros(self.num_layers*2, x.size(1), self.hidden_size).to(x.get_device())
        else:
            h_0 = torch.zeros(self.num_layers*2, x.size(1), self.hidden_size)

        x = self.s_fc1(x)
        x, _ = self.s_gru(x, h_0)
        x = self.s_pos_encoder(x)
        x = self.s_attention(x)
        return x

    def long_term_forward(self, x):
        x = self.gelu(self.l_conv1(x))
        x = self.l_pool1(x)
        x = self.gelu(self.l_conv2(x))
        x = self.l_pool2(x)
        # print(x.shape)
        x = x.view(-1, 1, 3*self.hidden_size)
        x = self.tanh(self.l_fc1(x))
        return x

    def forward(self, x):
        short_vector_sequence = self.short_term_forward(x[-120:])
        long_vector = self.long_term_forward(x.permute(1, 2, 0))
        long_vector = long_vector.expand(-1, self.out_sequence_length, -1)
        long_vector = long_vector.permute(1, 0, 2)
        x = torch.cat((long_vector, short_vector_sequence), 2)
        x = self.tanh(self.fc1(x))
        x = self.sigmoid(self.fc2(self.dropout(x)))
        return x

class FrClassificationHead(nn.Module):
    def __init__(self, d_model, dim_feedforward=512, num_heads=8, dropout=0.1, out_sequence_length=60, layer_norm_eps=1e-5):
        super(FrClassificationHead, self).__init__()
        self.out_sequence_length = out_sequence_length
        self.attention = nn.MultiheadAttention(d_model, num_heads=8, dropout=dropout)
        # self.linear1 = nn.Linear(d_model, dim_feedforward)
        # self.linear2 = nn.Linear(dim_feedforward, 3)
        self.fc1 = nn.Linear(d_model, 3)
        self.sigmoid = nn.Sigmoid()
        # self.gelu = nn.GELU()

        self.norm1 = nn.LayerNorm(d_model, eps=layer_norm_eps)
        # self.norm2 = nn.LayerNorm(3, eps=layer_norm_eps)
        # self.dropout = nn.Dropout(dropout)
        self.dropout1 = nn.Dropout(dropout)
        # self.dropout2 = nn.Dropout(dropout)

    def forward(self, x):
        x2, _ = self.attention(x[-self.out_sequence_length:, :, :], x, x)
        # x = x + self.dropout1(x2)
        x = x[-self.out_sequence_length:, :, :] + self.dropout1(x2)
        x = self.norm1(x)

        x = self.sigmoid(self.fc1(x))

        # x = self.gelu(self.linear1(x))
        # # x = self.linear2(self.dropout2(x))
        # x = self.linear2(x)
        # x = self.norm2(x)
        # x = self.sigmoid(x)
        return x

class FrSentimentalNet(nn.Module):
    def __init__(self, input_features=24, output_features=3, d_model=512, dim_feedforward=2048, num_layers=2, dropout=0.1):
        super(FrSentimentalNet, self).__init__()
        self.num_layers = num_layers
        self.hidden_size = int(d_model/2)
        self.gru = nn.GRU(d_model, self.hidden_size, num_layers=self.num_layers, bidirectional=True, dropout=dropout)

        self.fc1 = nn.Linear(input_features, d_model)
        # self.gelu = nn.GELU()
        self.pos_encoder = PositionalEncoding(d_model, dropout)
        # encoder_layer = nn.TransformerEncoderLayer(d_model=d_model, nhead=8, dim_feedforward=dim_feedforward, dropout=dropout, activation='gelu')
        # self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=1)

        self.classify = FrClassificationHead(d_model=d_model, dim_feedforward=dim_feedforward, num_heads=8, dropout=dropout)

    def forward(self, x):
        if x.get_device() >= 0:
            h_0 = torch.zeros(self.num_layers*2, x.size(1), self.hidden_size).to(x.get_device())
        else:
            h_0 = torch.zeros(self.num_layers*2, x.size(1), self.hidden_size)

        x = self.fc1(x)
        # x = self.pos_encoder(x)
        x, _ = self.gru(x, h_0)


        x = self.pos_encoder(x)
        # x = self.transformer_encoder(x)
        x = self.classify(x)
        return x
