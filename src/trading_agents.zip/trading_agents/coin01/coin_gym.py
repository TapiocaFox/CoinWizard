import torch
from data_loader import DataLoader
import matplotlib.pyplot as plt

from datetime import datetime, timedelta
import copy

granularity_time_delta = {
    "M1": timedelta(seconds=60),
    "M5": timedelta(seconds=60*5),
    "M15": timedelta(seconds=60*15),
    "M30": timedelta(seconds=60*30),
    "H1": timedelta(seconds=60*60),
    "H4": timedelta(seconds=60*240),
    "D": timedelta(seconds=60*60*24),
}

class Gym(object):
    def __init__(self, instrument_list, granularity_list, primary_granularity, input_period_list, from_datetime, to_datetime, episode_steps, reward_calculator, concurrent_episodes, cuda, verbose=True):
        self.verbose = verbose

        self.instrument_list = instrument_list
        self.granularity_list = granularity_list
        self.primary_granularity = primary_granularity
        self.input_period_list = input_period_list
        self.from_datetime = from_datetime
        self.to_datetime = to_datetime
        self.reward_calculator = reward_calculator
        self.episode_steps = episode_steps
        self.current_episode_steps = 0
        self.concurrent_episodes = concurrent_episodes
        self.episode_candles_start_index_list = []
        self.available_actions_list = []
        self.dataloader = DataLoader(instrument_list, granularity_list, primary_granularity, input_period_list, from_datetime, to_datetime, episode_steps+1)
        self.cuda = cuda
        self.position_state_list = []
        self.accumulated_trade_steps = []
        self.idle_position = 0
        self.long_position = 1
        self.short_position = 2

        self.actions = ['wait', 'long', 'short', 'close']
        self.position_available_acitons = [
              [1, 1, 1, 0],
              [1, 0, 0, 1],
              [1, 0, 0, 1]
          ]

        self.position_action_to_position_table = [
              [0, 1, 2, 0],
              [1, 1, 1, 0],
              [2, 2, 2, 0]
          ]

    def _step_actions(self, actions):
        self.current_episode_steps += 1
        reward = self.reward_calculator.step(self.current_episode_steps, actions)
        for episode_index, (position_state, action) in enumerate(zip(self.position_state_list, actions)):
            available_actions = self.position_available_acitons[position_state]
            if available_actions[action]:
                self.position_state_list[episode_index] = self.position_action_to_position_table[position_state][action]
            else:
                pass
                # action not available

        return reward

    def _step_states(self):
        candles_states = [[None for j in range(len(self.granularity_list))] for i in range(self.concurrent_episodes)]

        # Concurrent episodes
        for episode_index, (candles_list, start_index) in enumerate(self.episode_candles_start_index_list):
            timestamp = (candles_list[self.primary_granularity].timestamp)[start_index+self.current_episode_steps]
            # Granularities
            for granularity, candles in enumerate(candles_list):
                hist_data = candles_list[granularity]
                input_period = self.input_period_list[granularity]
                timestamp_series = hist_data.timestamp
                granularity_random_index = timestamp_series.searchsorted(timestamp-granularity_time_delta[self.granularity_list[granularity]], side='right') - 1
                candles_states[episode_index][granularity] = hist_data.iloc[granularity_random_index+1-input_period:granularity_random_index+1]

        return (candles_states, self.position_state_list)

    def reset(self):
        if self.verbose:
            print('Gym reset between date "' + str(self.from_datetime) + '" and "'+ str(self.to_datetime)+'". ')
            print('With selected instruments: '+str(self.instrument_list)+'.')

        del self.episode_candles_start_index_list[:]
        del self.position_state_list[:]
        del self.accumulated_trade_steps[:]

        self.episode_candles_start_index_list = [self.dataloader.generateEpisode() for i in range(self.concurrent_episodes)]
        self.position_state_list = [self.idle_position for i in range(self.concurrent_episodes)]
        self.position_state_list = [0 for i in range(self.concurrent_episodes)]
        self.current_episode_steps = 0

        self.reward_calculator.reset(self.concurrent_episodes, self.granularity_list, self.episode_candles_start_index_list, self.primary_granularity, self.episode_steps, self.position_available_acitons, self.position_action_to_position_table)
        return self._step_states()

    def step(self, actions):
        reward = self._step_actions(actions)
        done = self.current_episode_steps >= self.episode_steps
        return self._step_states(), reward, done
