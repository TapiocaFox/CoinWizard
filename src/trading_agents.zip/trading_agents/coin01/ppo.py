import torch
import torch.nn as nn
from torch.distributions import MultivariateNormal
from torch.distributions import Categorical

class ReusedRolloutBuffer:
    def __init__(self):
        self.actions = []
        self.available_actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []


    def clear(self):
        del self.actions[:]
        del self.available_actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]

class RolloutBuffer:
    def __init__(self):
        self.actions = []
        self.available_actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []


    def clear(self):
        del self.actions[:]
        del self.available_actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]


class ActorCritic(nn.Module):
    def __init__(self, actor, critic):
        super(ActorCritic, self).__init__()

        # actor
        self.actor = actor

        # critic
        self.critic = critic

    def forward(self):
        raise NotImplementedError

    def act(self, state, available_actions):
        action_probs = self.actor(state, available_actions)
        # print(action_probs)
        dist = Categorical(action_probs)

        action = dist.sample()
        action_logprob = dist.log_prob(action)

        return action.detach(), action_logprob.detach()

    def evaluate(self, state, available_actions, action):
        action_probs = self.actor(state, available_actions)
        dist = Categorical(action_probs)
        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        state_values = self.critic(state)

        return action_logprobs, state_values, dist_entropy


class PPO:
    def __init__(self, actor_critic, lr_actor, lr_critic, gamma, K_epochs, epoch_size, eps_clip, mini_batchs_merge=1, verbose=False, cuda=False):

        self.verbose = verbose

        self.device = torch.device('cuda:0') if cuda else torch.device('cpu')

        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs
        self.epoch_size = epoch_size

        self.mini_batchs_merge = mini_batchs_merge

        self.buffer = RolloutBuffer()

        self.policy = actor_critic
        self.optimizer = torch.optim.Adam([
                        {'params': self.policy.actor.parameters(), 'lr': lr_actor},
                        {'params': self.policy.critic.parameters(), 'lr': lr_critic}
                    ])

        self.policy_old = actor_critic
        self.policy_old.load_state_dict(self.policy.state_dict())

        self.MseLoss = nn.MSELoss()


    def select_action(self, state, available_actions):
        with torch.no_grad():
            # state = torch.FloatTensor(state).to(self.device)
            action, action_logprob = self.policy_old.act(state, available_actions)

        self.buffer.states.append(state)
        self.buffer.actions.append(action)
        self.buffer.available_actions.append(available_actions)
        self.buffer.logprobs.append(action_logprob)

        return action.tolist()


    def update(self):

        # Monte Carlo estimate of returns
        rewards = []
        discounted_reward = torch.zeros(self.buffer.rewards[0].shape[0], device=self.device)
        for reward in reversed(self.buffer.rewards):
            discounted_reward = reward + (self.gamma * discounted_reward)
            rewards.insert(0, discounted_reward)
        # Normalizing the rewards
        rewards = torch.stack(rewards)
        rewards = (rewards - rewards.mean(dim=0)) / (rewards.std(dim=0) + 1e-7)
        rewards_list = rewards.split(1, dim=0)

        # convert list to tensor
        # old_states = torch.squeeze(torch.stack(self.buffer.states, dim=0)).detach().to(self.device)
        # old_actions = torch.squeeze(torch.stack(self.buffer.actions, dim=0)).detach().to(self.device)
        # old_logprobs = torch.squeeze(torch.stack(self.buffer.logprobs, dim=0)).detach().to(self.device)

        # Optimize policy for K epochs
        if self.verbose:
            print('PPO training [ ', end='', flush=True)

        for _ in range(self.K_epochs):
            # Get total buffer length
            buffer_length = len(self.buffer.states)

            # Random permutation
            randperm = torch.randperm(buffer_length).tolist()

            for steps in range(min(self.epoch_size, buffer_length)):
                i = randperm[steps]
                old_states = self.buffer.states[i]
                old_actions = self.buffer.actions[i]
                old_available_actions = self.buffer.available_actions[i]
                old_logprobs = self.buffer.logprobs[i]
                rewards = rewards_list[i]
                # print(old_states, old_actions, old_available_actions, old_logprobs, rewards)
                # raise
                # Evaluating old actions and values
                logprobs, state_values, dist_entropy = self.policy.evaluate(old_states, old_available_actions, old_actions)

                # match state_values tensor dimensions with rewards tensor
                rewards = torch.squeeze(rewards)
                state_values = torch.squeeze(state_values)

                # Finding the ratio (pi_theta / pi_theta__old)
                ratios = torch.exp(logprobs - old_logprobs.detach())

                # Finding Surrogate Loss
                advantages = rewards - state_values.detach()
                surr1 = ratios * advantages
                surr2 = torch.clamp(ratios, 1-self.eps_clip, 1+self.eps_clip) * advantages

                # final loss of clipped objective PPO
                loss = -torch.min(surr1, surr2) + 0.5*self.MseLoss(state_values, rewards) - 0.01*dist_entropy

                # take gradient step
                loss = loss.mean()/self.mini_batchs_merge

                loss.backward()

                if (steps+1) == len(randperm) or (steps+1)%self.mini_batchs_merge == 0:
                    self.optimizer.step()
                    self.optimizer.zero_grad()

            if self.verbose:
                print('>', end='', flush=True)

        # Copy new weights into old policy
        self.policy_old.load_state_dict(self.policy.state_dict())

        # clear buffer
        self.buffer.clear()

        if self.verbose:
            print(' ]')

    def clear(self):
        self.buffer.clear()

    def get_actor_critic(self):
        return self.policy
