import torch
from torch import nn

from einops import rearrange, repeat
from einops.layers.torch import Rearrange

from math import ceil
# helpers

def pair(t):
    return t if isinstance(t, tuple) else (t, t)

# classes
class MaskedSoftmax(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()
        self.softmax = nn.Softmax(**kwargs)

    def forward(self, x, mask):
        x_masked = x.clone()
        x_masked[mask == 0] = -float("inf")

        # print(x_masked)
        return self.softmax(x_masked)

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )
    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.attend = nn.Softmax(dim = -1)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale

        attn = self.attend(dots)

        out = torch.matmul(attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)

class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout = 0.):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                PreNorm(dim, Attention(dim, heads = heads, dim_head = dim_head, dropout = dropout)),
                PreNorm(dim, FeedForward(dim, mlp_dim, dropout = dropout))
            ]))
    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return x

class ViT1D(nn.Module):
    def __init__(self, *, sequence_length, patch_length, in_dim, dim, depth, heads, mlp_dim, pool = 'cls', dim_head = 64, dropout = 0., emb_dropout = 0.):
        super().__init__()

        assert sequence_length % patch_length == 0, 'Image dimensions must be divisible by the patch size.'

        num_patches = (sequence_length // patch_length)
        patch_dim = in_dim * patch_length
        assert pool in {'cls', 'mean'}, 'pool type must be either cls (cls token) or mean (mean pooling)'

        self.to_patch_embedding = nn.Sequential(
            Rearrange('b (p_num p_len) in_dim -> b p_num (p_len in_dim)', p_len = patch_length),
            nn.Linear(patch_dim, dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout)

        self.pool = pool
        self.to_latent = nn.Identity()


    def forward(self, x):
        x = self.to_patch_embedding(x)
        b, n, _ = x.shape

        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b = b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        x = self.transformer(x)

        x = x.mean(dim = 1) if self.pool == 'mean' else x[:, 0]

        x = self.to_latent(x)

        return x

class DecoderTransformer(nn.Module):
    def __init__(self, *, sequence_length, in_dim, dim, depth, heads, mlp_dim, pool = 'cls', dim_head = 64, dropout = 0., emb_dropout = 0.):
        super().__init__()

        assert pool in {'cls', 'mean'}, 'pool type must be either cls (cls token) or mean (mean pooling)'

        self.input_embedding = nn.Sequential(
            nn.Linear(in_dim, dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, sequence_length + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout)

        self.pool = pool
        self.to_latent = nn.Identity()


    def forward(self, x):
        x = self.input_embedding(x)
        b, n, _ = x.shape

        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b = b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        x = self.transformer(x)

        x = x.mean(dim = 1) if self.pool == 'mean' else x[:, 0]

        x = self.to_latent(x)

        return x

class CoinNet(nn.Module):
    def __init__(self, sequence_length_list=[288, 288, 288], in_dim_list=[6, 5, 5], granularities_dropout_list=[True, True, True], vit_depth=1, decoder_transformer_depth=1, patch_length=12, heads=8, d_model=512, mlp_dim=1024, dropout=0., num_actions=4, critic=False):
        super().__init__()

        self.critic = critic

        self.d_model = d_model
        self.num_actions = num_actions
        # self.action_tokens = nn.Parameter(torch.randn(num_actions, d_model))

        dim_head = (d_model // heads)

        self.vit_list = nn.ModuleList([
            nn.Sequential(
                ViT1D(
                    sequence_length=sequence_length,
                    patch_length=patch_length,
                    in_dim=in_dim,
                    dim=d_model,
                    depth=vit_depth,
                    heads=heads,
                    mlp_dim=mlp_dim,
                    dropout=dropout,
                    emb_dropout=dropout
                ),
                nn.LayerNorm(d_model)
            )
            for sequence_length, in_dim in zip(sequence_length_list, in_dim_list)
        ])

        self.decoder = DecoderTransformer(
                        sequence_length=len(sequence_length_list),
                        in_dim=d_model,
                        dim=d_model,
                        depth=decoder_transformer_depth,
                        heads=heads,
                        mlp_dim=mlp_dim,
                        dropout=dropout,
                        emb_dropout=dropout
                    )

        if critic:
            self.mlp_head = nn.Sequential(
                nn.LayerNorm(d_model),
                nn.Linear(d_model, 1)
            )
        else:
            # For later dot product
            self.mlp_head = nn.Sequential(
                nn.LayerNorm(d_model),
                nn.Linear(d_model, num_actions)
            )

            self.softmax = MaskedSoftmax(dim=-1)

    def forward(self, x_list, available_actions=None):
        granularity = len(self.vit_list)
        vit_out_list = [self.vit_list[i](x_list[i]) for i in range(granularity)]
        x = torch.stack(vit_out_list, dim=1)
        x = self.decoder(x)

        if self.critic:
            x = self.mlp_head(x)
        else:
            # # print(available_actions)
            # available_actions = torch.einsum('ba,ad->bad', available_actions, self.action_tokens)
            # # print(available_actions)
            # x = self.mlp_head(x)
            # x = torch.einsum('bad,bd->ba', available_actions, x) # Dot product
            # print(x)
            # x = self.softmax(x)
            x = self.mlp_head(x)
            x = self.softmax(x, available_actions)
        return x
