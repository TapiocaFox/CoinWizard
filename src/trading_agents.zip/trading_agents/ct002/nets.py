#!/usr/bin/python3

import torch
import torch.nn as nn

class CtNet(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(CtNet, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = 2

        self.norm = nn.LayerNorm(input_size)
        self.softmax = nn.Softmax(dim=-1)
        self.tanh = nn.Tanh()
        self.sigmoid = nn.Sigmoid()
        # self.rnn = nn.GRU(input_size, hidden_size, num_layers=self.num_layers, dropout=0.2)
        # self.rnn = nn.LSTM(input_size, hidden_size, num_layers=self.num_layers, dropout=0.35)
        self.rnn = nn.LSTM(input_size, hidden_size, num_layers=self.num_layers, dropout=0.15)
        self.fc1 = nn.Linear(hidden_size, output_size*4)
        self.fc2 = nn.Linear(output_size*4, output_size)

    def forward(self, input):
        # input = self.norm(input)
        if input.get_device() >= 0:
            h_0 = torch.zeros(self.num_layers, input.size(1), self.hidden_size).to(input.get_device())
            c_0 = torch.zeros(self.num_layers, input.size(1), self.hidden_size).to(input.get_device())
        else:
            h_0 = torch.zeros(self.num_layers, input.size(1), self.hidden_size)
            c_0 = torch.zeros(self.num_layers, input.size(1), self.hidden_size)

        x, (_, __) = self.rnn(input, (h_0, c_0))
        # x, _ = self.rnn(input, h_0)
        # x = x.view(-1, self.hidden_size)
        x = self.fc1(x[-360:, :, :])
        x = self.fc2(self.tanh(x))
        x = self.sigmoid(x)
        return x
