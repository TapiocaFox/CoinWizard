#!/usr/bin/python3

import torch, random, math

import coin_wizard.historical_pair_data as hist
import numpy as np
from coin_wizard.technical_indicators import TechnicalIndicators
from datetime import datetime, timedelta
from .timefeatures import time_features
import matplotlib.pyplot as plt

import coin_wizard.plotter as plotter

time_delta_1_days = timedelta(days=7)

ti = TechnicalIndicators()

class StandardScaler():
    def __init__(self):
        # self.mean = np.array([1.2226823568344116, -5.239083748165285e-06, -3.1956626571627567e-06, 50.02531814575195, 0.21008837223052979, -6.678907539026113e-06, -3.8050857256166637e-06, 50.05034637451172, 0.3087314963340759, -0.00014962774002924562, 6.619840178245795e-07, 50.35264587402344, 1.7348049879074097])
        # self.std = np.array([0.11180845648050308, 0.0007891162531450391, 0.001594686764292419, 15.437833786010742, 89.16117858886719, 0.0009378508548252285, 0.001643498195335269, 15.34361457824707, 88.8891372680664, 0.09478573501110077, 0.0019835627172142267, 15.45702075958252, 88.71973419189453])
        self.mean = np.array([1.2538361549377441, 0, 0, 50, 0])
        self.std = np.array([0.12284567952156067, 0.000874049321282655, 0.0017087317537516356, 15.488541603088379, 88.93570709228516])

    def fit(self, data):
        self.mean = data.mean(0)
        self.std = data.std(0)
        print('mean:')
        print(self.mean.tolist())
        print('std:')
        print(self.std.tolist())
        print('shape:')
        print(self.std.shape)

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean) / std

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std) + mean

    def transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean[i]) / std[i]

    def diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return data / std[i]

    def inverse_transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i]) + mean[i]

    def inverse_diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i])

class EurUsdDataLoader(object):
    def __init__(self, from_datetime, to_datetime, moving_average=9, roc_period=9, rsi_period=14, cci_period=20):
        self.pip=0.0001
        self.jpypip=0.01


        self.eurusd_hist_data = hist.get_historical_pair_data_pandas('eurusd', from_datetime, to_datetime, granularity='M15')

        # self.eurusd_hist_data['ema'] = ti.ema(self.eurusd_hist_data.close, moving_average)
        self.eurusd_hist_data['macd'] = ti.macd(self.eurusd_hist_data.close, 12, 26)
        self.eurusd_hist_data['roc'] = ti.roc(self.eurusd_hist_data.close, roc_period)
        self.eurusd_hist_data['rsi'] = ti.rsi_ema(self.eurusd_hist_data.close, rsi_period)
        self.eurusd_hist_data['cci'] = ti.cci(self.eurusd_hist_data.high, self.eurusd_hist_data.low, self.eurusd_hist_data.close, cci_period)
        del self.eurusd_hist_data['open']
        del self.eurusd_hist_data['high']
        del self.eurusd_hist_data['low']

        # self.gbpusd_hist_data = hist.get_historical_pair_data_pandas('gbpusd', from_datetime, to_datetime, granularity='M15')
        #
        # self.gbpusd_hist_data['macd_gbpusd'] = ti.macd(self.gbpusd_hist_data.close, 12, 26)
        # self.gbpusd_hist_data['roc_gbpusd'] = ti.roc(self.gbpusd_hist_data.close, roc_period)
        # self.gbpusd_hist_data['rsi_gbpusd'] = ti.rsi_ema(self.gbpusd_hist_data.close, rsi_period)
        # self.gbpusd_hist_data['cci_gbpusd'] = ti.cci(self.gbpusd_hist_data.high, self.gbpusd_hist_data.low, self.gbpusd_hist_data.close, cci_period)
        # del self.gbpusd_hist_data['close']
        # del self.gbpusd_hist_data['open']
        # del self.gbpusd_hist_data['high']
        # del self.gbpusd_hist_data['low']
        #
        #
        # self.eurjpy_hist_data = hist.get_historical_pair_data_pandas('eurjpy', from_datetime, to_datetime, granularity='M15')
        #
        # self.eurjpy_hist_data['macd_eurjpy'] = ti.macd(self.eurjpy_hist_data.close, 12, 26)
        # self.eurjpy_hist_data['roc_eurjpy'] = ti.roc(self.eurjpy_hist_data.close, roc_period)
        # self.eurjpy_hist_data['rsi_eurjpy'] = ti.rsi_ema(self.eurjpy_hist_data.close, rsi_period)
        # self.eurjpy_hist_data['cci_eurjpy'] = ti.cci(self.eurjpy_hist_data.high, self.eurjpy_hist_data.low, self.eurjpy_hist_data.close, cci_period)
        # del self.eurjpy_hist_data['close']
        # del self.eurjpy_hist_data['open']
        # del self.eurjpy_hist_data['high']
        # del self.eurjpy_hist_data['low']

        self.first_valid_idex = 30

        self.hist_data = self.eurusd_hist_data
        # self.hist_data = self.eurusd_hist_data.merge(self.gbpusd_hist_data, how='inner', on='timestamp')
        # self.hist_data = self.hist_data.merge(self.eurjpy_hist_data, how='inner', on='timestamp')
        self.hist_data.replace([np.inf, -np.inf], np.nan, inplace=True)
        self.hist_data = self.hist_data.dropna().reset_index(drop=True)

        print(self.hist_data[-1:])

        self.hist_data_np = np.array([
            self.hist_data.close.to_list(),
            self.hist_data.macd.to_list(),
            self.hist_data.roc.to_list(),
            self.hist_data.rsi.to_list(),
            self.hist_data.cci.to_list(),
            # self.hist_data.macd_gbpusd.to_list(),
            # self.hist_data.roc_gbpusd.to_list(),
            # self.hist_data.rsi_gbpusd.to_list(),
            # self.hist_data.cci_gbpusd.to_list(),
            # self.hist_data.macd_eurjpy.to_list(),
            # self.hist_data.roc_eurjpy.to_list(),
            # self.hist_data.rsi_eurjpy.to_list(),
            # self.hist_data.cci_eurjpy.to_list(),
        ], dtype=np.float32)

        # self.label_data_np = np.array([
        #     self.hist_data.close.to_list(),
        # ], dtype=np.float32)

        self.hist_data_np = np.swapaxes(self.hist_data_np, 0, 1)
        # self.hist_data_np = np.nan_to_num(self.hist_data_np, nan=0, posinf=0, neginf=0)

        # self.label_data_np = np.swapaxes(self.label_data_np, 0, 1)
        ds = StandardScaler()
        # print(self.hist_data_np)
        # ds.fit(self.hist_data_np)
        # raise

        # print(self.hist_data)
        self.data_scaler = ds
        self.hist_data_np = ds.transform(self.hist_data_np)
        # self.label_data_np = ds.transform_index(0, self.label_data_np)

        self.time_np = time_features(self.hist_data['timestamp'], freq='t')
        print(self.time_np)
        # raise

    def convertToCloseRaw(self, data):
        return self.data_scaler.inverse_transform_index(0, data)

    def convertToCloseDiffRaw(self, data):
        return self.data_scaler.inverse_diff_transform_index(0, data)

    def generateBatches(self, batch_counts, batch_size, input_period=480, inference_len=60, out_length=120, neighbors=3, interval=30, shape_exp=np.exp(1), decay_exp=1.001, degree=7, margin=0, clip_value=0.0100, cci_threshold=100, weak_record_threshold=0.00055, weak_record_dropout=0, cuda=True, debug_plot=False): # 1.61803398875 1.05
        batch_list = []
        hist_data = self.hist_data_np
        # label_data = self.label_data_np
        time = self.time_np
        decay_array = np.power(decay_exp, -np.arange(out_length))
        x_axis = np.arange(out_length+2*margin)
        clip_value = self.data_scaler.diff_transform_index(0, clip_value)
        for i in range(batch_counts):
            encode_inputs = []
            encode_times = []
            decode_inputs = []
            decode_times = []
            labels = []

            j = 0
            up_counts = 0
            down_counts = 0
            while j < batch_size:
                if j%neighbors == 0:
                    random_index = None
                    cci = 0
                    previous_cci = 0
                    while random_index is None or ((-cci_threshold < previous_cci or cci <= previous_cci) and (previous_cci < cci_threshold or cci >= previous_cci)):
                        random_index = random.randint(0, hist_data.shape[0] - (input_period + out_length + (neighbors-1)*interval + margin))
                        cci = self.data_scaler.inverse_transform_index(4, hist_data[random_index+input_period-1, 4])
                        previous_cci =  self.data_scaler.inverse_transform_index(4, hist_data[random_index+input_period-1-1, 4])
                        # print(cci)
                        # raise
                    # print('sel', cci, previous_cci)
                else:
                    random_index += random.randint(1, interval)

                encode_input = hist_data[random_index:random_index+input_period, :]
                encode_time = time[random_index:random_index+input_period, :]
                decode_input = np.zeros((out_length, 5))
                decode_input = np.concatenate([hist_data[random_index+input_period-inference_len:random_index+input_period, :], decode_input], axis=0)
                decode_time = time[random_index+input_period-inference_len:random_index+input_period+out_length, :]
                # label = prediction_np[random_index:random_index+input_period]
                # label = label_data[random_index+input_period-margin:random_index+input_period+out_length+margin, 0] - label_data[random_index+input_period-1+1, 0]
                label = hist_data[random_index+input_period-margin:random_index+input_period+out_length+margin, 0] - hist_data[random_index+input_period-1+1, 0]
                label = label.clip(min=-clip_value, max=clip_value)
                if debug_plot:
                    plot_l = label
                poly = np.poly1d(np.polyfit(x_axis, label, degree))

                if margin >0:
                    label = poly(x_axis)[margin:-margin]
                else:
                    label = poly(x_axis)

                max_acc = np.maximum.accumulate(label).clip(min=0)
                min_acc = np.minimum.accumulate(label).clip(max=0)

                # max_acc = np.log10(max_acc)
                # min_acc = -np.log10(-min_acc)
                # print(label)
                # raise

                if shape_exp <= 1:
                    label = np.array([
                        decay_array*max_acc,
                        decay_array*min_acc
                    ]).transpose()
                else:
                    # print(np.power(shape_exp, label/np.maximum.accumulate(label)-1))*np.maximum.accumulate(label)))
                    # raise

                    label = np.array([
                        decay_array*np.power(shape_exp, label/np.maximum(max_acc, np.finfo(np.float32).eps)-1).clip(max=1)*max_acc,
                        decay_array*np.power(shape_exp, label/np.minimum(min_acc, -np.finfo(np.float32).eps)-1).clip(max=1)*min_acc
                    ]).transpose()

                if j%neighbors == 0:
                    max_abs = self.data_scaler.inverse_diff_transform_index(0, np.amax(np.absolute(label)))
                    # print(max_abs)
                    if weak_record_dropout > 0 and max_abs < weak_record_threshold and random.uniform(0, 1) < weak_record_dropout:
                        # print('dropped')
                        continue

                if debug_plot:
                    x = np.arange(out_length)
                    plt.plot(x, self.convertToCloseDiffRaw(label[:, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, self.convertToCloseDiffRaw(label[:, 1]).tolist(), label='Label-CumMin')
                    if margin > 0:
                        plt.plot(x, self.convertToCloseDiffRaw(plot_l[margin:-margin]).tolist(), label='Label-EMA')
                    else:
                        plt.plot(x, self.convertToCloseDiffRaw(plot_l).tolist(), label='Label-EMA')
                    # plt.plot(x, (label[:, 0]).tolist(), label='Label-CumMax')
                    # plt.plot(x, (label[:, 1]).tolist(), label='Label-CumMin')
                    # plt.plot(x, (plot_l[margin:-margin]).tolist(), label='Label-EMA')
                    # linear_reg, _, _, _ = np.linalg.lstsq(x[:, None], decay_array*poly(x_axis)[margin:-margin], rcond=None)
                    # print(linear_reg)
                    # plt.plot(x, self.convertToCloseDiffRaw(x*linear_reg).tolist(), label='Label-Linear')
                    plt.legend()
                    plt.show()

                encode_inputs.append(encode_input)
                encode_times.append(encode_time)
                decode_inputs.append(decode_input)
                decode_times.append(decode_time)
                labels.append(label)
                j += 1

            encode_inputs = torch.tensor(encode_inputs, dtype=torch.float32)
            encode_times = torch.tensor(encode_times, dtype=torch.float32)
            decode_inputs = torch.tensor(decode_inputs, dtype=torch.float32)
            decode_times = torch.tensor(decode_times, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.float32)

            if cuda:
                encode_inputs = encode_inputs.cuda()
                encode_times = encode_times.cuda()
                decode_inputs = decode_inputs.cuda()
                decode_times = decode_times.cuda()
                labels = labels.cuda()

            batch_list.append([encode_inputs, encode_times, decode_inputs, decode_times, labels])

        return batch_list
