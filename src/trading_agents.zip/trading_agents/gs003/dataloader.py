#!/usr/bin/python3

import torch, random, math

import coin_wizard.historical_pair_data as hist
import numpy as np
from coin_wizard.technical_indicators import TechnicalIndicators
from datetime import datetime, timedelta

import coin_wizard.plotter as plotter

time_delta_1_days = timedelta(days=7)

ti = TechnicalIndicators()

class EurUsdDataLoader(object):
    def __init__(self, from_datetime, to_datetime, prediction_steps=25, min_profit=0.0012, max_loss=0.0003):

        if min_profit < max_loss:
            raise

        self.prediction_steps = prediction_steps
        self.pip=0.0001
        self.jpypip=0.01


        self.eurusd_hist_data = hist.get_historical_pair_data_pandas('eurusd', from_datetime, to_datetime )

        self.usdchf_hist_data = hist.get_historical_pair_data_pandas('usdchf', from_datetime, to_datetime )
        # self.usdchf_hist_data['close_usdchf'] = self.usdchf_hist_data['close']
        self.usdchf_hist_data['macd_usdchf'] = ti.macd(self.usdchf_hist_data.close, 12, 26)
        self.usdchf_hist_data['rsi_usdchf'] = ti.rsi_ema(self.usdchf_hist_data.close, 10)
        self.usdchf_hist_data['momentum_usdchf'] = ti.momentum(self.usdchf_hist_data.close, 4)
        del self.usdchf_hist_data['close']
        del self.usdchf_hist_data['open']
        del self.usdchf_hist_data['high']
        del self.usdchf_hist_data['low']

        self.eurjpy_hist_data = hist.get_historical_pair_data_pandas('eurjpy', from_datetime, to_datetime )
        # self.eurjpy_hist_data['close_eurjpy'] = self.eurjpy_hist_data['close']
        self.eurjpy_hist_data['macd_eurjpy'] = ti.macd(self.eurjpy_hist_data.close, 12, 26)
        self.eurjpy_hist_data['rsi_eurjpy'] = ti.rsi_ema(self.eurjpy_hist_data.close, 10)
        self.eurjpy_hist_data['momentum_eurjpy'] = ti.momentum(self.eurjpy_hist_data.close, 4)
        del self.eurjpy_hist_data['close']
        del self.eurjpy_hist_data['open']
        del self.eurjpy_hist_data['high']
        del self.eurjpy_hist_data['low']

        self.usdjpy_hist_data = hist.get_historical_pair_data_pandas('usdjpy', from_datetime, to_datetime )
        # self.usdjpy_hist_data['close_usdjpy'] = self.usdjpy_hist_data['close']
        self.usdjpy_hist_data['macd_usdjpy'] = ti.macd(self.usdjpy_hist_data.close, 12, 26)
        self.usdjpy_hist_data['rsi_usdjpy'] = ti.rsi_ema(self.usdjpy_hist_data.close, 10)
        self.usdjpy_hist_data['momentum_usdjpy'] = ti.momentum(self.usdjpy_hist_data.close, 4)
        del self.usdjpy_hist_data['close']
        del self.usdjpy_hist_data['open']
        del self.usdjpy_hist_data['high']
        del self.usdjpy_hist_data['low']

        self.gbpusd_hist_data = hist.get_historical_pair_data_pandas('gbpusd', from_datetime, to_datetime )
        # self.gbpusd_hist_data['close_gbpusd'] = self.gbpusd_hist_data['close']
        self.gbpusd_hist_data['macd_gbpusd'] = ti.macd(self.gbpusd_hist_data.close, 12, 26)
        self.gbpusd_hist_data['rsi_gbpusd'] = ti.rsi_ema(self.gbpusd_hist_data.close, 10)
        self.gbpusd_hist_data['momentum_gbpusd'] = ti.momentum(self.gbpusd_hist_data.close, 4)
        del self.gbpusd_hist_data['close']
        del self.gbpusd_hist_data['open']
        del self.gbpusd_hist_data['high']
        del self.gbpusd_hist_data['low']

        self.xauusd_hist_data = hist.get_historical_pair_data_pandas('xauusd', from_datetime, to_datetime )
        # self.xauusd_hist_data['close_xauusd'] = self.xauusd_hist_data['close']
        self.xauusd_hist_data['macd_xauusd'] = ti.macd(self.xauusd_hist_data.close, 12, 26)
        self.xauusd_hist_data['rsi_xauusd'] = ti.rsi_ema(self.xauusd_hist_data.close, 10)
        self.xauusd_hist_data['momentum_xauusd'] = ti.momentum(self.xauusd_hist_data.close, 4)
        del self.xauusd_hist_data['close']
        del self.xauusd_hist_data['open']
        del self.xauusd_hist_data['high']
        del self.xauusd_hist_data['low']

        self.eurusd_hist_data['ma'] = ti.ma(self.eurusd_hist_data.close, 10)
        self.eurusd_hist_data['macd'] = ti.macd(self.eurusd_hist_data.close, 12, 26)
        self.eurusd_hist_data['roc'] = ti.roc(self.eurusd_hist_data.close, 2)
        self.eurusd_hist_data['momentum'] = ti.momentum(self.eurusd_hist_data.close, 4)
        self.eurusd_hist_data['rsi'] = ti.rsi_ema(self.eurusd_hist_data.close, 10)
        self.eurusd_hist_data['bb_upper'], self.eurusd_hist_data['bb_lower'] = ti.bb(self.eurusd_hist_data.close, 20, 2)
        self.eurusd_hist_data['cci'] = ti.cci(self.eurusd_hist_data.high, self.eurusd_hist_data.low, self.eurusd_hist_data.close, 20)
        # del self.eurusd_hist_data['open']
        # del self.eurusd_hist_data['high']
        # del self.eurusd_hist_data['low']

        self.first_valid_idex = 26

        self.hist_data = self.eurusd_hist_data.merge(self.usdchf_hist_data, left_on='timestamp', right_on='timestamp')
        self.hist_data = self.hist_data.merge(self.eurjpy_hist_data, left_on='timestamp', right_on='timestamp')
        self.hist_data = self.hist_data.merge(self.usdjpy_hist_data, left_on='timestamp', right_on='timestamp')
        self.hist_data = self.hist_data.merge(self.gbpusd_hist_data, left_on='timestamp', right_on='timestamp')
        self.hist_data = self.hist_data.merge(self.xauusd_hist_data, left_on='timestamp', right_on='timestamp')
        self.hist_data = self.hist_data[self.first_valid_idex:].reset_index(drop=True)

        print(self.hist_data[-1:])

        self.hist_data_np = np.array([
            self.hist_data.close.to_list(),
            self.hist_data.ma.to_list(),
            self.hist_data.macd.to_list(),
            self.hist_data.roc.to_list(),
            self.hist_data.momentum.to_list(),
            self.hist_data.rsi.to_list(),
            self.hist_data.bb_upper.to_list(),
            self.hist_data.bb_lower.to_list(),
            self.hist_data.cci.to_list(),
            self.hist_data.macd_usdchf.to_list(),
            self.hist_data.rsi_usdchf.to_list(),
            self.hist_data.momentum_usdchf.to_list(),
            self.hist_data.macd_eurjpy.to_list(),
            self.hist_data.rsi_eurjpy.to_list(),
            self.hist_data.momentum_eurjpy.to_list(),
            self.hist_data.macd_usdjpy.to_list(),
            self.hist_data.rsi_usdjpy.to_list(),
            self.hist_data.momentum_usdjpy.to_list(),
            self.hist_data.macd_gbpusd.to_list(),
            self.hist_data.rsi_gbpusd.to_list(),
            self.hist_data.momentum_gbpusd.to_list(),
            self.hist_data.macd_xauusd.to_list(),
            self.hist_data.rsi_xauusd.to_list(),
            self.hist_data.momentum_xauusd.to_list(),
        ], dtype=np.float32)

        # ma = ti.ma(self.hist_data.close[self.first_valid_idex:], prediction_window)
        # ma = np.array(ma.to_list()[prediction_window:])
        # ma = ma - self.hist_data_np[0, :-prediction_window]
        # ma = -ma
        close = self.hist_data.close
        max_diff = np.array(close.rolling(window=prediction_steps, min_periods=prediction_steps).max()[prediction_steps:].to_list()) - np.array(close[:-prediction_steps].to_list())
        min_diff = np.array(close.rolling(window=prediction_steps, min_periods=prediction_steps).min()[prediction_steps:].to_list()) - np.array(close[:-prediction_steps].to_list())

        resolution = 25

        for i in range(resolution+1):
            if i == 0:
                long = np.logical_and(max_diff >= min_profit, min_diff >= -max_loss*math.pow(i/float(resolution), 0.6)).astype(float)
                short = np.logical_and(min_diff <= -min_profit, max_diff <= max_loss*math.pow(i/float(resolution), 0.6)).astype(float)
            else:
                # print(max_loss*math.pow(i/float(resolution), 0.6))
                # print(long[5000:5300])
                long += np.logical_and(max_diff >= min_profit, min_diff >= -max_loss*math.pow(i/float(resolution), 0.6)).astype(float)
                short += np.logical_and(min_diff <= -min_profit, max_diff <= max_loss*math.pow(i/float(resolution), 0.6)).astype(float)

        long = long/(resolution+1)
        short = short/(resolution+1)
        # short = 0*short

        # print(max_diff)
        # print(min_diff)
        # raise
        self.prediction_np = np.array([
            long,
            short,
            1.0 - (long+short),
        ])
        # print(long, short)
        # self.prediction_np = 1*short + 2*np.logical_and(~long, ~short)
        self.prediction_np = np.swapaxes(self.prediction_np, 0, 1)

        # print(self.prediction_np[5000:5300])
        # print(self.prediction_np[2000:2300])
        # # # print(ma[600: 800])
        # # plotter.plot_candles('test', self.hist_data[5000:5300].reset_index(drop=True))
        # #
        # raise

        self.hist_data_np = np.swapaxes(self.hist_data_np, 0, 1)
        np.nan_to_num(self.hist_data_np, nan=0, posinf=0, neginf=0)

        #
        # print(self.hist_data)
        # print(self.hist_data_np)
        # print(self.hist_data_np.shape)
    def generateBatches(self, batch_counts, batch_size, input_period=720, predict_period=360, cuda=True):
        batch_list = []
        hist_data = self.hist_data_np
        prediction_np = self.prediction_np
        for i in range(batch_counts):
            inputs = []
            labels = []

            j = 0
            up_counts = 0
            down_counts = 0
            while j < batch_size:
                randomed_index = random.randint(0, hist_data.shape[0] - (input_period + self.prediction_steps))

                input = hist_data[randomed_index:randomed_index+input_period, :]
                # label = prediction_np[randomed_index:randomed_index+input_period]
                label = prediction_np[randomed_index+input_period-1:randomed_index+input_period]
                # print(input, label)
                # raise
                # print(input.shape, label.shape)
                if label[0, 0] > 0.9:
                # if label[-1] == 0:
                    if up_counts > 0.35 * batch_size:
                        continue
                    # plotter.plot_candles('up', self.hist_data[randomed_index+input_period-1:randomed_index+input_period+self.prediction_steps].reset_index(drop=True))

                    up_counts += 1

                elif label[0, 1] > 0.9:
                # elif label[-1] == 1:
                    if down_counts > 0.35 * batch_size:
                        continue
                    # plotter.plot_candles('down', self.hist_data[randomed_index+input_period-1:randomed_index+input_period+self.prediction_steps].reset_index(drop=True))
                    down_counts += 1
                else:
                    if j % 3 != 0 and (up_counts + down_counts) < 0.65 * batch_size:
                        continue
                inputs.append(input)
                labels.append(label)
                j += 1
                # for k in range(input_period):
                #     # inputs[k].append(input[k])
                #     # print(k+prediction_window)
                #     labels[k].append(label[k: k+prediction_window])
            inputs = torch.tensor(inputs, dtype=torch.float32)
            # inputs = torch.swapaxes(inputs, 0, 1)
            labels = torch.tensor(labels, dtype=torch.float32)
            # labels = torch.swapaxes(labels, 0, 1)

            if cuda:
                inputs = inputs.cuda()
                labels = labels.cuda()

            batch_list.append([inputs, labels])

        return batch_list
