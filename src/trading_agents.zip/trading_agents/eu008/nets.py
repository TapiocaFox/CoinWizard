#!/usr/bin/python3

import torch, math
import torch.nn as nn
from trading_agents.eu008.informer.model import GranularityInformer

class EuNet(nn.Module):
    def __init__(self):
        super(EuNet, self).__init__()
        self.decode_predict_len = 48
        self.informer = GranularityInformer([6, 6, 6, 6], 6, 2, self.decode_predict_len, factor=5, e_layers=2, d_layers=3, dropout=0.1, d_model=512, d_ff=2048, embed='timeF', freq='t')

    def forward(self, encode_input, encode_time, decode_input, decode_time):
        x = self.informer(encode_input, encode_time, decode_input, decode_time)
        return x
