#!/usr/bin/python3

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math
import coin_wizard.historical_pair_data as hist
from trading_agents.hb001.train_utils import generate_training_batches, calc_confusion_matrix, to_gasf
from trading_agents.hb001.nets import HbNet
import matplotlib.pyplot as plt
import coin_wizard.plotter as plotter


import pytz, time
utc = pytz.utc
from datetime import datetime

# selected_net = 'HB_2021_03_18_17_46.net'
selected_net = 'backup.net'

cuda_enabled = True
test_batch_size = 512
output_counts = 3


class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 1
        self.net = None
        self.move_avg_list = [None, None]
        self.position = 2

    def _every_15_second_loop(self, BrokerAPI):
        if self.every_15_second_loop_count%4 == 0:
            recent_candles_df = self.eurusd_inst.getRecent1MCandles(62)
            recent_candles_mtx = np.array([
                recent_candles_df['open'].tolist(),
                recent_candles_df['high'].tolist(),
                recent_candles_df['low'].tolist(),
                recent_candles_df['close'].tolist()
            ])
            gasf = np.array([to_gasf(recent_candles_mtx)])
            gasf = torch.from_numpy(gasf)
            gasf = torch.tensor(gasf, dtype=torch.float32)
            outputs = self.net(gasf)
            output = outputs[0][0]
            output = output.item()
            # if output > 0:
            #     output = math.sqrt(output)
            # else:
            #     output = -math.sqrt(-output)

            if self.position == 2:
                if output > 0.0018:
                    print('buy')
                elif output < -0.0018:
                    print('sell')

            elif self.position == 0:
                pass
            elif self.position == 1:
                pass
            print(output/0.0001)
            # output = outputs[0]
            # mv_avg_sum = outputs[0].clone()
            # for i in range(len(self.move_avg_list)-1):
            #     self.move_avg_list[i] = self.move_avg_list[i+1]
            #     if self.move_avg_list[i]!= None:
            #         mv_avg_sum += self.move_avg_list[i]
            # self.move_avg_list[-1] = output
            # # print(mv_avg_sum)
            #
            # mv_avg = mv_avg_sum / len(self.move_avg_list)
            # print(mv_avg)
            # print(self.move_avg_list)
            plotter.plot_candles('recent_candles', recent_candles_df)
        self.every_15_second_loop_count += 1


    def run(self, BrokerAPI):
        net = HbNet()
        net.load_state_dict(torch.load(self.agent_directory+'/'+selected_net))
        net.eval()
        self.net = net
        BrokerAPI.onEvery15Second(self._every_15_second_loop)
        self.eurusd_inst = BrokerAPI.getInstrument('EUR_USD')

    def stop_running(self, BrokerAPI):
        pass

    def train(self, BrokerAPI):
        nsp = BrokerAPI.getNotificationServiceProvider()
        nsp.pushImmediately('Training', 'HB001')

        offset = 240

        training_batches = generate_training_batches('eurusd', utc.localize(datetime(2015, 1, 1, 0, 0)), utc.localize(datetime(2020, 11, 29, 23, 59)), batch_counts = 64, batch_size = 512, cuda = cuda_enabled)
        test_batches = generate_training_batches('eurusd', utc.localize(datetime(2020, 12, 1, 0, 0)), utc.localize(datetime(2021, 4, 8, 23, 59)), batch_counts = 1, batch_size = test_batch_size, cuda = cuda_enabled)

        test_batch = test_batches[0]
        test_inputs, test_labels = test_batch

        # net = HbNet()
        # net.load_state_dict(torch.load(self.agent_directory+'/'+selected_net))
        # net.eval()
        net = HbNet()
        if cuda_enabled:
            print(net.cuda())

        # criterion = nn.CrossEntropyLoss()
        criterion = nn.MSELoss()
        # criterion_mae = nn.L1Loss()

        # optimizer = optim.RMSprop(net.parameters())

        # optimizer = optim.SGD(net.parameters(), lr=0.01, momentum=0.9)
        # optimizer = optim.Adam(net.parameters(), lr=0.01)
        # optimizer = optim.Adam(net.parameters(), lr=0.001)

        optimizer = optim.Adam(net.parameters(), lr=0.0002)
        # optimizer = optim.Adam(net.parameters(), lr=0.0001)
        # optimizer = optim.Adam(net.parameters(), lr=0.00001)
        # optimizer = optim.Adam(net.parameters(), lr=0.0000001)
        # optimizer = optim.Adam(net.parameters(), lr=0.000003)
        # optimizer = optim.Adam(net.parameters(), lr=0.000004)
        # optimizer = optim.Adam(net.parameters(), lr=0.0000008)
        # optimizer = optim.Adam(net.parameters(), lr=0.00000065)
        # optimizer = optim.Adam(net.parameters(), lr=0.0000004)
        # optimizer = optim.Adam(net.parameters(), lr=0.000001)
        # optimizer = optim.Adam(net.parameters(), lr=0.0000001)

        # for epoch in range(1):  # loop over the dataset multiple times
        # for epoch in range(32):  # loop over the dataset multiple times
        for epoch in range(128):  # loop over the dataset multiple times
        # for epoch in range(128*4):  # loop over the dataset multiple times
        # for epoch in range(128*8):  # loop over the dataset multiple times

        # for epoch in range(128*24):  # loop over the dataset multiple times
        # for epoch in range(128*32):  # loop over the dataset multiple times
            if (epoch-1)%32 == 31 and epoch != 0:
                torch.save(net.state_dict(), self.agent_directory+datetime.now().strftime("/backup.net"))

                del training_batches
                # print('Sleeping(too hot)...')
                # time.sleep(75)
                training_batches = generate_training_batches('eurusd', utc.localize(datetime(2015, 1, 1, 0, 0)), utc.localize(datetime(2020, 11, 29, 23, 59)), batch_counts = 64, batch_size = 512, cuda = cuda_enabled)
                print('Training batches updated.')

            running_loss = 0.0
            running_test_loss = 0.0
            for i, training_batch in enumerate(training_batches):
                # get the inputs; data is a list of [inputs, labels]
                inputs, labels = training_batch
                # print(labels)
                # print(inputs, labels, inputs.shape, labels.shape)
                # raise
                # zero the parameter gradients
                optimizer.zero_grad()

                # forward + backward + optimize120*14
                outputs = net(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                test_outputs = net(test_inputs)
                test_loss = criterion(test_outputs, test_labels)

                running_loss += loss.item()
                running_test_loss += test_loss.item()

                if i % 64 == 63:    # print every 2000 mini-batches
                    print('[%d, %5d] Loss: %.10f, %.5f   Test loss: %.10f, %.5f' % (epoch + 1, i + 1, running_loss/64, math.sqrt(running_loss/64), running_test_loss/64, math.sqrt(running_test_loss/64)))
                    if (epoch-1) % 128 == 127 and i == 63:
                        nsp.pushImmediately('Traing loss', '[%d, %5d] Loss: %.10f Test loss: %.10f' % (epoch + 1, i + 1, running_loss / 64, running_test_loss / 64))
                        nsp.pushImmediately('Traing loss', '[%d, %5d] Loss: %.10f Test loss: %.10f' % (epoch + 1, i + 1, running_loss / 64, running_test_loss / 64))
                    running_loss = 0.0
                    running_test_loss = 0.0
        # net.cpu()

        # outputs = net(test_inputs)

        # print('\n===answers===')
        # print(test_labels)
        # print('\n===outputs===')
        # print(outputs)
        # print('\n===same trends or not===')
        # # answer_max_value, answer_max_indices = torch.max(test_labels, 1)
        # output_max_value, output_max_indices = torch.max(outputs, 1)
        #
        # # print(answer_max_indices)
        # print(output_max_indices)
        # # print(answer_max_value)
        # print(output_max_value)
        # t_trend = torch.eq(test_labels, output_max_indices)
        # print(t_trend)
        # # t_trend = torch.eq(answer_max_indices, output_max_indices)
        # counts = torch.sum(t_trend.int()).item()
        # print(' accuracy:', counts/test_batch_size)
        # nsp.pushImmediately('Train accuracy', str(counts/test_batch_size))
        # print('\n===confusion matrix===')
        # m = calc_confusion_matrix(test_labels, output_max_indices, 3)
        # print(m)
        # plt.matshow(m)
        # plt.colorbar()
        # plt.show()


        print(self.agent_directory+datetime.now().strftime("/HB_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory+datetime.now().strftime("/HB_%Y_%m_%d_%H_%M.net"))
        del net

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        self.run(BacktestBrokerAPI)

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
