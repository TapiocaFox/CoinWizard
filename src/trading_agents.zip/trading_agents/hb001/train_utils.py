#!/usr/bin/python3

import torch
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt

from datetime import datetime, timedelta
import coin_wizard.historical_pair_data as hist

import coin_wizard.plotter as plotter

time_delta_7_days = timedelta(days=7)


def calc_confusion_matrix(answers, outputs, labels_length):
    answers = answers.tolist()
    outputs = outputs.tolist()
    array = np.zeros((labels_length, labels_length))
    for i, item in enumerate(answers):
        array[item, outputs[i]] += 1

    # print(array)
    # print(np.sum(array, axis=1))
    array = array / np.sum(array, axis=1)[:, None]
    return array


def to_gasf(mtx):

    mtx = np.array([
        mtx[1] - np.maximum(mtx[0], mtx[3]),
        np.maximum(mtx[0], mtx[3]) - np.minimum(mtx[0], mtx[3]),
        np.minimum(mtx[0], mtx[3]) - mtx[2],
        mtx[3],
    ])

    np.nan_to_num(mtx, nan=0, posinf=0, neginf=0)
    # print(mtx)
    max = np.max(mtx, 1)
    min = np.min(mtx, 1)
    mtx = mtx - min[:, None]
    mtx = mtx / (max[:, None] - min[:, None])
    # print(mtx)
    mtx = mtx[:, None, :] * mtx[:, :, None]

    # plt.matshow(mtx[0])
    # plt.colorbar()
    # plt.show()
    # plt.matshow(mtx[1])
    # plt.colorbar()
    # plt.show()
    # plt.matshow(mtx[2])
    # plt.colorbar()
    # plt.show()
    # plt.matshow(mtx[3])
    # plt.colorbar()
    # plt.show()

    # while True:
    #     pass
    # raise
    return mtx
# Yeh Trapzoid Index


def generate_training_batches_yti(pair, from_datetime, to_datetime, batch_counts=128, batch_size=512, input_length=62, yeh_n=20, yeh_m=10, yti_threshold=0.00185, cuda=False):
    hist_data = hist.get_historical_pair_data(
        pair, from_datetime, to_datetime + time_delta_7_days)
    df = pd.DataFrame(hist_data)
    df['utc_timestamp'] = pd.DatetimeIndex(pd.to_datetime(
        df['utc_timestamp'], unit='s')).tz_localize('UTC')
    df = df.rename(columns={'utc_timestamp': 'timestamp'})

    hist_data = hist_data.view((np.double, 5))
    hist_data = np.delete(hist_data, 0, 1)
    hist_data = np.swapaxes(hist_data, 0, 1)

    hist_data_len = hist_data.shape[1]
    batch_list = []

    yeh_n_m = yeh_m + yeh_n

    for i in range(batch_counts):
        inputs = []
        labels = []

        i_shape = None
        j = 0
        up_counts = 0
        down_counts = 0
        while j < batch_size:
            randomed_index = random.randint(
                0, hist_data_len - (input_length + yeh_n_m))
            input = hist_data[:, randomed_index:randomed_index + input_length]

            yti_label = 0
            # raise
            after_anchor_index = randomed_index + input_length
            anchor = input[3][-1]

            n_candles = hist_data[:,
                                  after_anchor_index: after_anchor_index + yeh_n]
            m_candles = hist_data[:, after_anchor_index +
                                  yeh_n: after_anchor_index + yeh_n + yeh_m]

            n_candles = (n_candles[0] + n_candles[3]) / 2
            m_candles = (m_candles[0] + m_candles[3]) / 2

            n_candles = n_candles - anchor
            m_candles = m_candles - anchor

            y_number = np.mean(m_candles)
            y_number_abs = np.absolute(y_number)

            if y_number > 0:
                yeh_area = (y_number_abs * yeh_m + np.sum(n_candles)
                            ) / (y_number_abs * (yeh_n_m / 2))
            else:
                yeh_area = (y_number_abs * yeh_m - np.sum(n_candles)
                            ) / (y_number_abs * (yeh_n_m / 2))

            np.nan_to_num(yeh_area, nan=0, posinf=0, neginf=0)
            yeh_area = max(yeh_area, 0)
            yeh_area = min(yeh_area, 1.25)

            yti = y_number * yeh_area

            if j % 3 != 0:
                if yti > yti_threshold:
                    if up_counts > 0.38 * batch_size:
                        continue

                    up_counts += 1
                elif yti < -yti_threshold:
                    if down_counts > 0.38 * batch_size:
                        continue

                    down_counts += 1
                else:
                    continue

            # print(yti_label)
            # print(y_number)
            # print(anchor)
            # print(yeh_area)
            # print(n_candles)
            # print(m_candles)
            # plotter.plot_candles('YTI', df[after_anchor_index:after_anchor_index+yeh_n+yeh_m].reset_index(drop=True))
            #
            # raise
            inputs.append(to_gasf(input))
            labels.append(np.array([yti_label]))
            j += 1

        inputs = np.array(inputs)
        inputs = torch.from_numpy(inputs)
        inputs = torch.tensor(inputs, dtype=torch.float32)
        # print(labels)
        labels = np.array(labels)
        # print(labels.shape)
        labels = torch.from_numpy(labels)
        labels = torch.tensor(labels, dtype=torch.float32)

        if cuda:
            # print(123)
            inputs = inputs.cuda()
            labels = labels.cuda()

        batch_list.append([inputs, labels])

    return batch_list

# Yeh Trapzoid Index


def generate_training_batches_2(pair, from_datetime, to_datetime, batch_counts=128, batch_size=512, input_length=482, yeh_n=30, yeh_m=180, yti_threshold=0.0012, cuda=False):
    hist_data = hist.get_historical_pair_data(
        pair, from_datetime, to_datetime + time_delta_7_days)
    df = pd.DataFrame(hist_data)
    df['utc_timestamp'] = pd.DatetimeIndex(pd.to_datetime(
        df['utc_timestamp'], unit='s')).tz_localize('UTC')
    df = df.rename(columns={'utc_timestamp': 'timestamp'})
    macd = df.close.ewm(span=12).mean() - df.close.ewm(span=26).mean()
    signal = macd.ewm(span=9).mean()
    df['macd_diff'] = macd - signal
    macd_np = macd.to_numpy()
    macd_diff_np = df['macd_diff'].to_numpy()

    # print(macd_diff_np)
    # macd
    # raise
    hist_data = hist_data.view((np.double, 5))
    hist_data = np.delete(hist_data, 0, 1)
    hist_data = np.swapaxes(hist_data, 0, 1)

    hist_data_len = hist_data.shape[1]
    batch_list = []

    yeh_n_m = yeh_m + yeh_n

    base_confidence = 0.6

    for i in range(batch_counts):
        inputs = []
        labels = []

        i_shape = None
        j = 0
        up_counts = 0
        down_counts = 0
        while j < batch_size:
            randomed_index = random.randint(
                0, hist_data_len - (input_length + yeh_n_m))
            input = hist_data[:, randomed_index:randomed_index + input_length]

            yti_label = 0
            # raise
            after_anchor_index = randomed_index + input_length
            anchor = input[3][-1]

            n_candles = hist_data[:,
                                  after_anchor_index: after_anchor_index + yeh_n]
            m_candles = hist_data[:, after_anchor_index +
                                  yeh_n: after_anchor_index + yeh_n + yeh_m]

            n_candles = (n_candles[0] + n_candles[3]) / 2
            m_candles = (m_candles[0] + m_candles[3]) / 2

            n_candles = n_candles - anchor
            m_candles = m_candles - anchor

            y_number = np.mean(m_candles)
            y_number_abs = np.absolute(y_number)

            if y_number > 0:
                yeh_area = (y_number_abs * yeh_m + np.sum(n_candles)
                            ) / (y_number_abs * (yeh_n_m / 2))
            else:
                yeh_area = (y_number_abs * yeh_m - np.sum(n_candles)
                            ) / (y_number_abs * (yeh_n_m / 2))

            np.nan_to_num(yeh_area, nan=0, posinf=0, neginf=0)
            yeh_area = max(yeh_area, 0)
            yeh_area = min(yeh_area, 1.25)

            yti = y_number * yeh_area

            # label = [1, 0, 0]
            label = None

            if yti > yti_threshold and y_number > yti_threshold:
                if up_counts > 0.35 * batch_size:
                    continue

                result = min(base_confidence * yti / yti_threshold, 1)
                # plotter.plot_candles('up', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                label = [result, 0, 1 - result]
                # label = 0
                up_counts += 1
            elif yti < -yti_threshold and y_number < -yti_threshold:
                if down_counts > 0.35 * batch_size:
                    continue
                result = min(-base_confidence * yti / yti_threshold, 1)
                # plotter.plot_candles('down', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                label = [0, result, 1 - result]
                # label = 1
                down_counts += 1
            else:
                if j % 3 != 0 and (up_counts + down_counts) < 0.6 * batch_size:
                    continue
                # plotter.plot_candles('mid', df[randomed_index:randomed_index+input_length].reset_index(drop=True))

                yti_pow = min(abs(yti), abs(y_number)) / yti_threshold
                yti_pow = base_confidence * pow(yti_pow, 3)

                if yti >= 0:
                    label = [yti_pow, 0, 1 - yti_pow]
                else:
                    label = [0, yti_pow, 1 - yti_pow]
                # label = 2

            # print(yti)
            # print(y_number)
            # print(anchor)
            # print(yeh_area)
            # print(n_candles)
            # print(m_candles)
            # plotter.plot_candles('YTI', df[after_anchor_index:after_anchor_index+yeh_n+yeh_m].reset_index(drop=True))
            #
            # raise
            upper_shadow = input[1] - np.maximum(input[0], input[3])
            body = np.maximum(input[0], input[3]) - np.minimum(input[0], input[3])
            # body = input[3] - input[0]
            lower_shadow = np.minimum(input[0], input[3]) - input[2]
            closed = input[3]
            # macd_diff_ = macd_diff_np[randomed_index:randomed_index + input_length]
            # macd_ = macd_np[randomed_index:randomed_index + input_length]

            # Regularize
            # upper_shadow = (upper_shadow - np.amin(upper_shadow)) / (np.amax(upper_shadow) - np.amin(upper_shadow))
            upper_shadow = upper_shadow / yti_threshold
            # body = (body - np.amin(body)) / (np.amax(body) - np.amin(body))
            body = body / yti_threshold
            # lower_shadow = (lower_shadow - np.amin(lower_shadow)) / (np.amax(lower_shadow) - np.amin(lower_shadow))
            lower_shadow = lower_shadow / yti_threshold
            closed = (closed - np.amin(closed)) / yti_threshold
            # macd_diff_ = macd_diff_ / yti_threshold
            # macd_ = macd_ / yti_threshold

            input = np.array([
                upper_shadow,
                body,
                lower_shadow,
                closed,
                # macd_diff_,
                # macd_
            ])
            # input = (input - np.amin(input, axis = 1)[:, None])/(np.amax(input, axis = 1) - np.amin(input, axis = 1))[:, None]
            inputs.append(input)
            labels.append(label)
            j += 1

        inputs = np.array(inputs)
        inputs = torch.from_numpy(inputs)
        inputs = torch.tensor(inputs, dtype=torch.float32)
        # print(labels)
        labels = np.array(labels)
        # print(labels.shape)
        labels = torch.from_numpy(labels)
        labels = torch.tensor(labels, dtype=torch.float32)
        # labels = torch.tensor(labels, dtype=torch.long)

        if cuda:
            # print(123)
            inputs = inputs.cuda()
            labels = labels.cuda()

        batch_list.append([inputs, labels])

    return batch_list

# Yeh Trapzoid Index


def generate_training_batches(pair, from_datetime, to_datetime, batch_counts=128, batch_size=512, input_length=62, yeh_n=20, yeh_m=10, yti_threshold=0.00185, cuda=False):
    hist_data = hist.get_historical_pair_data(
        pair, from_datetime, to_datetime + time_delta_7_days)
    df = pd.DataFrame(hist_data)
    df['utc_timestamp'] = pd.DatetimeIndex(pd.to_datetime(
        df['utc_timestamp'], unit='s')).tz_localize('UTC')
    df = df.rename(columns={'utc_timestamp': 'timestamp'})

    hist_data = hist_data.view((np.double, 5))
    hist_data = np.delete(hist_data, 0, 1)
    hist_data = np.swapaxes(hist_data, 0, 1)

    hist_data_len = hist_data.shape[1]
    batch_list = []

    yeh_n_m = yeh_m + yeh_n

    for i in range(batch_counts):
        inputs = []
        labels = []

        i_shape = None
        j = 0
        up_counts = 0
        down_counts = 0
        while j < batch_size:
            randomed_index = random.randint(
                0, hist_data_len - (input_length + yeh_n_m))
            input = hist_data[:, randomed_index:randomed_index + input_length]

            yti_label = 0
            # raise
            after_anchor_index = randomed_index + input_length
            anchor = input[3][-1]

            n_candles = hist_data[:,
                                  after_anchor_index: after_anchor_index + yeh_n]
            m_candles = hist_data[:, after_anchor_index +
                                  yeh_n: after_anchor_index + yeh_n + yeh_m]

            n_candles = (n_candles[0] + n_candles[3]) / 2
            m_candles = (m_candles[0] + m_candles[3]) / 2

            n_candles = n_candles - anchor
            m_candles = m_candles - anchor

            y_number = np.mean(m_candles)
            y_number_abs = np.absolute(y_number)

            if y_number > 0:
                yeh_area = (y_number_abs * yeh_m + np.sum(n_candles)
                            ) / (y_number_abs * (yeh_n_m / 2))
            else:
                yeh_area = (y_number_abs * yeh_m - np.sum(n_candles)
                            ) / (y_number_abs * (yeh_n_m / 2))

            np.nan_to_num(yeh_area, nan=0, posinf=0, neginf=0)
            yeh_area = max(yeh_area, 0)
            yeh_area = min(yeh_area, 1.25)

            yti_label = y_number * yeh_area

            label = 0

            if yti_label > yti_threshold:
                if up_counts > 0.38 * batch_size:
                    continue
                # plotter.plot_candles('up', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                label = 0
                up_counts += 1
            elif yti_label < -yti_threshold:
                if down_counts > 0.38 * batch_size:
                    continue
                # plotter.plot_candles('down', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                label = 1
                down_counts += 1
            else:
                if j % 3 != 0:
                    continue
                # plotter.plot_candles('mid', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                label = 2

            # print(yti_label)
            # print(y_number)
            # print(anchor)
            # print(yeh_area)
            # print(n_candles)
            # print(m_candles)
            # plotter.plot_candles('YTI', df[after_anchor_index:after_anchor_index+yeh_n+yeh_m].reset_index(drop=True))
            #
            # raise
            inputs.append(to_gasf(input))
            labels.append(label)
            j += 1

        inputs = np.array(inputs)
        inputs = torch.from_numpy(inputs)
        inputs = torch.tensor(inputs, dtype=torch.float32)
        # print(labels)
        labels = np.array(labels)
        # print(labels.shape)
        labels = torch.from_numpy(labels)
        labels = torch.tensor(labels, dtype=torch.long)

        if cuda:
            # print(123)
            inputs = inputs.cuda()
            labels = labels.cuda()

        batch_list.append([inputs, labels])

    return batch_list


# 50 pip
def generate_training_batches_new_old(pair, from_datetime, to_datetime, batch_counts=128, batch_size=512, input_length=62, after_n_min=20, move_threshold=0.00185, cuda=False):
    hist_data = hist.get_historical_pair_data(
        pair, from_datetime, to_datetime + time_delta_7_days)
    df = pd.DataFrame(hist_data)
    df['utc_timestamp'] = pd.DatetimeIndex(pd.to_datetime(
        df['utc_timestamp'], unit='s')).tz_localize('UTC')
    df = df.rename(columns={'utc_timestamp': 'timestamp'})
    hist_data = hist_data.view((np.double, 5))
    hist_data = np.delete(hist_data, 0, 1)
    hist_data = np.swapaxes(hist_data, 0, 1)

    # hist_data = 10000*hist_data
    # hist_data = hist_data.astype(np.double)

    hist_data_len = hist_data.shape[1]

    batch_list = []

    for i in range(batch_counts):
        inputs = []
        labels = []

        i_shape = None
        j = 0
        up_counts = 0
        down_counts = 0
        while j < batch_size:
            randomed_index = random.randint(
                0, hist_data_len - (input_length + after_n_min))
            input = hist_data[:, randomed_index:randomed_index + input_length]
            # raise
            closed_price = input[3][-1]
            # print(latest_closed, input)

            label = []
            after_n_min_closed_price = hist_data[3][randomed_index +
                                                    input_length + after_n_min - 1]
            after_1_min_closed_price = hist_data[3][randomed_index + input_length]
            # print(after_1_min_closed_price-closed_price)
            # Check proceed growth

            proceed = after_1_min_closed_price - closed_price
            # before = after_1_min_closed_price
            for k in range(7):
                candle = hist_data[:, randomed_index + input_length + k + 1]
                # print(candle)
                # print(proceed, after-before)
                if (candle[3] - candle[0]) * proceed < 0 and abs(candle[3] - candle[0]) > 0.00022:
                    proceed = 0
                    break

                if (candle[3] - candle[0]) * proceed > 0 and abs(candle[3] - candle[0]) < 0.000025:
                    proceed = 0
                    break
                # elif (after-before)*proceed > 0 and abs(after-before)<0.00003:
                #     proceed = 0
                #     break
                # before = after

            # if j%2 != 0:
            #     if (input[3][-1] - input[0][-1])*proceed < 0 or abs(input[3][-1] - input[0][-1]) >0.0002:
            #         proceed = 0
            #
            #     if (input[3][-2] - input[0][-2])*proceed < 0 or abs(input[3][-2] - input[0][-2])<0.0001:
            #         proceed = 0

            if after_n_min_closed_price - closed_price >= move_threshold and proceed > 0:
                if up_counts > 0.38 * batch_size:
                    continue
                # print('up')
                # plotter.plot_candles('up', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                # to_gasf(input)
                # label = [1, 0, 0]
                # print(df[randomed_index:randomed_index+input_length+after_n_min])
                # # raise
                # plotter.plot_candles('up pre', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                # plotter.plot_candles('up', df[randomed_index+input_length:randomed_index+input_length+after_n_min].reset_index(drop=True))
                label = 0
                up_counts += 1
            elif after_n_min_closed_price - closed_price <= -move_threshold and proceed < 0:
                if down_counts > 0.38 * batch_size:
                    continue
                # print('down')
                # plotter.plot_candles('down pre', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                # plotter.plot_candles('down', df[randomed_index+input_length:randomed_index+input_length+after_n_min].reset_index(drop=True))
                # to_gasf(input)

                # label = [0, 1, 0]
                label = 1
                down_counts += 1
            else:
                if j % 3 != 0:
                    continue
                # label = [0, 0, 1]
                # plotter.plot_candles('mid pre', df[randomed_index:randomed_index+input_length].reset_index(drop=True))
                # plotter.plot_candles('mid', df[randomed_index+input_length:randomed_index+input_length+after_n_min].reset_index(drop=True))
                # print('mid')
                # to_gasf(input)
                label = 2

            inputs.append(to_gasf(input))
            labels.append(label)
            j += 1

        inputs = np.array(inputs)
        inputs = torch.from_numpy(inputs)
        inputs = torch.tensor(inputs, dtype=torch.float32)
        # print(labels)
        labels = np.array(labels)
        # print(labels.shape)
        labels = torch.from_numpy(labels)
        labels = torch.tensor(labels, dtype=torch.long)

        if cuda:
            # print(123)
            inputs = inputs.cuda()
            labels = labels.cuda()

        batch_list.append([inputs, labels])

    return batch_list


def generate_training_batches_old(pair, from_datetime, to_datetime, batch_counts=128, batch_size=512, input_length=4830, record_interval_min=240, record_counts=9, cuda=False):
    hist_data = hist.get_historical_pair_data(
        pair, from_datetime, to_datetime + time_delta_7_days)
    hist_data = hist_data.view((np.double, 5))
    hist_data = np.delete(hist_data, 0, 1)
    hist_data = np.swapaxes(hist_data, 0, 1)

    # hist_data = 10000*hist_data
    # hist_data = hist_data.astype(np.double)

    hist_data_len = hist_data.shape[1]

    batch_list = []

    for i in range(batch_counts):
        inputs = []
        labels = []

        i_shape = None
        for j in range(batch_size):
            randomed_index = random.randint(
                0, hist_data_len - (input_length + record_counts * record_interval_min))
            input = hist_data[:, randomed_index:randomed_index + input_length]
            # raise
            # latest_closed = input[3][-1]
            # print(latest_closed, input)

            label = []

            for i in range(record_counts):
                label.append(
                    hist_data[3][randomed_index + input_length + (i + 1) * record_interval_min - 1])
            # future_12hr_closed = hist_data[3][randomed_index+input_length+12*60-1]
            # # print(future_12hr_closed, hist_data[:, randomed_index+input_length:randomed_index+input_length+60])
            #
            # future_24hr_closed = hist_data[3][randomed_index+input_length+24*60-1]
            # # print(future_24hr_closed, hist_data[:, randomed_index+input_length:randomed_index+input_length+2*60])
            #
            # future_36hr_closed = hist_data[3][randomed_index+input_length+36*60-1]
            # # print(future_36hr_closed, hist_data[:, randomed_index+input_length:randomed_index+input_length+3*60])
            #
            # label = [future_12hr_closed, future_24hr_closed, future_36hr_closed]

            # raise

            # label = hist_data[:, randomed_index+input_length:randomed_index+input_length+]
            # print(input)
            # print(label)
            # if i_shape== None or i_shape != input.shape:
            #     print(input.shape)
            #     i_shape = input.shape
            # print(label.shape)
            inputs.append(input)
            labels.append(label)

        inputs = np.array(inputs)
        inputs = torch.from_numpy(inputs)
        inputs = torch.tensor(inputs, dtype=torch.float32)
        # print(labels)
        labels = np.array(labels)
        # print(labels.shape)
        labels = torch.from_numpy(labels)
        labels = torch.tensor(labels, dtype=torch.float32)

        if cuda:
            inputs = inputs.cuda()
            labels = labels.cuda()

        batch_list.append([inputs, labels])

    return batch_list
