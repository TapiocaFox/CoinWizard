#!/usr/bin/python3

from datetime import datetime
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math
import coin_wizard.historical_pair_data as hist
from trading_agents.hb001.train_utils import generate_training_batches_2, calc_confusion_matrix, to_gasf
from trading_agents.hb001.nets import HbNet, JvnNet
import matplotlib.pyplot as plt
import coin_wizard.plotter as plotter


import pytz
import time
utc = pytz.utc

# selected_net = 'JVN_2021_03_19_16_15.net'
selected_net = 'backup.net'
# selected_net = 'good.net'

cuda_enabled = True
test_batch_size = 512
train_batch_size = 2048*2
output_counts = 3
confidence_threshold = 0.8
yti_threshold = 0.0012
verbose = False
# verbose = True
macd_threshold = 0.00008
macd_diff_threshold = 0.00001
# macd_diff_close_threshold = 0.00001

win_rate_threshold = 0.5


class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 1
        self.net = None
        self.move_avg_list = [None, None]
        self.position = 2
        self.yeh_n = 30
        self.yeh_m = 180
        self.yeh_steps = 0
        self.total_yeh_steps = 0
        self.buy_cd = 0
        self.sell_cd = 0
        self.current_trade = None
        self.best_profit = 0
        self.dragged_long_conf = 0
        self.dragged_short_conf = 0
        self.max_macd_diff_abs = 0
        self.consider_to_close_trade = False

        self.buy_pl = 0
        self.buy_counts = 0
        self.sell_pl = 0
        self.sell_counts = 0

        self.confidence = 0.9

    def _order_canceled_listener(self, order, reason):
        self.position = 2
        self.yeh_steps = 0

    def _order_filled_listener(self, order, trade):
        self.current_trade = trade
        trade.onReduced(self._trade_reduced_listener)
        trade.onClosed(self._trade_closed_listener)

    def _trade_reduced_listener(self, trade, units, realized_pl, close_price, spread, timestamp):
        pass

    def _trade_closed_listener(self, trade, realized_pl, close_price, spread, timestamp):
        # print(self.yeh_steps, self.best_profit)
        print('Trade closed after %d yeh steps. Best profit: %.5f. PL:  %.5f. Max abs macd diff:  %.5f.' % (
            self.total_yeh_steps, self.best_profit, realized_pl, self.max_macd_diff_abs))
        self.position = 2
        self.yeh_steps = 0
        self.max_macd_diff_abs = 0
        self.total_yeh_steps = 0
        self.consider_to_close_trade = False
        if trade.getTradeSettings()['units'] > 0:
            self.buy_pl += realized_pl
            if realized_pl < 0:
                self.confidence -= 0.95*(self.confidence)
                self.confidence = max(self.confidence, confidence_threshold*1.05)
                # self.buy_cd = 0
                self.buy_cd = 30
                self.sell_cd = 0
            else:
                self.confidence += 0.1*(1 - self.confidence)
        else:
            self.sell_pl += realized_pl
            if realized_pl < 0:
                self.confidence -= 0.95*(self.confidence)
                self.confidence = max(self.confidence, confidence_threshold*1.05)
                # self.sell_cd = 0
                self.sell_cd = 30
                self.buy_cd = 0
            else:
                self.confidence += 0.1*(1 - self.confidence)

    def _every_15_second_loop(self, BrokerAPI):
        if not self.eurusd_inst.isTradable():
            return
        # raise
        if self.every_15_second_loop_count % 4 == 0:
            if self.buy_cd > 0:
                self.buy_cd -= 1
            if self.sell_cd > 0:
                self.sell_cd -= 1

            recent_candles_df = self.eurusd_inst.getRecent1MCandles(482)
            macd = recent_candles_df.close.ewm(span=12).mean(
            ) - recent_candles_df.close.ewm(span=26).mean()
            signal = macd.ewm(span=9).mean()
            recent_candles_df['macd_diff'] = macd - signal
            macd_np = macd.to_numpy()
            macd_diff_np = recent_candles_df['macd_diff'].to_numpy()
            # print(recent_candles_df['macd_diff'])
            # raise
            bid, ask, timestamp = self.eurusd_inst.getCurrentCloseoutBidAsk()
            input = np.array([
                recent_candles_df['open'].tolist(),
                recent_candles_df['high'].tolist(),
                recent_candles_df['low'].tolist(),
                recent_candles_df['close'].tolist()
            ])

            upper_shadow = input[1] - np.maximum(input[0], input[3])
            body = np.maximum(input[0], input[3]) - np.minimum(input[0], input[3])
            # body = input[3] - input[0]
            lower_shadow = np.minimum(input[0], input[3]) - input[2]
            closed = input[3]
            # macd_diff_ = macd_diff_np
            # macd_ = macd_np

            # Regularize
            # upper_shadow = (upper_shadow - np.amin(upper_shadow)) / (np.amax(upper_shadow) - np.amin(upper_shadow))
            upper_shadow = upper_shadow / yti_threshold
            # body = (body - np.amin(body)) / (np.amax(body) - np.amin(body))
            body = body / yti_threshold
            # lower_shadow = (lower_shadow - np.amin(lower_shadow)) / (np.amax(lower_shadow) - np.amin(lower_shadow))
            lower_shadow = lower_shadow / yti_threshold
            closed = (closed - np.amin(closed)) / yti_threshold
            # macd_diff_ = macd_diff_ / yti_threshold
            # macd_ = macd_ / yti_threshold

            input = np.array([
                upper_shadow,
                body,
                lower_shadow,
                closed,
                # macd_diff_,
                # macd_
            ])
            # input = (input - np.amin(input, axis = 1)[:, None])/(np.amax(input, axis = 1) - np.amin(input, axis = 1))[:, None]

            input = np.array([input])
            input = torch.from_numpy(input)
            input = torch.tensor(input, dtype=torch.float32)
            outputs = self.net(input)
            output = outputs[0]
            long_confidence = output[0].item()
            short_confidence = output[1].item()

            last_1_macd_diff = recent_candles_df['macd_diff'][recent_candles_df.index[-1]]
            last_2_macd_diff = recent_candles_df['macd_diff'][recent_candles_df.index[-2]]
            current_macd = macd[macd.index[-1]]
            # long_confidence = output[1].item()
            # short_confidence = output[0].item()

            # self.dragged_long_conf = 0.7 * long_confidence + 0.3 * self.dragged_long_conf
            # self.dragged_short_conf = 0.7 * short_confidence + 0.3 * self.dragged_short_conf

            self.dragged_long_conf = long_confidence
            self.dragged_short_conf = short_confidence

            # units = int(0.8 * self.account.getMarginAvailable() / self.account.getMarginRate())

            units = 1000/0.02

            if self.position == 2:
                if self.confidence*self.dragged_long_conf > confidence_threshold and short_confidence < 0.5 * (1 - confidence_threshold) and self.buy_cd <= 0:
                    self.buy_counts += 1
                    print(timestamp, 'BUY with confidence: %.5f' %
                          (long_confidence))
                    self.position = 0
                    # self.best_profit = units*yti_threshold*0.1
                    self.best_profit = 0
                    self.yeh_steps = 0
                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": units, "stop_lost": bid - 1.1 * yti_threshold, "take_profit": bid + 3.3 * yti_threshold})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)
                    if verbose:
                        plotter.plot_candles(
                            'buy future', self.eurusd_inst.foreseeFutureCandles1M(self.yeh_n + 1*self.yeh_m))
                elif self.confidence*self.dragged_short_conf > confidence_threshold and long_confidence < 0.5 * (1 - confidence_threshold) and self.sell_cd <= 0:
                    self.sell_counts += 1
                    print(timestamp, 'SELL with confidence: %.5f' %
                          (short_confidence))
                    self.position = 1
                    # self.best_profit = units*yti_threshold*0.1
                    self.best_profit = 0
                    self.yeh_steps = 0
                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": -units, "stop_lost": ask + 1.1 * yti_threshold, "take_profit": ask - 3.3 * yti_threshold})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)
                    if verbose:
                        plotter.plot_candles(
                            'sell future', self.eurusd_inst.foreseeFutureCandles1M(self.yeh_n + 1*self.yeh_m))

            elif self.position == 0:
                self.yeh_steps += 1
                self.total_yeh_steps += 1

                if current_macd > ((self.yeh_m-0.5*(self.yeh_steps-1-self.yeh_n))/self.yeh_m)*macd_threshold and bid - self.current_trade.getOpenPrice() > 0.33 * yti_threshold and last_1_macd_diff > 0 and self.yeh_steps > self.yeh_n:
                    self.consider_to_close_trade = True

                if self.yeh_steps > self.yeh_n + 0.8*self.yeh_m:
                    self.consider_to_close_trade = True

                if self.best_profit < self.current_trade.getUnrealizedPL():
                    self.best_profit = self.current_trade.getUnrealizedPL()

                if self.consider_to_close_trade and current_macd <= 0.9 * macd_threshold:
                    print('00')
                    self.current_trade.close()
                elif self.consider_to_close_trade and last_1_macd_diff < macd_diff_threshold:
                    print('01')
                    self.current_trade.close()
                elif self.yeh_steps >= self.yeh_n + self.yeh_m:
                    print('02')
                    self.current_trade.close()

            elif self.position == 1:
                self.yeh_steps += 1
                self.total_yeh_steps += 1

                if current_macd < -((self.yeh_m-0.5*(self.yeh_steps-1-self.yeh_n))/self.yeh_m)*macd_threshold and self.current_trade.getOpenPrice() - ask > 0.33 * yti_threshold and last_1_macd_diff < 0 and self.yeh_steps > self.yeh_n:
                    self.consider_to_close_trade = True

                if self.yeh_steps > self.yeh_n + 0.8*self.yeh_m:
                    self.consider_to_close_trade = True

                if self.best_profit < self.current_trade.getUnrealizedPL():
                    self.best_profit = self.current_trade.getUnrealizedPL()

                if self.consider_to_close_trade and current_macd >= -0.9 * macd_threshold:
                    print('10')
                    self.current_trade.close()
                elif self.consider_to_close_trade and last_1_macd_diff > -macd_diff_threshold:
                    print('11')
                    self.current_trade.close()
                elif self.yeh_steps >= self.yeh_n + self.yeh_m:
                    print('12')
                    self.current_trade.close()
            if verbose:
                print(timestamp, ' b: %.6f, a: %.6f ' % (bid, ask),
                      ' l: %.5f, s: %.5f, h: %.5f' % tuple(output.tolist()))
            # print(outputs)
            # output = outputs[0]
            # mv_avg_sum = outputs[0].clone()
            # for i in range(len(self.move_avg_list)-1):
            #     self.move_avg_list[i] = self.move_avg_list[i+1]
            #     if self.move_avg_list[i]!= None:
            #         mv_avg_sum += self.move_avg_list[i]
            # self.move_avg_list[-1] = output
            # # print(mv_avg_sum)
            #
            # mv_avg = mv_avg_sum / len(self.move_avg_list)
            # print(mv_avg)
            # print(self.move_avg_list)
            # plotter.plot_candles('recent_candles', recent_candles_df)
        self.every_15_second_loop_count += 1

    def run(self, BrokerAPI):
        net = JvnNet()
        net.load_state_dict(torch.load(
            self.agent_directory + '/' + selected_net))
        net.eval()
        self.net = net
        BrokerAPI.onEvery15Second(self._every_15_second_loop)
        self.eurusd_inst = BrokerAPI.getInstrument('EUR_USD')
        self.account = BrokerAPI.getAccount()

        test_batches = generate_training_batches_2('eurusd', utc.localize(datetime(2020, 12, 1, 0, 0)), utc.localize(
            datetime(2021, 4, 8, 23, 59)), batch_counts=1, batch_size=test_batch_size * 4)
        test_batch = test_batches[0]
        test_inputs, test_labels = test_batch

        outputs = net(test_inputs)
        output_max_value, output_max_indices = torch.max(outputs, 1)
        answer_max_value, answer_max_indices = torch.max(test_labels, 1)
        t_trend = torch.eq(answer_max_indices, output_max_indices)
        # t_trend = torch.eq(test_labels, output_max_indices)
        counts = torch.sum(t_trend.int()).item()
        print(' accuracy:', counts / (test_batch_size * 4))
        print(' avg conf:', torch.sum(output_max_value) / (test_batch_size * 4))
        m = calc_confusion_matrix(answer_max_indices, output_max_indices, 3)
        a = m / np.sum(m, axis=0)[None, :]

        # print(m)
        # plt.matshow(m)
        # plt.colorbar()
        # plt.show()

        print(a)

        buy_win_rate = a[0, 0] / (a[0, 0] + a[1, 0])
        sell_win_rate = a[1, 1] / (a[0, 1] + a[1, 1])
        self.buy_win_rate = buy_win_rate
        self.sell_win_rate = sell_win_rate
        print('Win rate: buy(%.5f), sell(%.5f)' %
              (buy_win_rate, sell_win_rate))

        if verbose or True:
            plt.matshow(a, vmin=0, vmax=1)
            plt.colorbar()
            plt.show()

        if buy_win_rate < win_rate_threshold or sell_win_rate < win_rate_threshold:
            print('Bad model imported, abort.')
            raise

    def stop_running(self, BrokerAPI):
        print('Win rate: buy(%.5f), sell(%.5f)' %
              (self.buy_win_rate, self.sell_win_rate))
        print('Buy Pl: %.5f, Counts: %d, Avg: %.5f.\nSell Pl: %.5f, Counts: %d, Avg: %.5f.' % (
            self.buy_pl, self.buy_counts, self.buy_pl/self.buy_counts, self.sell_pl, self.sell_counts, self.sell_pl/self.sell_counts))

    def train(self, BrokerAPI):
        nsp = BrokerAPI.getNotificationServiceProvider()
        nsp.pushImmediately('Training', 'HB001')

        offset = 240

        training_batches = generate_training_batches_2('eurusd', utc.localize(datetime(2000, 1, 1, 0, 0)), utc.localize(
            datetime(2020, 11, 29, 23, 59)), batch_counts=8, batch_size=train_batch_size, cuda=cuda_enabled)
        test_batches = generate_training_batches_2('eurusd', utc.localize(datetime(2020, 12, 1, 0, 0)), utc.localize(
            datetime(2021, 4, 8, 23, 59)), batch_counts=1, batch_size=test_batch_size, cuda=cuda_enabled)

        test_batch = test_batches[0]
        test_inputs, test_labels = test_batch
        #
        net = JvnNet()
        # nn.init.normal_(net.fc1.weight, mean=0, std=1.0)
        # nn.init.normal_(net.fc2.weight, mean=0, std=1.0)
        # nn.init.normal_(net.fc3.weight, mean=0, std=1.0)

        # net.load_state_dict(torch.load(
        #     self.agent_directory + '/' + selected_net))
        # net.eval()

        if cuda_enabled:
            print(net.cuda())

        # criterion = nn.CrossEntropyLoss()
        criterion = nn.MSELoss()
        # criterion_mae = nn.L1Loss()

        # optimizer = optim.RMSprop(net.parameters())

        # optimizer = optim.SGD(net.parameters(), lr=0.01, momentum=0.9)
        # optimizer = optim.Adam(net.parameters(), lr=0.01)
        # optimizer = optim.Adam(net.parameters(), lr=0.0005)
        optimizer = optim.Adam(net.parameters(), lr=0.001)
        # optimizer = optim.Adam(net.parameters(), lr=0.0001)
        # optimizer = optim.Adam(net.parameters(), lr=0.00008) #
        # optimizer = optim.Adam(net.parameters(), lr=0.00001) #
        # optimizer = optim.Adam(net.parameters(), lr=0.0000001)
        # optimizer = optim.Adam(net.parameters(), lr=0.000003)
        # optimizer = optim.Adam(net.parameters(), lr=0.000001) #
        # optimizer = optim.Adam(net.parameters(), lr=0.0000008)
        # optimizer = optim.Adam(net.parameters(), lr=0.00000065)
        # optimizer = optim.Adam(net.parameters(), lr=0.0000004)
        # optimizer = optim.Adam(net.parameters(), lr=0.000001)
        # optimizer = optim.Adam(net.parameters(), lr=0.0000001)

        # for epoch in range(1):  # loop over the dataset multiple times
        # for epoch in range(32):  # loop over the dataset multiple times
        # for epoch in range(128):  # loop over the dataset multiple times
        # for epoch in range(128*4):  # loop over the dataset multiple times
        # for epoch in range(128*8):  # loop over the dataset multiple times
        # for epoch in range(128*16):  # loop over the dataset multiple times

        # for epoch in range(128 * 24):  # loop over the dataset multiple times
            #
        for epoch in range(128*64):  # loop over the dataset multiple times
            if (epoch - 1) % 8 == 7 and epoch != 0:
                torch.save(net.state_dict(), self.agent_directory +
                           datetime.now().strftime("/backup.net"))

                del training_batches
                # print('Sleeping(too hot)...')
                # time.sleep(75)
                training_batches = generate_training_batches_2('eurusd', utc.localize(datetime(2000, 1, 1, 0, 0)), utc.localize(
                    datetime(2020, 11, 29, 23, 59)), batch_counts=8, batch_size=train_batch_size, cuda=cuda_enabled)
                print('Training batches updated.')

            running_loss = 0.0
            running_test_loss = 0.0
            for i, training_batch in enumerate(training_batches):
                # get the inputs; data is a list of [inputs, labels]
                inputs, labels = training_batch
                # print(labels)
                # print(inputs, labels, inputs.shape, labels.shape)
                # raise
                # zero the parameter gradients
                optimizer.zero_grad()

                # forward + backward + optimize120*14
                outputs = net(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                test_outputs = net(test_inputs)
                test_loss = criterion(test_outputs, test_labels)

                # print statistics
                running_loss += loss.item()
                running_test_loss += test_loss.item()

                if i % 8 == 7:    # print every 2000 mini-batches
                    answer_max_value, answer_max_indices = torch.max(labels, 1)
                    output_max_value, output_max_indices = torch.max(
                        outputs, 1)
                    trend = torch.eq(answer_max_indices, output_max_indices)
                    trend_int = trend.int()
                    trend_counts = torch.sum(trend_int).item()

                    answer_max_value, answer_max_indices = torch.max(
                        test_labels, 1)
                    output_max_value, output_max_indices = torch.max(
                        test_outputs, 1)
                    t_trend = torch.eq(answer_max_indices, output_max_indices)
                    # t_trend = torch.eq(test_labels, output_max_indices)
                    t_trend_int = t_trend.int()
                    t_trend_counts = torch.sum(t_trend_int).item()
                    # counts_col = torch.sum(t_trend_int, dim=0)

                    print('[%d, %5d] Loss: %.6f, accuracy: %.3f    Test loss: %.6f, accuracy: %.3f ' % (
                        epoch + 1, i + 1, running_loss / 8, trend_counts / 8192, running_test_loss / 8, t_trend_counts / test_batch_size))
                    # if (epoch-1) % 128 == 127 and i == 63:
                    #     nsp.pushImmediately('Traing loss', '[%d, %5d] Loss: %.10f Test loss: %.10f\nTest accuracy: %.5f' % (epoch + 1, i + 1, running_loss / 64, running_test_loss / 64, counts/test_batch_size))
                    #     nsp.pushImmediately('Traing loss', '[%d, %5d] Loss: %.10f Test loss: %.10f\nTest accuracy: %.5f' % (epoch + 1, i + 1, running_loss / 64, running_test_loss / 64, counts/test_batch_size))
                    running_loss = 0.0
                    running_test_loss = 0.0
        # net.cpu()

        outputs = net(test_inputs)

        print('\n===answers===')
        print(test_labels)
        # print('\n===outputs===')
        # print(outputs)
        print('\n===same trends or not===')
        answer_max_value, answer_max_indices = torch.max(test_labels, 1)
        output_max_value, output_max_indices = torch.max(outputs, 1)

        # print(answer_max_indices)
        print(output_max_indices)
        # print(answer_max_value)
        print(output_max_value)
        # t_trend = torch.eq(test_labels, output_max_indices)
        t_trend = torch.eq(answer_max_indices, output_max_indices)
        print(t_trend)
        counts = torch.sum(t_trend.int()).item()
        print(' accuracy:', counts / test_batch_size)
        nsp.pushImmediately('Train accuracy', str(counts / test_batch_size))
        print('\n===confusion matrix===')
        m = calc_confusion_matrix(answer_max_indices, output_max_indices, 3)
        print(m)
        plt.matshow(m, vmin=0, vmax=1)
        plt.colorbar()
        plt.show()

        print(self.agent_directory +
              datetime.now().strftime("/JVN_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory +
                   datetime.now().strftime("/JVN_%Y_%m_%d_%H_%M.net"))
        del net

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        self.run(BacktestBrokerAPI)

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
