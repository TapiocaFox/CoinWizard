from numpy import exp, arange, sign, log
from pylab import meshgrid, cm, imshow, contour, clabel, colorbar, axis, title, show

# the function that I'm going to plot

def z_func(x, y):
    sigma = 5
    lamb = 0.5
    v = 0.75
    s = 48
    lamb = log(1-v)/log(exp(-s))
    sample = 48
    return sign(x)*(1. - exp((-1./2.)*(x/sigma)**2))*((lamb*exp(-lamb*y))/(1. - exp(-lamb*sample)))
    # return sign(x)*(1. - exp((-1./2.)*(x/sigma)**2))


x = arange(-20.0, 20.0, 0.1)
y = arange(0., 48.0, 1.)
X, Y = meshgrid(x, y)  # grid of point
Z = z_func(X, Y)  # evaluation of the function on the grid

im = imshow(Z, cmap=cm.RdBu)  # drawing the function
# adding the Contour lines with labels
cset = contour(Z, arange(-1, 1.5, 0.005), linewidths=2, cmap=cm.Set2)
clabel(cset, inline=True, fmt='%1.3f', fontsize=10)
colorbar(im)  # adding the colobar on the right
# latex fashion title
title('')
show()
