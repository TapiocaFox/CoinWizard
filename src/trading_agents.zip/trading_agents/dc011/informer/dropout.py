import torch
import torch.nn as nn

import numpy as np

from math import ceil

import matplotlib.pyplot as plt

class DataDropout(nn.Module):
    def __init__(self, dropout_keep=0.5, dropout=0.2, feature_dropout=True):
        super(DataDropout, self).__init__()
        self.dropout_keep = dropout_keep
        self.dropout = dropout
        self.feature_dropout = feature_dropout

    def forward(self, x, x_mark):
        if self.training and True:
            device = x.get_device()

            dropout_keep = self.dropout_keep
            dropout = self.dropout
            feature_dropout = self.feature_dropout

            B, L, D = x.shape

            # # Positional dropout
            # if device >= 0:
            #     mask = torch.ones(B, L, device=device)*(1-dropout)
            #     preserve_mask = torch.rand(B, L, device=device)
            # else:
            #     mask = torch.ones(B, L)*(1-dropout)
            #     preserve_mask = torch.rand(B, L)
            #
            # mask = torch.bernoulli(mask)
            #
            # preserve_mask_top_k = torch.topk(preserve_mask, ceil(L*dropout_keep))[0]
            # preserve_mask = preserve_mask >= preserve_mask_top_k[:, -1:]
            #
            # mask[preserve_mask] = 1
            #
            # mask = mask.unsqueeze(2)
            #
            # if not feature_dropout:
            #     # print(mask*x)
            #     # x_ = np.arange(L)
            #     # m = mask*x
            #     # plt.plot(x_, (m[0, :, 0]).tolist(), label='close')
            #     # plt.plot(x_, (m[0, :, 1]).tolist(), label='macd1')
            #     # plt.plot(x_, (m[0, :, 2]).tolist(), label='macd2')
            #     # plt.plot(x_, (m[0, :, 3]).tolist(), label='momentum')
            #     # plt.plot(x_, (m[0, :, 4]).tolist(), label='rsi')
            #     # plt.plot(x_, (m[0, :, 5]).tolist(), label='cci')
            #     # plt.legend()
            #     # plt.show()
            #     return mask*x, mask*x_mark, mask

            # Feature dropout
            if device >= 0:
                f_mask = torch.ones(B, D, device=device)*(1-dropout)
                f_preserve_mask = torch.rand(B, D, device=device)
            else:
                f_mask = torch.ones(B, D)*(1-dropout)
                f_preserve_mask = torch.rand(B, D)

            f_mask = torch.bernoulli(f_mask)

            f_preserve_mask_top_k = torch.topk(f_preserve_mask, ceil(D*dropout_keep))[0]
            f_preserve_mask = f_preserve_mask >= f_preserve_mask_top_k[:, -1:]

            f_mask[f_preserve_mask] = 1

            f_mask = f_mask.unsqueeze(1)

            # print(f_mask*mask*x)
            # x_ = np.arange(L)
            # m = f_mask*mask*x
            # plt.plot(x_, (m[0, :, 0]).tolist(), label='close')
            # plt.plot(x_, (m[0, :, 1]).tolist(), label='macd1')
            # plt.plot(x_, (m[0, :, 2]).tolist(), label='macd2')
            # plt.plot(x_, (m[0, :, 3]).tolist(), label='momentum')
            # plt.plot(x_, (m[0, :, 4]).tolist(), label='rsi')
            # plt.plot(x_, (m[0, :, 5]).tolist(), label='cci')
            # plt.legend()
            # plt.show()

            # return f_mask*mask*x, mask*x_mark, mask
            mask = torch.ones(B, L, 1, device=device)
            return f_mask*mask*x, mask*x_mark, mask
            # return x
        else:
            B, L, D = x.shape

            device = x.get_device()
            if device >= 0:
                mask = torch.ones(B, L, device=device)
            else:
                mask = torch.ones(B, L)

            mask = mask.unsqueeze(2)

            return x, x_mark, mask

class MultiHeadDropout(nn.Module):
    def __init__(self, dropout=0.1):
        super(MultiHeadDropout, self).__init__()
        self.dropout = dropout

    def forward(self, x):
        if self.training and True:
            device = x.get_device()

            dropout = self.dropout

            B, L, H, D = x.shape

            if device >= 0:
                mask = torch.ones(B, L, H, device=device)*(1-dropout)
            else:
                mask = torch.ones(B, L, H)*(1-dropout)

            mask = torch.bernoulli(mask)
            active_counts = torch.sum(mask, dim=2, keepdim=True)
            scale = H/active_counts
            scale = torch.nan_to_num(scale, nan=0.0)
            # print(active_counts)
            mask = scale*mask
            # print(mask)
            mask = mask.expand(B, L, H).unsqueeze(3).expand(B, L, H, D)
            # print(mask)
            # print(active_counts)

            return mask*x
        else:
            return x

class GranularityDropout(nn.Module):
    def __init__(self, dropout=0.1, granularities = []):
        super(GranularityDropout, self).__init__()
        self.dropout = dropout
        self.granularities = granularities

    def forward(self, x):
        # print(0)
        dropout = self.dropout
        granularities = self.granularities
        device = x[0].get_device()

        if self.training and True:
            B, _, _ = x[0].shape

            if device >= 0:
                preserve_mask = torch.rand(B, len(granularities), device=device)
            else:
                preserve_mask = torch.rand(B, len(granularities))

            preserve_mask_top_k = torch.topk(preserve_mask, 1)[0]
            preserve_mask = preserve_mask >= preserve_mask_top_k[:, -1:]

            # print(preserve_mask)
            for index, do_dropout in enumerate(granularities):
                if do_dropout:
                    if device >= 0:
                        mask = torch.ones(B, device=device)*(1-dropout)
                    else:
                        mask = torch.ones(B)*(1-dropout)

                    mask = torch.bernoulli(mask)

                    mask = (torch.logical_or(mask, preserve_mask[:, index])).float()
                    mask = mask.unsqueeze(1).unsqueeze(2)

                    x[index] = mask*x[index]
            return x

        else:
            return x

# a = torch.arange(3*288*2)
# b = torch.arange(3*288*1)
# a = a.view(3, 288, 2)
# b = b.view(3, 288, 1)

# a = torch.arange(3*15*6)
# b = torch.arange(3*15*1)
# a = a.view(3, 15, 6)
# b = b.view(3, 15, 1)
#
# d = DataDropout(0.5, 0.1)
# print(d(a, b))


# c = torch.arange(3*5*8*2)
# c = c.view(3, 5, 8, 2)
# d2 = MultiHeadDropout()
# print(d2(c))

# d_ = [torch.arange(16*3*2).view(16, 3, 2), torch.arange(16*3*2).view(16, 3, 2), torch.arange(16*3*2).view(16, 3, 2)]
# d3 = GranularityDropout(0.1, [True, True, True])
# print(d3(d_))

# l = 0
# while True:
#     c = torch.arange(128*256*8*64)
#     c = c.view(128, 256, 8, 64)
#     d2 = MultiHeadDropout()
#     d2.cuda()
#     n = torch.isnan(d2(c))
#     if torch.sum(n)>0:
#         print(l)
#         raise
