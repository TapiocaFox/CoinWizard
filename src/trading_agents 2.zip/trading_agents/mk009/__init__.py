#!/usr/bin/python3

import pytz, torch, math, os
from datetime import datetime, timedelta

import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import trading_agents.mk009.nets as nets
import trading_agents.mk009.dataloader as dataloader
import matplotlib.pyplot as plt
from .timefeatures import time_features
import coin_wizard.historical_pair_data as hist

from coin_wizard.technical_indicators import TechnicalIndicators

utc = pytz.utc

### Global settings ###
verbose = False
# granularities = ['M5', 'M15', 'H1', 'H4']
# granularities = ['M5', 'M15', 'H1', 'H4', 'D']
granularities = ['M15', 'H1', 'H4',]
macd_amplifier = [8, 4, 2]
# granularities = ['M5', 'M15', 'H1', 'H4', 'D']

granularity_time_delta = {
    "M1": timedelta(seconds=60),
    "M5": timedelta(seconds=60*5),
    "M15": timedelta(seconds=60*15),
    "M30": timedelta(seconds=60*30),
    "H1": timedelta(seconds=60*60),
    "H4": timedelta(seconds=60*240),
    "D": timedelta(seconds=60*60*24),
}
# input_period_list = [64, 64, 64]
# input_period_list = [64, 64, 64, 64]
# input_period_list = [96, 96, 96, 96]
# input_period_list = [64, 64, 64, 64, 32]
# input_period_list = [96, 128, 96, 96, 96, 32]
# input_period_list = [256, 256, 256]
input_period_list = [288, 288, 288]
# input_period_list = [480, 480, 480]

cci_trigger_granularity = 0
decode_inference_granularity = 2
# decode_inference_len = 64
decode_inference_len = 72
decode_prediction_granularity = 0
decode_predict_len = 24
decode_predict_resolution = 24
cuda_enabled = True
# cuda_enabled = False
selected_net = 'backup.net'
# selected_net = 'MK_2021_08_13_11_21.net'
plot_range = 0.0025

### Indicator settings ###
# moving_average = 9
momentum_period=10
rsi_period=14
cci_period=14

### Train settings ###
load_selected_net = False
learning_rate = 0.0001 * 0.1
# learning_rate = learning_rate * 0.29385764323
primary_intrument = 'eurusd'
primary_intrument_trade = 'EUR_USD'
primary_intrument_index = 0
# primary_intrument = 'usdchf'
# primary_intrument_trade = 'USD_CHF'
# primary_intrument_index = 9
# selected_instrument_list = ['eurusd', 'gbpusd', 'audusd', 'usdcad', 'eurjpy', 'usdjpy']

# selected_instrument_datascaler_list = [ dataloader.DataScaler(np.array(1.1924490551226474), np.array(0.09608276821936781)),
#                                         dataloader.DataScaler(np.array(1.428601840627313), np.array(0.14754311756904043)),
#                                         dataloader.DataScaler(np.array(0.8109898637830456), np.array(0.12188596874201743)),
#                                         dataloader.DataScaler(np.array(1.222725673225676), np.array(0.13292115495331883)),
#                                         dataloader.DataScaler(np.array(125.33177145959843), np.array(10.895352856678667)),
#                                         dataloader.DataScaler(np.array(105.68095956301106), np.array(11.318548392932305))]

selected_instrument_list = ['eurusd', 'gbpusd', 'audusd', 'eurjpy', 'nzdusd',
                            'usdcad', 'usdjpy', 'gbpaud', 'euraud', 'gbpcad',
                            'gbpnzd', 'nzdchf', 'cadchf', 'eurcad', 'gbpchf',
                            'audjpy', 'eurnok', 'usdtry', 'audnzd', 'audchf',
                            'sgdjpy', 'xagusd', 'xauusd', 'zarjpy', 'usdzar']

selected_instrument_datascaler_list = [ dataloader.DataScaler(np.array(1.2226727737949628), np.array(0.009321890215588892)),
                                        dataloader.DataScaler(np.array(1.45501340226881), np.array(0.011060999128222426)),
                                        dataloader.DataScaler(np.array(0.8409227146528752), np.array(0.007851036786977503)),
                                        dataloader.DataScaler(np.array(123.22119330754076), np.array(1.0986215134644373)),
                                        dataloader.DataScaler(np.array(0.7346609054141837), np.array(0.007203641730052198)),

                                        dataloader.DataScaler(np.array(1.1841049275904305), np.array(0.008109238767617525)),
                                        dataloader.DataScaler(np.array(101.70687582712374), np.array(0.7672340028178317)),
                                        dataloader.DataScaler(np.array(1.7489657289994534), np.array(0.015634155327402196)),
                                        dataloader.DataScaler(np.array(1.4704677095197058), np.array(0.012488832038779537)),
                                        dataloader.DataScaler(np.array(1.7050919335627375), np.array(0.01290389198549966)),

                                        dataloader.DataScaler(np.array(1.982708837715431), np.array(0.018346041130852826)),
                                        dataloader.DataScaler(np.array(0.7022315989619157), np.array(0.006774384399805169)),
                                        dataloader.DataScaler(np.array(0.8205161447191238), np.array(0.007099000754367068)),
                                        dataloader.DataScaler(np.array(1.433110284870101), np.array(0.0106671219505378)),
                                        dataloader.DataScaler(np.array(1.3918337555225828), np.array(0.01172679423774073)),

                                        dataloader.DataScaler(np.array(84.04944948208193), np.array(0.9175642452381934)),
                                        dataloader.DataScaler(np.array(8.854169837315494), np.array(0.06107360442551253)),
                                        dataloader.DataScaler(np.array(3.42330615833745), np.array(0.04418635283989717)),
                                        dataloader.DataScaler(np.array(1.1399203007488543), np.array(0.006948698037429377)),
                                        dataloader.DataScaler(np.array(0.8033054645248916), np.array(0.007775106293923018)),

                                        dataloader.DataScaler(np.array(76.38232800119137), np.array(0.5603408388005925)),
                                        dataloader.DataScaler(np.array(21.14781348972715), np.array(0.5645192817654998)),
                                        dataloader.DataScaler(np.array(1389.8507780231075), np.array(19.194476302290806)),
                                        dataloader.DataScaler(np.array(8.852639836823544), np.array(0.13207647094098612)),
                                        dataloader.DataScaler(np.array(12.073743261105015), np.array(0.17317074155954423)),
                                        ]
fit_granularity = 'M15'
learning_rate_decay = 0.96**1
epoch_counts = int(512*1) # 6
batch_counts = int(512*2*2)
test_batch_counts = 16
# batch_counts = int(1)
# batch_counts = 32
batch_size = 16
batch_accumulation = 2
training_batches_update_epochs = 4

train_start_year = 2010
train_start_month = 1
train_start_day = 1
train_end_year = 2021
train_end_month = 1
train_end_day = 31

test_start_year = 2021
test_start_month = 2
test_start_day = 1
test_end_year = 2021
test_end_month = 6
test_end_day = 29

neighbors = 3
interval = 2

### Running settings ###
loop_every_n_15_second = 4*15
input_additional_period = 64
trade_additional_period = 5
close_steps = decode_predict_len + trade_additional_period
backtesting_plot = True
# backtesting_trading_active_plot = True
backtesting_trade_plot = False
backtesting_plot_pause = 0.001
activate_watchdog_cci_threshold = 100
watchdog_active_period = 8 # neighbors*interval

trade_trigger_ratio = 2.0
trade_trigger_magnitude = 0.0015

cci_close_granularity = 'M15'
cci_close_threshold = 100 *9999

# trade_close_trigger_distance = 0.0010
# trade_close_trigger_ratio = 1/1.3
# close_trials = 3

trailing_stop_distance = 0.0015
risk_reward_ratio = 0.75
take_profit_magnitude = 0.0015
stop_lost_magnitude = 0.0010
rsi_trade_close_rsi = 35
trade_close_price_distance = 0.0003
trade_close_least_steps = 8
trials = 3
trade_cd = 4
do_not_trade = False
# trials = 99
# mode = 'cci'

import coin_wizard.plotter as plotter

ti = TechnicalIndicators()

class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        if not os.path.exists(os.path.join(agent_directory, 'figs')):
            os.makedirs(os.path.join(agent_directory, 'figs'))
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 0

        self.nsp = None
        self.net = None
        self.position = 0

        self.current_trade = None
        self.current_trade_total_steps = 0
        self.current_trade_best_profit = 0
        self.current_trade_worst_loss = 0
        self.current_trade_steps = 0
        self.current_trade_close_steps = 0

        self.total_long_counts = 0
        self.total_short_counts = 0

        self.total_long_pl = 0
        self.total_short_pl = 0

        self.succeeded_trials = 0

        self.watchdog_remaining_active_period = 0
        self.trade_cd = 0

    def _order_canceled_listener(self, order, reason):
        self.position = 0

    def _order_filled_listener(self, order, trade):
        # Record stats
        if trade.getTradeSettings()['units'] > 0:
            self.total_long_counts += 1
        else:
            self.total_short_counts += 1

        self.current_trade = trade
        trade.onReduced(self._trade_reduced_listener)
        trade.onClosed(self._trade_closed_listener)

    def _trade_reduced_listener(self, trade, units, realized_pl, close_price, spread, timestamp):
        pass

    def _trade_closed_listener(self, trade, realized_pl, close_price, spread, timestamp):
        # Record stats
        if trade.getTradeSettings()['units'] > 0:
            self.total_long_pl += realized_pl
        else:
            self.total_short_pl += realized_pl

        self.position = 0

        self.nsp.pushImmediately('Trade closed', 'Trade closed after %d total steps. PL: %.5f. Best profit: %.5f. Worst loss: %.5f.' % (
            self.current_trade_steps, realized_pl, self.current_trade_best_profit, self.current_trade_worst_loss))

    def _neural_net_predict(self, mid=None):
        inference_granularity = decode_inference_granularity
        inference_length = decode_inference_len
        prediction_granularity = decode_prediction_granularity
        prediction_length = decode_predict_len
        prediction_resolution = decode_predict_resolution

        hist_data_granularities = [None for g in granularities]
        time_granularities = [None for g in granularities]
        prediction_start_timestamp = None

        # Prepare EurUsd data
        for index, granularity in enumerate(granularities):
            hist_data =  self.primary_instrument_object.getRecentCandles(input_period_list[index]+input_additional_period, granularity=granularity)
            hist_data.open = self.data_scaler.transform(hist_data.open)
            hist_data.low = self.data_scaler.transform(hist_data.low)
            hist_data.high = self.data_scaler.transform(hist_data.high)
            hist_data.close = self.data_scaler.transform(hist_data.close)

            hist_data['macd_12_26'] = ti.macd(hist_data.close, 12, 26)*macd_amplifier[index]
            hist_data['macd_26_40'] = ti.macd(hist_data.close, 26, 40)*macd_amplifier[index]
            hist_data['momentum'] = ti.momentum(hist_data.close, momentum_period)
            hist_data['rsi'] = ti.rsi_ema(hist_data.close, rsi_period)/50 - 1.0
            hist_data['cci'] = ti.cci(hist_data.high, hist_data.low, hist_data.close, cci_period)/200
            del hist_data['open']
            del hist_data['high']
            del hist_data['low']

            hist_data = hist_data

            hist_data.replace([np.inf, -np.inf], np.nan, inplace=True)
            hist_data = hist_data.dropna()
            hist_data = hist_data.sort_values(by=['timestamp']).reset_index(drop=True)

            hist_data_np = np.array([
                hist_data.close.to_list(),
                hist_data.macd_12_26.to_list(),
                hist_data.macd_26_40.to_list(),
                hist_data.momentum.to_list(),
                hist_data.rsi.to_list(),
                hist_data.cci.to_list(),
            ], dtype=np.float32)

            hist_data_np = np.swapaxes(hist_data_np, 0, 1)

            time_np = time_features(hist_data['timestamp'], freq='t')

            hist_data_granularities[index] = hist_data_np
            time_granularities[index] = time_np

            if index == prediction_granularity:
                prediction_start_timestamp = hist_data['timestamp'].iloc[-1]#+granularity_time_delta[granularity]

        # Make input tensor
        encode_inputs_list = [[] for g in granularities]
        encode_times_list = [[] for g in granularities]
        decode_inputs = []
        decode_times = []
        decode_inference = None
        decode_inference_time = None

        for index, granularity in enumerate(granularities):
            hist_data = hist_data_granularities[index]
            time = time_granularities[index]
            input_period = input_period_list[index]

            encode_input = hist_data[-input_period:, :].copy()
            encode_input[:, 0] = encode_input[:, 0] - encode_input[-1, 0]

            # x = np.arange(input_period)
            # plt.plot(x, (encode_input[:, 0]).tolist(), label='close')
            # plt.plot(x, (encode_input[:, 1]).tolist(), label='macd1')
            # plt.plot(x, (encode_input[:, 2]).tolist(), label='macd2')
            # plt.plot(x, (encode_input[:, 3]).tolist(), label='momentum')
            # plt.plot(x, (encode_input[:, 4]).tolist(), label='rsi')
            # plt.plot(x, (encode_input[:, 5]).tolist(), label='cci')
            # plt.title(str(granularity))
            # plt.legend()
            # plt.show()

            encode_time = time[-input_period:, :]
            encode_inputs_list[index].append(encode_input)
            encode_times_list[index].append(encode_time)

            if index == inference_granularity:
                decode_inference = encode_input[-inference_length:, :]
                decode_inference_time = encode_time[-inference_length:, :]

        prediction_resolution_steps = int(prediction_length/prediction_resolution)

        decode_input = np.zeros((prediction_resolution, decode_inference.shape[-1]))
        decode_input = np.concatenate([decode_inference, decode_input], axis=0)
        decode_time = np.concatenate([decode_inference_time, time_features(pd.date_range(start=prediction_start_timestamp, periods=prediction_length,
            freq=pd.DateOffset(seconds=granularity_time_delta[granularities[prediction_granularity]].total_seconds()))[::prediction_resolution_steps], freq='t')], axis=0)

        decode_inputs.append(decode_input)
        decode_times.append(decode_time)

        encode_inputs_list = [torch.tensor(encode_inputs, dtype=torch.float32) for encode_inputs in encode_inputs_list]
        encode_times_list = [torch.tensor(encode_times, dtype=torch.float32) for encode_times in encode_times_list]
        decode_inputs = torch.tensor(decode_inputs, dtype=torch.float32)
        decode_times = torch.tensor(decode_times, dtype=torch.float32)

        if cuda_enabled:
            encode_inputs_list = [encode_inputs.cuda() for encode_inputs in encode_inputs_list]
            encode_times_list = [encode_times.cuda() for encode_times in encode_times_list]
            decode_inputs = decode_inputs.cuda()
            decode_times = decode_times.cuda()

        outputs = self.net(encode_inputs_list, encode_times_list, decode_inputs, decode_times)

        del encode_inputs_list
        del encode_times_list
        del decode_inputs
        del decode_times

        # print(hist_data.ema.to_list()[-1], mid, (hist_data.ema.to_list()[-1]-mid))
        prediction = selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(outputs) # + (hist_data.ema.to_list()[-1]-mid)
        prediction[:, :, 0] = prediction[:, :, 0].clip(min=torch.finfo(torch.float32).eps)
        prediction[:, :, 1] = prediction[:, :, 1].clip(max=-torch.finfo(torch.float32).eps)
        prediction_max = torch.max(prediction[0, :, 0]).item()
        prediction_min = torch.min(prediction[0, :, 1]).item()

        # Plot for backtesting.
        if backtesting_plot == True:
            x = list(range(0, prediction_resolution))
            labels = self.primary_instrument_object.foreseeFutureCandles(prediction_length, granularity=granularities[prediction_granularity])
            labels = torch.tensor(labels['close'].tolist())
            labels = labels - labels[0]
            plt.plot(x, labels[::prediction_resolution_steps].tolist(), label='Label')
            plt.plot(x, prediction[0, :, 0].tolist(), label='Predict-CumMax')
            plt.plot(x, prediction[0, :, 1].tolist(), label='Predict-CumMin')
            plt.legend()
            plt.ylim(-plot_range, plot_range)
            plt.show(block=False)
            # plt.show()
            plt.pause(backtesting_plot_pause)
            plt.close()

        return prediction_max, prediction_min

    def _every_15_second_loop(self, BrokerAPI):

        # Is not tradable
        if not self.primary_instrument_object.isTradable():
            return

        # Every one minute = 4*15 seconds
        # print(self.every_15_second_loop_count)
        if self.every_15_second_loop_count % loop_every_n_15_second == 0:
            self.every_15_second_loop_count = 0
            # print(self.every_15_second_loop_count)

            # Normalize
            bid, ask, timestamp = self.primary_instrument_object.getCurrentCloseoutBidAsk()
            mid = 0.5*(bid+ask)

            # Trading algorithm
            units = 1000/0.02

            recent_candles = self.primary_instrument_object.getRecentCandles(rsi_period+cci_period+input_additional_period, granularity=granularities[cci_trigger_granularity])
            rsi_list = ti.rsi_ema(recent_candles.close, rsi_period).tail(2)
            rsi_now = rsi_list.iloc[1]
            rsi_previous = rsi_list.iloc[0]

            cci_list = ti.cci(recent_candles.high, recent_candles.low, recent_candles.close, cci_period).tail(2)
            cci_now = cci_list.iloc[1]
            cci_previous = cci_list.iloc[0]

            if verbose:
                print(cci_list)
                print('cci_now: %1.6f, cci_previous: %1.6f'%(cci_now, cci_previous))

            if self.position == 0:
                if ((-activate_watchdog_cci_threshold >= cci_previous and cci_now > cci_previous) or (cci_previous >= activate_watchdog_cci_threshold and cci_now < cci_previous)):
                    self.watchdog_remaining_active_period = watchdog_active_period
                    if verbose:
                        print('watchdog actived.')

                if self.watchdog_remaining_active_period > 0:
                    self.watchdog_remaining_active_period -= 1
                    if verbose:
                        print('watchdog "'+str(self.watchdog_remaining_active_period)+'" active periods remaining.')

                    prediction_max, prediction_min = self._neural_net_predict(mid)

                    if (-prediction_max/prediction_min >= 1):
                        magnitude = prediction_max
                        ratio = -prediction_max/prediction_min
                        triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                        print(timestamp, '[long] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))
                        if(triggered and not do_not_trade and self.trade_cd <= 0):
                            self.succeeded_trials += 1
                            if self.succeeded_trials >= trials:
                                self.succeeded_trials = 0
                                self.succeeded_close_trials = 0
                                self.position = 1
                                self.current_trade_best_profit = 0
                                self.current_trade_worst_loss = 0
                                self.current_trade_steps = 0
                                self.current_trade_close_steps = close_steps
                                self.watchdog_remaining_active_period = 0
                                self.trade_cd = trade_cd
                                order = BrokerAPI.order(primary_intrument_trade, {"type": "market"}, {
                                                        "units": units,
                                                        "take_profit": round(bid + take_profit_magnitude, 8),
                                                        "stop_lost":  round(bid - stop_lost_magnitude, 8),
                                                        "trailing_stop_distance": round(trailing_stop_distance, 8)
                                                        })
                                order.onCanceled(self._order_canceled_listener)
                                order.onFilled(self._order_filled_listener)

                                # Plot for backtesting.
                                if backtesting_trade_plot == True:
                                    x = list(range(0, decode_predict_len))
                                    labels = self.primary_instrument_object.foreseeFutureCandles(decode_predict_len, granularity=granularities[decode_prediction_granularity])
                                    labels = torch.tensor(labels['close'].tolist())
                                    labels = labels - labels[0]
                                    plt.plot(x, labels.tolist(), label='Label')
                                    plt.legend()
                                    plt.ylim(-plot_range, plot_range)
                                    plt.show()
                        else:
                            self.succeeded_trials = 0
                    else:
                        magnitude = -prediction_min
                        ratio = -prediction_min/prediction_max
                        triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                        print(timestamp, '[short] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))
                        if(triggered and not do_not_trade and self.trade_cd <= 0):
                            self.succeeded_trials += 1
                            if self.succeeded_trials >= trials:
                                self.succeeded_trials = 0
                                self.succeeded_close_trials = 0
                                self.position = 2
                                self.current_trade_best_profit = 0
                                self.current_trade_worst_loss = 0
                                self.current_trade_steps = 0
                                self.current_trade_close_steps = close_steps
                                self.watchdog_remaining_active_period = 0
                                self.trade_cd = trade_cd
                                order = BrokerAPI.order(primary_intrument_trade, {"type": "market"}, {
                                                        "units": -units,
                                                        "take_profit": round(ask - take_profit_magnitude, 8),
                                                        "stop_lost": round(ask + stop_lost_magnitude, 8),
                                                        "trailing_stop_distance": round(trailing_stop_distance, 8)
                                                        })
                                order.onCanceled(self._order_canceled_listener)
                                order.onFilled(self._order_filled_listener)

                                # Plot for backtesting.
                                if backtesting_trade_plot == True:
                                    x = list(range(0, decode_predict_len))
                                    labels = self.primary_instrument_object.foreseeFutureCandles(decode_predict_len, granularity=granularities[decode_prediction_granularity])
                                    labels = torch.tensor(labels['close'].tolist())
                                    labels = labels - labels[0]
                                    plt.plot(x, labels.tolist(), label='Label')
                                    plt.legend()
                                    plt.ylim(-plot_range, plot_range)
                                    plt.show()
                        else:
                            self.succeeded_trials = 0
                else:
                    self.succeeded_trials = 0

            # Long position
            elif self.position == 1:
                self.current_trade_steps += 1

                if self.current_trade_best_profit < self.current_trade.getUnrealizedPL():
                    self.current_trade_best_profit = self.current_trade.getUnrealizedPL()

                if self.current_trade_worst_loss > self.current_trade.getUnrealizedPL():
                    self.current_trade_worst_loss = self.current_trade.getUnrealizedPL()

                recent_candles = self.primary_instrument_object.getRecentCandles(rsi_period+cci_period+input_additional_period, granularity=cci_close_granularity)
                cci_now = ti.cci(recent_candles.high, recent_candles.low, recent_candles.close, cci_period).tail(1).iloc[0]
                if self.current_trade_steps >= trade_close_least_steps and cci_now >= cci_close_threshold:
                    print('** Reach cci close threshold. Request trade close.')
                    self.current_trade.close()
                # bid, ask, timestamp = self.primary_instrument_object.getCurrentCloseoutBidAsk()

                # if self.current_trade_steps >= trade_close_least_steps and bid - self.current_trade.getOpenPrice() >= trade_close_trigger_distance:
                #     prediction_max, prediction_min = self._neural_net_predict()
                #     ratio = -prediction_max/prediction_min
                #     if ratio <= trade_close_trigger_ratio:z
                #         self.succeeded_close_trials += 1
                #     else:
                #         self.succeeded_close_trials = 0
                #
                #     if self.succeeded_close_trials >= close_trials:
                #         print('** Succeeded close trials reached. Request trade close.')
                #         self.current_trade.close()

                if self.current_trade_steps >= self.current_trade_close_steps:
                    print('** Reach trade close steps. Request trade close.')
                    self.current_trade.close()

            # Short position
            elif self.position == 2:
                self.current_trade_steps += 1

                if self.current_trade_best_profit < self.current_trade.getUnrealizedPL():
                    self.current_trade_best_profit = self.current_trade.getUnrealizedPL()

                if self.current_trade_worst_loss > self.current_trade.getUnrealizedPL():
                    self.current_trade_worst_loss = self.current_trade.getUnrealizedPL()

                recent_candles = self.primary_instrument_object.getRecentCandles(rsi_period+cci_period+input_additional_period, granularity=cci_close_granularity)
                cci_now = ti.cci(recent_candles.high, recent_candles.low, recent_candles.close, cci_period).tail(1).iloc[0]
                if self.current_trade_steps >= trade_close_least_steps and cci_now <= -cci_close_threshold:
                    print('** Reach cci close threshold. Request trade close.')
                    self.current_trade.close()
                # bid, ask, timestamp = self.primary_instrument_object.getCurrentCloseoutBidAsk()

                # if self.current_trade_steps >= trade_close_least_steps and self.current_trade.getOpenPrice() - ask >= trade_close_trigger_distance:
                #     prediction_max, prediction_min = self._neural_net_predict()
                #     ratio = -prediction_min/prediction_max
                #     if ratio <= trade_close_trigger_ratio:
                #         self.succeeded_close_trials += 1
                #     else:
                #         self.succeeded_close_trials = 0
                #
                #     if self.succeeded_close_trials >= close_trials:
                #         print('** Succeeded close trials reached. Request trade close.')
                #         self.current_trade.close()

                if self.current_trade_steps >= self.current_trade_close_steps:
                    print('** Reach trade close steps. Request trade close.')
                    self.current_trade.close()

            if self.trade_cd > 0:
                print('Trade Colddown '+str(self.trade_cd)+' left.')
                self.trade_cd -= 1

        self.every_15_second_loop_count += 1

    def run(self, BrokerAPI):
        self.test_mode = True
        self.data_scaler = selected_instrument_datascaler_list[primary_intrument_index]

        net = nets.MkNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            print(net.cuda())

        self.net = net

        self.primary_instrument_object = BrokerAPI.getInstrument(primary_intrument_trade)
        self.account = BrokerAPI.getAccount()

        self.nsp = BrokerAPI.getNotificationServiceProvider()
        BrokerAPI.onEvery15Second(self._every_15_second_loop)

    def stop_running(self, BrokerAPI):
        self.nsp.pushImmediately('Running stop', 'Long Pl: %.5f, Counts: %d, Avg: %.5f.\nShort Pl: %.5f, Counts: %d, Avg: %.5f.' % (
            self.total_long_pl, self.total_long_counts, self.total_long_pl/max(self.total_long_counts, 1), self.total_short_pl, self.total_short_counts, self.total_short_pl/max(self.total_short_counts, 1)))

    def train(self, BrokerAPI):

        # for index, instrument_name in enumerate(selected_instrument_list):
        #     hist_data = hist.get_historical_pair_data_pandas(instrument_name, utc.localize(datetime(train_start_year, train_start_month, train_start_day, 0, 0)), utc.localize(datetime(train_end_year, train_end_month, train_end_day, 23, 59)), granularity=fit_granularity)
        #     selected_instrument_datascaler_list[index].fit(hist_data.close)
        # raise

        global learning_rate
        net = nets.MkNet()

        if load_selected_net:
            net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
            print('Net "'+selected_net+'" loaded.')

        net.train()

        if cuda_enabled:
            torch.cuda.empty_cache()
            print(net.cuda())

        dl = dataloader.DataLoader(
            selected_instrument_list,
            selected_instrument_datascaler_list,
            macd_amplifier,
            granularities,
            utc.localize(datetime(train_start_year, train_start_month, train_start_day, 0, 0)),
            utc.localize(datetime(train_end_year, train_end_month, train_end_day, 23, 59)),
            momentum_period=momentum_period, rsi_period=rsi_period, cci_period=cci_period)
        test_dl = dataloader.DataLoader(
            [primary_intrument],
            [selected_instrument_datascaler_list[primary_intrument_index]],
            macd_amplifier,
            granularities,
            utc.localize(datetime(test_start_year, test_start_month, test_start_day, 0, 0)),
            utc.localize(datetime(test_end_year, test_end_month, test_end_day, 23, 59)),
            momentum_period=momentum_period, rsi_period=rsi_period, cci_period=cci_period)

        criterion = torch.nn.MSELoss()
        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        training_batches = dl.generateBatches(batch_counts, batch_size, input_period_list=input_period_list, cci_trigger_granularity=cci_trigger_granularity, inference_granularity=decode_inference_granularity, inference_length=decode_inference_len, prediction_granularity=decode_prediction_granularity, prediction_length=decode_predict_len, prediction_resolution=decode_predict_resolution, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
        test_batches = test_dl.generateBatches(test_batch_counts, batch_size, input_period_list=input_period_list, cci_trigger_granularity=cci_trigger_granularity, inference_granularity=decode_inference_granularity, inference_length=decode_inference_len, prediction_granularity=decode_prediction_granularity, prediction_length=decode_predict_len, prediction_resolution=decode_predict_resolution, neighbors=neighbors, interval=interval, cuda=cuda_enabled)

        loss_list = []
        test_loss_list = []
        print('Training started.')
        for epoch in range(epoch_counts):
            if (epoch - 1) % training_batches_update_epochs == training_batches_update_epochs-1 and epoch != 0:
                del training_batches

                if cuda_enabled:
                    net.cpu()
                    torch.cuda.empty_cache()

                torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/backup.net"))

                if cuda_enabled:
                    net.cuda()

                training_batches = dl.generateBatches(batch_counts, batch_size, input_period_list=input_period_list, cci_trigger_granularity=cci_trigger_granularity, inference_granularity=decode_inference_granularity, inference_length=decode_inference_len, prediction_granularity=decode_prediction_granularity, prediction_length=decode_predict_len, prediction_resolution=decode_predict_resolution, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
                learning_rate = learning_rate*learning_rate_decay
                for param_group in optimizer.param_groups:
                    param_group['lr'] = learning_rate
                print('Training batches updated.')

            running_loss = 0.0
            optimizer.zero_grad()
            steps = 0
            for encode_inputs, encode_times, decode_inputs, decode_times, labels in training_batches:

                outputs = net(encode_inputs, encode_times, decode_inputs, decode_times)

                loss = criterion(outputs, labels)
                running_loss += loss.item()
                loss = loss/batch_accumulation
                loss.backward()

                if (steps+1) == batch_counts or (steps+1)%batch_accumulation == 0:
                    optimizer.step()
                    optimizer.zero_grad()

                steps += 1

            x = list(range(0, decode_predict_resolution))
            # plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(labels[0, :, 0]).tolist(), label='Label-Linear')
            plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(labels[0, :, 0]).tolist(), label='Label-CumMax')
            plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(labels[0, :, 1]).tolist(), label='Label-CumMin')
            # plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(outputs[0, :, 0]).tolist(), label='Predict-Linear')
            plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(outputs[0, :, 0]).tolist(), label='Predict-CumMax')
            plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(outputs[0, :, 1]).tolist(), label='Predict-CumMin')
            plt.legend()
            plt.savefig(self.agent_directory +'/figs/'+ datetime.now().strftime("/MK_%Y_%m_%d_%H_%M.png"))
            plt.clf()

            test_loss = 0.0
            for t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels in test_batches:
                test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)
                test_loss += criterion(test_outputs, t_labels).item()

            print("Epoch: %d, loss: %1.8f, test loss: %1.8f" % (epoch, math.sqrt(running_loss/batch_counts), math.sqrt(test_loss/test_batch_counts)))

            loss_list.append(math.sqrt(running_loss/batch_counts))
            test_loss_list.append(math.sqrt(test_loss/test_batch_counts))
            x = list(range(0, epoch+1))
            plt.plot(x, loss_list, label='Loss')
            plt.plot(x, test_loss_list, label='Test-Loss')
            plt.legend()
            plt.savefig(self.agent_directory + '/loss.png')
            plt.clf()

        if cuda_enabled:
            net.cpu()
        print(self.agent_directory + datetime.now().strftime("/MK_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/MK_%Y_%m_%d_%H_%M.net"))

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        cuda_enabled = False
        self.test_mode = True

        # test_dl = dataloader.DataLoader(
        # selected_instrument_list,
        # selected_instrument_datascaler_list,
        # macd_amplifier,
        # granularities, utc.localize(datetime(2017, 2, 1, 0, 0)), utc.localize(datetime(2018, 7, 29, 23, 59)), momentum_period=momentum_period, rsi_period=rsi_period, cci_period=cci_period)

        test_dl = dataloader.DataLoader(
        # selected_instrument_list,
        # selected_instrument_datascaler_list,
        # macd_amplifier,
        [primary_intrument],
        [selected_instrument_datascaler_list[primary_intrument_index]],
        macd_amplifier,
        granularities, utc.localize(datetime(2021, 2, 1, 0, 0)), utc.localize(datetime(2021, 7, 29, 23, 59)), momentum_period=momentum_period, rsi_period=rsi_period, cci_period=cci_period)

        # test_dl = dataloader.DataLoader(
        # [primary_intrument],
        # [selected_instrument_datascaler_list[primary_intrument_index]],
        # macd_amplifier,
        # granularities, utc.localize(datetime(2018, 1, 1, 0, 0)), utc.localize(datetime(2019, 4, 8, 23, 59)), momentum_period=momentum_period, rsi_period=rsi_period, cci_period=cci_period)

        # test_dl = dataloader.DataLoader(
        # [primary_intrument],
        # [selected_instrument_datascaler_list[primary_intrument_index]],
        # macd_amplifier,
        # granularities, utc.localize(datetime(2005, 1, 1, 0, 0)), utc.localize(datetime(2005, 7, 8, 23, 59)), momentum_period=momentum_period, rsi_period=rsi_period, cci_period=cci_period)

        net = nets.MkNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            net.cuda()

        while(True):
            test_batches = test_dl.generateBatches(1, batch_size, input_period_list=input_period_list, cci_trigger_granularity=cci_trigger_granularity, inference_granularity=decode_inference_granularity, inference_length=decode_inference_len, prediction_granularity=decode_prediction_granularity, prediction_length=decode_predict_len, prediction_resolution=decode_predict_resolution, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
            t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]
            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)
            test_outputs = selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(test_outputs)
            test_outputs[:, :, 0] = test_outputs[:, :, 0].clip(min=torch.finfo(torch.float32).eps)
            test_outputs[:, :, 1] = test_outputs[:, :, 1].clip(max=-torch.finfo(torch.float32).eps)

            for i in range(batch_size):
                prediction_max = torch.max(test_outputs[i, :, 0]).item()
                prediction_min = torch.min(test_outputs[i, :, 1]).item()

                # print('[long] magnitude: %1.6f, ratio: %1.3f [short] magnitude: %1.6f, ratio: %1.3f'%(t_max, -t_max/t_min, -t_min, -t_min/t_max))
                if -prediction_max/prediction_min >= 1:
                    magnitude = prediction_max
                    ratio = -prediction_max/prediction_min
                    triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                    print('[long] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))
                else:
                    magnitude = -prediction_min
                    ratio = -prediction_min/prediction_max
                    triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                    print('[short] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))

                if triggered or True:
                    # if (t_max > tp and t_min > -sl) or (t_min < -tp and t_max < sl):
                    x = list(range(0, decode_predict_resolution))
                    # plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(t_labels[i, :, 0]).tolist(), label='Label-Linear')
                    plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(t_labels[i, :, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(t_labels[i, :, 1]).tolist(), label='Label-CumMin')
                    # plt.plot(x, selected_instrument_datascaler_list[primary_intrument_index].inverse_diff_transform(test_outputs[i, :, 0]).tolist(), label='Predict-Linear')
                    plt.plot(x, test_outputs[i, :, 0].tolist(), label='Predict-CumMax')
                    plt.plot(x, test_outputs[i, :, 1].tolist(), label='Predict-CumMin')
                    plt.legend()
                    plt.ylim(-plot_range, plot_range)
                    plt.show()

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
