#!/usr/bin/python3

import torch, math
import torch.nn as nn
from trading_agents.el005.informer.model import Informer

class ElNet(nn.Module):
    def __init__(self):
        super(ElNet, self).__init__()
        self.decode_inference_len = 60
        self.decode_predict_len = 180
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, dropout=0.1, embed='timeF', freq='t')
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=4, d_layers=3, dropout=0.1, d_model=768, d_ff=768, embed='timeF', freq='t')
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=4, d_layers=3, dropout=0.1, d_model=512, d_ff=512, embed='timeF', freq='t', mix=False)
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=4, d_layers=3, dropout=0.1, d_model=512, d_ff=1024, embed='timeF', freq='t', mix=False)
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=4, d_layers=3, dropout=0.1, d_model=512, d_ff=768, embed='timeF', freq='t')
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=4, d_layers=3, dropout=0.05, d_model=512, d_ff=2048, embed='timeF', freq='t')
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=4, d_layers=2, dropout=0.1, d_model=512, d_ff=2048, embed='timeF', freq='t')
        self.informer = Informer(13, 13, 1, self.decode_predict_len, factor=5, e_layers=2, d_layers=1, dropout=0.1, d_model=512, d_ff=2048, embed='timeF', freq='t')

        # self.informer = Informer(16, 16, 1, self.decode_predict_len, factor=5, e_layers=3, d_layers=2, dropout=0.05, d_model=512, d_ff=2048, embed='timeF', freq='t')
        # self.informer = Informer(16, 16, 1, self.decode_predict_len, d_model=1024, factor=5, e_layers=4, d_layers=3, dropout=0.1, d_ff=1024, embed='timeF', freq='t')

    def forward(self, encode_input, encode_time, decode_input, decode_time):
        # decode_input = torch.zeros(encode_input.size(0), self.decode_predict_len, 24)
        # decode_input = torch.cat([encode_input[:,-self.decode_inference_len:,:], decode_input], dim=1)
        # decode_time = torch.zeros(encode_input.size(0), self.decode_predict_len, 24)
        x = self.informer(encode_input, encode_time, decode_input, decode_time)
        return x

class ElBoundNet(nn.Module):
    def __init__(self, graph_net):
        super(ElBoundNet, self).__init__()
