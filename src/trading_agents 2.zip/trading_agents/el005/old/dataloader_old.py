#!/usr/bin/python3

import torch, random, math

import coin_wizard.historical_pair_data as hist
import numpy as np
from coin_wizard.technical_indicators import TechnicalIndicators
from datetime import datetime, timedelta
from .timefeatures import time_features

import coin_wizard.plotter as plotter

time_delta_1_days = timedelta(days=7)

ti = TechnicalIndicators()

class StandardScaler():
    def __init__(self):
        self.mean = np.array([1.2273361682891846, 1.2273353338241577, -4.135276654437803e-08, -3.0912588044884615e-08, -1.243757026259118e-07, 0.0009936443530023098, 1.2279921770095825, 1.2266820669174194, 0.003407774493098259, -7.524718625973037e-08, 0.002109451685100794, -2.622477097702358e-07, 7.353681212407537e-06, 0.002621428342536092, -2.272962410643231e-05, 1.5240931134030689e-05, 0.003380783135071397, -4.730937689600978e-06, 3.2545165140618337e-07, 0.00021799943351652473, 5.1388461486112647e-08, 0.0007824902422726154, 0.0025639906525611877, 0.00034264076384715736])
        self.std = np.array([0.11677885055541992, 0.11677909642457962, 0.00021748199651483446, 0.0001621376577531919, 0.0003960107278544456, 0.3738138973712921, 0.11691150814294815, 0.11664952337741852, 1.3200619220733643, 0.0001948362769326195, 0.37928664684295654, 0.0003480770392343402, 0.026418078690767288, 0.3656889498233795, 0.048410918563604355, 0.018181707710027695, 0.3695676922798157, 0.033079490065574646, 0.00026352857821621, 0.3785831332206726, 0.0004844216746278107, 0.43189382553100586, 0.3708338439464569, 0.7819598317146301])
        pass

    def fit(self, data):
        self.mean = data.mean(0)
        self.std = data.std(0)
        print('mean:')
        print(self.mean.tolist())
        print('std:')
        print(self.std.tolist())
        print('shape:')
        print(self.std.shape)

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean) / std

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std) + mean

    def inverse_transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i]) + mean[i]

    def inverse_diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i])

class EurUsdDataLoader(object):
    def __init__(self, from_datetime, to_datetime, min_profit=0.0012, max_loss=0.0003):

        if min_profit < max_loss:
            raise

        self.pip=0.0001
        self.jpypip=0.01


        self.eurusd_hist_data = hist.get_historical_pair_data_pandas('eurusd', from_datetime, to_datetime )
        # self.eurusd_hist_data['open'] /= 0.0001 *100
        # self.eurusd_hist_data['high'] /= 0.0001 *100
        # self.eurusd_hist_data['low'] /= 0.0001 *100
        # self.eurusd_hist_data['close'] /= 0.0001 *100

        self.eurusd_hist_data['ma'] = ti.ma(self.eurusd_hist_data.close, 30)
        self.eurusd_hist_data['macd'] = ti.macd(self.eurusd_hist_data.close, 12, 26)
        self.eurusd_hist_data['roc'] = ti.roc(self.eurusd_hist_data.close, 2)
        self.eurusd_hist_data['momentum'] = ti.momentum(self.eurusd_hist_data.close, 4)
        self.eurusd_hist_data['rsi'] = ti.rsi_ema(self.eurusd_hist_data.close, 10)/50.0 - 1.0
        self.eurusd_hist_data['bb_upper'], self.eurusd_hist_data['bb_lower'] = ti.bb(self.eurusd_hist_data.close, 30, 2)
        self.eurusd_hist_data['cci'] = ti.cci(self.eurusd_hist_data.high, self.eurusd_hist_data.low, self.eurusd_hist_data.close, 20)

        self.usdchf_hist_data = hist.get_historical_pair_data_pandas('usdchf', from_datetime, to_datetime )
        # self.usdchf_hist_data['close_usdchf'] = self.usdchf_hist_data['close']
        self.usdchf_hist_data['macd_usdchf'] = ti.macd(self.usdchf_hist_data.close, 12, 26)
        self.usdchf_hist_data['rsi_usdchf'] = ti.rsi_ema(self.usdchf_hist_data.close, 10)/50.0 - 1.0
        self.usdchf_hist_data['momentum_usdchf'] = ti.momentum(self.usdchf_hist_data.close, 4)
        del self.usdchf_hist_data['close']
        del self.usdchf_hist_data['open']
        del self.usdchf_hist_data['high']
        del self.usdchf_hist_data['low']

        self.eurjpy_hist_data = hist.get_historical_pair_data_pandas('eurjpy', from_datetime, to_datetime )
        # self.eurjpy_hist_data['close'] /= 0.01 *100
        # self.eurjpy_hist_data['close_eurjpy'] = self.eurjpy_hist_data['close']
        self.eurjpy_hist_data['macd_eurjpy'] = ti.macd(self.eurjpy_hist_data.close, 12, 26)
        self.eurjpy_hist_data['rsi_eurjpy'] = ti.rsi_ema(self.eurjpy_hist_data.close, 10)/50.0 - 1.0
        self.eurjpy_hist_data['momentum_eurjpy'] = ti.momentum(self.eurjpy_hist_data.close, 4)
        del self.eurjpy_hist_data['close']
        del self.eurjpy_hist_data['open']
        del self.eurjpy_hist_data['high']
        del self.eurjpy_hist_data['low']

        self.usdjpy_hist_data = hist.get_historical_pair_data_pandas('usdjpy', from_datetime, to_datetime )
        # self.usdjpy_hist_data['close'] /= 0.01 *100
        # self.usdjpy_hist_data['close_usdjpy'] = self.usdjpy_hist_data['close']
        self.usdjpy_hist_data['macd_usdjpy'] = ti.macd(self.usdjpy_hist_data.close, 12, 26)
        self.usdjpy_hist_data['rsi_usdjpy'] = ti.rsi_ema(self.usdjpy_hist_data.close, 10)/50.0 - 1.0
        self.usdjpy_hist_data['momentum_usdjpy'] = ti.momentum(self.usdjpy_hist_data.close, 4)
        del self.usdjpy_hist_data['close']
        del self.usdjpy_hist_data['open']
        del self.usdjpy_hist_data['high']
        del self.usdjpy_hist_data['low']

        self.gbpusd_hist_data = hist.get_historical_pair_data_pandas('gbpusd', from_datetime, to_datetime )
        # self.gbpusd_hist_data['close'] /= 0.0001 *100
        # self.gbpusd_hist_data['close_gbpusd'] = self.gbpusd_hist_data['close']
        self.gbpusd_hist_data['macd_gbpusd'] = ti.macd(self.gbpusd_hist_data.close, 12, 26)
        self.gbpusd_hist_data['rsi_gbpusd'] = ti.rsi_ema(self.gbpusd_hist_data.close, 10)/50.0 - 1.0
        self.gbpusd_hist_data['momentum_gbpusd'] = ti.momentum(self.gbpusd_hist_data.close, 4)
        del self.gbpusd_hist_data['close']
        del self.gbpusd_hist_data['open']
        del self.gbpusd_hist_data['high']
        del self.gbpusd_hist_data['low']

        self.xauusd_hist_data = hist.get_historical_pair_data_pandas('xauusd', from_datetime, to_datetime )
        # self.xauusd_hist_data['close'] /= 0.01 *100
        # self.xauusd_hist_data['close_xauusd'] = self.xauusd_hist_data['close']
        self.xauusd_hist_data['macd_xauusd'] = ti.macd(self.xauusd_hist_data.close, 12, 26)
        self.xauusd_hist_data['rsi_xauusd'] = ti.rsi_ema(self.xauusd_hist_data.close, 10)/50.0 - 1.0
        self.xauusd_hist_data['momentum_xauusd'] = ti.momentum(self.xauusd_hist_data.close, 4)
        del self.xauusd_hist_data['close']
        del self.xauusd_hist_data['open']
        del self.xauusd_hist_data['high']
        del self.xauusd_hist_data['low']


        # del self.eurusd_hist_data['open']
        # del self.eurusd_hist_data['high']
        # del self.eurusd_hist_data['low']

        self.first_valid_idex = 26

        self.hist_data = self.eurusd_hist_data.merge(self.usdchf_hist_data, how='inner', on='timestamp')
        self.hist_data = self.hist_data.merge(self.eurjpy_hist_data, how='inner', on='timestamp')
        self.hist_data = self.hist_data.merge(self.usdjpy_hist_data, how='inner', on='timestamp')
        self.hist_data = self.hist_data.merge(self.gbpusd_hist_data, how='inner', on='timestamp')
        self.hist_data = self.hist_data.merge(self.xauusd_hist_data, how='inner', on='timestamp')
        self.hist_data = self.hist_data[self.first_valid_idex:].reset_index(drop=True)

        print(self.hist_data[-1:])

        self.hist_data_np = np.array([
            self.hist_data.close.to_list(),
            self.hist_data.ma.to_list(),
            self.hist_data.macd.to_list(),
            self.hist_data.roc.to_list(),
            self.hist_data.momentum.to_list(),
            self.hist_data.rsi.to_list(),
            self.hist_data.bb_upper.to_list(),
            self.hist_data.bb_lower.to_list(),
            self.hist_data.cci.to_list(),
            self.hist_data.macd_usdchf.to_list(),
            self.hist_data.rsi_usdchf.to_list(),
            self.hist_data.momentum_usdchf.to_list(),
            self.hist_data.macd_eurjpy.to_list(),
            self.hist_data.rsi_eurjpy.to_list(),
            self.hist_data.momentum_eurjpy.to_list(),
            self.hist_data.macd_usdjpy.to_list(),
            self.hist_data.rsi_usdjpy.to_list(),
            self.hist_data.momentum_usdjpy.to_list(),
            self.hist_data.macd_gbpusd.to_list(),
            self.hist_data.rsi_gbpusd.to_list(),
            self.hist_data.momentum_gbpusd.to_list(),
            self.hist_data.macd_xauusd.to_list(),
            self.hist_data.rsi_xauusd.to_list(),
            self.hist_data.momentum_xauusd.to_list(),
        ], dtype=np.float32)

        self.hist_data_np = np.swapaxes(self.hist_data_np, 0, 1)
        ds = StandardScaler()
        # ds.fit(self.hist_data_np)
        # raise
        self.data_scaler = ds
        self.hist_data_np = ds.transform(self.hist_data_np)

        self.time_np = time_features(self.hist_data['timestamp'], freq='t')
        print(self.time_np)
        np.nan_to_num(self.hist_data_np, nan=0, posinf=0, neginf=0)
        # raise

    def convertToCloseRaw(self, data):
        return self.data_scaler.inverse_transform_index(0, data)

    def convertToCloseDiffRaw(self, data):
        return self.data_scaler.inverse_diff_transform_index(0, data)

    def generateBatches(self, batch_counts, batch_size, input_period=960, inference_len=120, out_length=240, cuda=True):
        batch_list = []
        hist_data = self.hist_data_np
        time = self.time_np
        for i in range(batch_counts):
            encode_inputs = []
            encode_times = []
            decode_inputs = []
            decode_times = []
            labels = []

            j = 0
            up_counts = 0
            down_counts = 0
            while j < batch_size:
                randomed_index = random.randint(0, hist_data.shape[0] - (input_period + out_length))

                encode_input = hist_data[randomed_index:randomed_index+input_period, :]
                encode_time = time[randomed_index:randomed_index+input_period, :]
                decode_input = np.zeros((out_length, 24))
                decode_input = np.concatenate([hist_data[randomed_index+input_period-inference_len:randomed_index+input_period, :], decode_input], axis=0)
                decode_time = time[randomed_index+input_period-inference_len:randomed_index+input_period+out_length, :]
                # label = prediction_np[randomed_index:randomed_index+input_period]
                label = hist_data[randomed_index+input_period:randomed_index+input_period+out_length, 1:2] - hist_data[randomed_index+input_period-1, 1]

                encode_inputs.append(encode_input)
                encode_times.append(encode_time)
                decode_inputs.append(decode_input)
                decode_times.append(decode_time)
                labels.append(label)
                j += 1

            encode_inputs = torch.tensor(encode_inputs, dtype=torch.float32)
            encode_times = torch.tensor(encode_times, dtype=torch.float32)
            decode_inputs = torch.tensor(decode_inputs, dtype=torch.float32)
            decode_times = torch.tensor(decode_times, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.float32)

            if cuda:
                encode_inputs = encode_inputs.cuda()
                encode_times = encode_times.cuda()
                decode_inputs = decode_inputs.cuda()
                decode_times = decode_times.cuda()
                labels = labels.cuda()

            batch_list.append([encode_inputs, encode_times, decode_inputs, decode_times, labels])

        return batch_list
