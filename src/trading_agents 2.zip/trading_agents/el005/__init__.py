#!/usr/bin/python3

import pytz, torch, math, os
from datetime import datetime

import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import trading_agents.el005.nets as nets
import trading_agents.el005.dataloader as dataloader
import matplotlib.pyplot as plt
from .timefeatures import time_features

from coin_wizard.technical_indicators import TechnicalIndicators

utc = pytz.utc

### Global settings ###
verbose = True
input_period = 720
decode_inference_len = 60
decode_predict_len = 105 # 105
cuda_enabled = True
# cuda_enabled = False
selected_net = 'backup.net'
# selected_net = '60_512_1024_4.net'

### Indicator settings ###
moving_average = 9
roc_period=9
rsi_period=14
cci_period=20

### Train settings ###
load_selected_net = False
learning_rate = 0.0001 * 0.1
learning_rate = learning_rate # *0.03752413921
learning_rate_decay = 0.9
epoch_counts = 512*1 # 6
batch_counts = 512*2
batch_size = 16
training_batches_update_epochs = 4

train_start_year = 2014
train_start_month = 1
train_start_day = 1
train_end_year = 2020
train_end_month = 12
train_end_day = 29

test_start_year = 2021
test_start_month = 1
test_start_day = 1
test_end_year = 2021
test_end_month = 4
test_end_day = 8

### Running settings ###
net_moving_average = 2
close_steps = decode_predict_len
additional_period = 350
backtesting_plot = False
backtesting_plot = True
backtesting_plot_pause = 0.001
min_profit_trigger_threshold = 0.0006
max_loss_trigger_threshold = 0.0002
trailing_stop_distance = 0.0005
risk_reward_ratio = 0.75
adjustment_ratio = 1.2
ema_calibration_ratio = 0.25
ema_close_diff_tolerance = 0.0005
ema_calibration_cut_out = 3
# ema_offset_tolerance = 0.0001

import coin_wizard.plotter as plotter

ti = TechnicalIndicators()

class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        if not os.path.exists(os.path.join(agent_directory, 'figs')):
            os.makedirs(os.path.join(agent_directory, 'figs'))
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 0

        self.nsp = None
        self.net = None
        self.position = 0

        self.current_trade = None
        self.current_trade_total_steps = 0
        self.current_trade_best_profit = 0
        self.current_trade_worst_loss = 0
        self.current_trade_steps = 0
        self.current_trade_close_steps = 0

        self.total_long_counts = 0
        self.total_short_counts = 0

        self.total_long_pl = 0
        self.total_short_pl = 0

    def _order_canceled_listener(self, order, reason):
        self.position = 0

    def _order_filled_listener(self, order, trade):
        # Record stats
        if trade.getTradeSettings()['units'] > 0:
            self.total_long_counts += 1
        else:
            self.total_short_counts += 1

        self.current_trade = trade
        trade.onReduced(self._trade_reduced_listener)
        trade.onClosed(self._trade_closed_listener)

    def _trade_reduced_listener(self, trade, units, realized_pl, close_price, spread, timestamp):
        pass

    def _trade_closed_listener(self, trade, realized_pl, close_price, spread, timestamp):
        # Record stats
        if trade.getTradeSettings()['units'] > 0:
            self.total_long_pl += realized_pl
        else:
            self.total_short_pl += realized_pl

        self.position = 0

        self.nsp.pushImmediately('Trade closed', 'Trade closed after %d total steps. PL: %.5f. Best profit: %.5f. Worst loss: %.5f.' % (
            self.current_trade_steps, realized_pl, self.current_trade_best_profit, self.current_trade_worst_loss))

    def _every_15_second_loop(self, BrokerAPI):

        # Is not tradable
        if not self.eurusd_inst.isTradable():
            return

        # Every one minute = 4*15 seconds
        if self.every_15_second_loop_count % 4 == 0:
            self.every_15_second_loop_count = 0

            # Prepare EurUsd data
            eurusd_hist_data = self.eurusd_inst.getRecent1MCandles(input_period+additional_period)
            eurusd_hist_data['ema'] = ti.ema(eurusd_hist_data.close, moving_average)
            eurusd_hist_data['macd'] = ti.macd(eurusd_hist_data.close, 12, 26)
            eurusd_hist_data['roc'] = ti.roc(eurusd_hist_data.close, roc_period)
            eurusd_hist_data['rsi'] = ti.rsi_ema(eurusd_hist_data.close, rsi_period)
            eurusd_hist_data['cci'] = ti.cci(eurusd_hist_data.high, eurusd_hist_data.low, eurusd_hist_data.close, cci_period)
            del eurusd_hist_data['open']
            del eurusd_hist_data['high']
            del eurusd_hist_data['low']

            # Prepare GbpUsd data
            gbpusd_hist_data = self.gbpusd_inst.getRecent1MCandles(input_period+additional_period)
            gbpusd_hist_data['macd_gbpusd'] = ti.macd(gbpusd_hist_data.close, 12, 26)
            gbpusd_hist_data['roc_gbpusd'] = ti.roc(gbpusd_hist_data.close, roc_period)
            gbpusd_hist_data['rsi_gbpusd'] = ti.rsi_ema(gbpusd_hist_data.close, rsi_period)
            gbpusd_hist_data['cci_gbpusd'] = ti.cci(gbpusd_hist_data.high, gbpusd_hist_data.low, gbpusd_hist_data.close, cci_period)
            del gbpusd_hist_data['open']
            del gbpusd_hist_data['high']
            del gbpusd_hist_data['low']

            # Prepare EurJpy data
            eurjpy_hist_data = self.eurjpy_inst.getRecent1MCandles(input_period+additional_period)
            eurjpy_hist_data['macd_eurjpy'] = ti.macd(eurjpy_hist_data.close, 12, 26)
            eurjpy_hist_data['roc_eurjpy'] = ti.roc(eurjpy_hist_data.close, roc_period)
            eurjpy_hist_data['rsi_eurjpy'] = ti.rsi_ema(eurjpy_hist_data.close, rsi_period)
            eurjpy_hist_data['cci_eurjpy'] = ti.cci(eurjpy_hist_data.high, eurjpy_hist_data.low, eurjpy_hist_data.close, cci_period)
            del eurjpy_hist_data['open']
            del eurjpy_hist_data['high']
            del eurjpy_hist_data['low']

            # Since period is set 30
            self.first_valid_idex = 30

            # Merge data
            hist_data = eurusd_hist_data.merge(gbpusd_hist_data, how='inner', on='timestamp')
            hist_data = hist_data.merge(eurjpy_hist_data, how='inner', on='timestamp')
            hist_data = hist_data[self.first_valid_idex:].reset_index(drop=True)

            # Make input tensor
            input = np.array([
                hist_data.ema.to_list(),
                hist_data.macd.to_list(),
                hist_data.roc.to_list(),
                hist_data.rsi.to_list(),
                hist_data.cci.to_list(),
                hist_data.macd_gbpusd.to_list(),
                hist_data.roc_gbpusd.to_list(),
                hist_data.rsi_gbpusd.to_list(),
                hist_data.cci_gbpusd.to_list(),
                hist_data.macd_eurjpy.to_list(),
                hist_data.roc_eurjpy.to_list(),
                hist_data.rsi_eurjpy.to_list(),
                hist_data.cci_eurjpy.to_list(),
            ], dtype=np.float32)
            input = np.swapaxes(input, 0, 1)
            input = self.data_scaler.transform(input)
            times = time_features(hist_data['timestamp'], freq='t')

            # Moving average implementation
            encode_inputs_list = []
            encode_times_list = []
            decode_inputs_list = []
            decode_times_list = []

            for i in range(net_moving_average):
                encode_inputs = (input[-(input_period+(i)):, :])[:input_period, :]
                encode_times = (times[-(input_period+(i)):, :])[:input_period, :]
                decode_inputs = np.zeros((decode_inference_len+decode_predict_len, 13), dtype=float)
                decode_inputs[:decode_inference_len, :] = input[-decode_inference_len:, :]
                decode_times = time_features(pd.date_range(start=eurusd_hist_data['timestamp'].tail(1).iloc[0], periods=decode_predict_len, freq='T'), freq='t')
                decode_times = np.concatenate((times[-decode_inference_len:, :], decode_times))

                encode_inputs_list.append(encode_inputs)
                encode_times_list.append(encode_times)
                decode_inputs_list.append(decode_inputs)
                decode_times_list.append(decode_times)

            encode_inputs = torch.tensor(encode_inputs_list, dtype=torch.float32)
            encode_times = torch.tensor(encode_times_list, dtype=torch.float32)
            decode_inputs = torch.tensor(decode_inputs_list, dtype=torch.float32)
            decode_times = torch.tensor(decode_times_list, dtype=torch.float32)

            if cuda_enabled:
                encode_inputs = encode_inputs.cuda()
                encode_times = encode_times.cuda()
                decode_inputs = decode_inputs.cuda()
                decode_times = decode_times.cuda()

            outputs = self.net(encode_inputs, encode_times, decode_inputs, decode_times)

            del encode_inputs
            del encode_times
            del decode_inputs
            del decode_times

            # Normalize
            bid, ask, timestamp = self.eurusd_inst.getCurrentCloseoutBidAsk()
            mid = 0.5*(bid+ask)
            ema_closed = eurusd_hist_data['ema'].tail(1).iloc[0]

            outputs = outputs.sum(0, keepdim=True)/net_moving_average
            prediction = adjustment_ratio*self.data_scaler.inverse_diff_transform_index(0, outputs[0, ema_calibration_cut_out:, 0]-outputs[0, ema_calibration_cut_out, 0])+ema_calibration_ratio*(ema_closed-mid)
            prediction_max = torch.max(prediction).item()
            prediction_min = torch.min(prediction).item()

            # Plot for backtesting.
            if backtesting_plot == True:
                x = list(range(0, decode_predict_len-ema_calibration_cut_out))
                labels = self.eurusd_inst.foreseeFutureCandles1M(decode_predict_len-ema_calibration_cut_out)
                labels = torch.tensor(labels['close'].tolist())
                labels = labels - eurusd_hist_data['close'].tail(1).iloc[0]
                plt.plot(x, labels.tolist(), label='Label')
                plt.plot(x, (adjustment_ratio*self.data_scaler.inverse_diff_transform_index(0, outputs[0, ema_calibration_cut_out:, 0]-outputs[0, ema_calibration_cut_out, 0])+ema_calibration_ratio*(ema_closed-mid)).tolist(), label='Predict-'+str(i))
                plt.legend()
                plt.ylim(-0.0015, 0.0015)
                plt.show(block=False)
                plt.pause(backtesting_plot_pause)
                plt.close()

            # Trading algorithm
            units = 1000/0.02

            if verbose:
                print(timestamp, 'bid: %.5f, ask: %.5f, prediction_max: %.5f, prediction_min: %.5f,'%(bid, ask, prediction_max, prediction_min))

            if self.position == 0:
                if (prediction_max > min_profit_trigger_threshold and prediction_min > -max_loss_trigger_threshold):
                    self.position = 1
                    self.current_trade_best_profit = 0
                    self.current_trade_worst_loss = 0
                    self.current_trade_steps = 0
                    self.current_trade_close_steps = close_steps
                    self.current_trade_take_profit = round(bid + prediction_max, 8)

                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": units,
                                            # "take_profit": round(bid + prediction_max, 8),
                                            "stop_lost":  round(bid - prediction_max*risk_reward_ratio, 8),
                                            "trailing_stop_distance": round(trailing_stop_distance, 8)})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)

                elif (prediction_min < -min_profit_trigger_threshold and prediction_max < max_loss_trigger_threshold):
                    self.position = 2
                    self.current_trade_best_profit = 0
                    self.current_trade_worst_loss = 0
                    self.current_trade_steps = 0
                    self.current_trade_close_steps = close_steps
                    self.current_trade_take_profit = round(ask + prediction_min, 8)

                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": -units,
                                            # "take_profit": round(ask + prediction_min, 8),
                                            "stop_lost": round(ask - prediction_min*risk_reward_ratio, 8),
                                            "trailing_stop_distance": round(trailing_stop_distance, 8)})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)

            elif self.position == 1:
                self.current_trade_steps += 1

                if self.current_trade_best_profit < self.current_trade.getUnrealizedPL():
                    self.current_trade_best_profit = self.current_trade.getUnrealizedPL()

                if self.current_trade_worst_loss > self.current_trade.getUnrealizedPL():
                    self.current_trade_worst_loss = self.current_trade.getUnrealizedPL()

                if self.current_trade_steps >= self.current_trade_close_steps or bid > self.current_trade_take_profit:
                    if (prediction_max > min_profit_trigger_threshold and prediction_min > -max_loss_trigger_threshold):
                        self.current_trade_take_profit = round(bid + prediction_max*risk_reward_ratio, 8)
                        self.current_trade_close_steps += close_steps
                    else:
                        self.current_trade.close()

            elif self.position == 2:
                self.current_trade_steps += 1

                if self.current_trade_best_profit < self.current_trade.getUnrealizedPL():
                    self.current_trade_best_profit = self.current_trade.getUnrealizedPL()

                if self.current_trade_worst_loss > self.current_trade.getUnrealizedPL():
                    self.current_trade_worst_loss = self.current_trade.getUnrealizedPL()

                if self.current_trade_steps >= self.current_trade_close_steps or ask < self.current_trade_take_profit:
                    if (prediction_min < -min_profit_trigger_threshold and prediction_max < max_loss_trigger_threshold):
                        self.current_trade_take_profit = round(ask + prediction_min*risk_reward_ratio, 8)
                        self.current_trade_close_steps += close_steps
                    else:
                        self.current_trade.close()

        self.every_15_second_loop_count += 1

    def run(self, BrokerAPI):
        self.test_mode = True
        self.data_scaler = dataloader.StandardScaler()

        net = nets.ElNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            print(net.cuda())

        self.net = net

        self.eurusd_inst = BrokerAPI.getInstrument('EUR_USD')
        self.eurjpy_inst = BrokerAPI.getInstrument('EUR_JPY')
        self.gbpusd_inst = BrokerAPI.getInstrument('GBP_USD')
        self.account = BrokerAPI.getAccount()

        self.nsp = BrokerAPI.getNotificationServiceProvider()
        BrokerAPI.onEvery15Second(self._every_15_second_loop)

    def stop_running(self, BrokerAPI):
        self.nsp.pushImmediately('Running stop', 'Long Pl: %.5f, Counts: %d, Avg: %.5f.\nShort Pl: %.5f, Counts: %d, Avg: %.5f.' % (
            self.total_long_pl, self.total_long_counts, self.total_long_pl/max(self.total_long_counts, 1), self.total_short_pl, self.total_short_counts, self.total_short_pl/max(self.total_short_counts, 1)))

    def train(self, BrokerAPI):
        global learning_rate
        net = nets.ElNet()

        if load_selected_net:
            net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))

        net.train()

        if cuda_enabled:
            print(net.cuda())

        dl = dataloader.EurUsdDataLoader(
            utc.localize(datetime(train_start_year, train_start_month, train_start_day, 0, 0)),
            utc.localize(datetime(train_end_year, train_end_month, train_end_day, 23, 59)),
            moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)
        test_dl = dataloader.EurUsdDataLoader(
            utc.localize(datetime(test_start_year, test_start_month, test_start_day, 0, 0)),
            utc.localize(datetime(test_end_year, test_end_month, test_end_day, 23, 59)),
            moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)

        criterion = torch.nn.MSELoss()
        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        training_batches = dl.generateBatches(batch_counts, batch_size, input_period=input_period, out_length=decode_predict_len, cuda=cuda_enabled)
        test_batches = test_dl.generateBatches(1, batch_size, input_period=input_period, out_length=decode_predict_len, cuda=cuda_enabled)
        t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]

        for epoch in range(epoch_counts):
            if (epoch - 1) % training_batches_update_epochs == training_batches_update_epochs-1 and epoch != 0:
                del training_batches

                if cuda_enabled:
                    net.cpu()
                    torch.cuda.empty_cache()

                torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/backup.net"))

                if cuda_enabled:
                    net.cuda()

                training_batches = dl.generateBatches(batch_counts, batch_size, input_period=input_period, out_length=decode_predict_len, cuda=cuda_enabled)
                learning_rate = learning_rate*learning_rate_decay
                for param_group in optimizer.param_groups:
                    param_group['lr'] = learning_rate
                print('Training batches updated.')

            running_loss = 0.0
            for encode_inputs, encode_times, decode_inputs, decode_times, labels in training_batches:

                outputs = net(encode_inputs, encode_times, decode_inputs, decode_times)
                optimizer.zero_grad()

                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()
                running_loss += loss.item()

            x = list(range(0, decode_predict_len))
            plt.plot(x, dl.convertToCloseDiffRaw(labels[0, :, 0]).tolist(), label='Label')
            plt.plot(x, dl.convertToCloseDiffRaw(outputs[0, :, 0]).tolist(), label='Predict')
            plt.legend()
            plt.savefig(self.agent_directory +'/figs/'+ datetime.now().strftime("/EL_%Y_%m_%d_%H_%M.png"))
            plt.clf()

            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)
            test_loss = criterion(test_outputs, t_labels)

            print("Epoch: %d, loss: %1.8f, test loss: %1.8f" % (epoch, math.sqrt(running_loss/batch_counts), math.sqrt(test_loss.item())))


        if cuda_enabled:
            net.cpu()
        print(self.agent_directory + datetime.now().strftime("/EL_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/EL_%Y_%m_%d_%H_%M.net"))

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        cuda_enabled = False
        self.test_mode = True
        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 2, 1, 0, 0)), utc.localize(datetime(2021, 2, 28, 23, 59)), moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)
        # test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 2, 1, 0, 0)), utc.localize(datetime(2021, 5, 29, 23, 59)), moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)
        # test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2020, 1, 1, 0, 0)), utc.localize(datetime(2020, 4, 8, 23, 59)), moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)

        net = nets.ElNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            net.cuda()

        while(True):
            test_batches = test_dl.generateBatches(1, batch_size, input_period=input_period, out_length=decode_predict_len, cuda=cuda_enabled)
            t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]
            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)

            for i in range(batch_size):
                t = test_dl.convertToCloseDiffRaw(test_outputs[i, :, 0])
                t_max = torch.max(t).item()
                t_min = torch.min(t).item()
                print(t_max, t_min)
                sl = 0.0003
                tp = 0.003
                # if (t_max > tp and t_min > -sl) or (t_min < -tp and t_max < sl):
                x = list(range(0, decode_predict_len))
                plt.plot(x, test_dl.convertToCloseDiffRaw(t_labels[i, :, 0]).tolist(), label='Close')
                plt.plot(x, test_dl.convertToCloseDiffRaw(test_outputs[i, :, 0]).tolist(), label='Predict')
                plt.legend()
                plt.show()

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
