
class AccountBook:
    def __init__(self):
        return

    def appendTrade(self, trade):
        raise NotImplementedError('Not implemented.')
