from ..gym import Gym


class HistDataGym(Gym):
    def __init__(self, instrument_list, primary_intrument, granularity, input_period, from_datetime, to_datetime, episode_steps):
        self.on_step_callback = None

    def generateOutSpecs(self):
        return

    def start(self):
        raise NotImplementedError('Not implemented.')

    def onStep(self, callback):
        self.on_step_callback = callback
        # action = callback(finished, state)
        # raise NotImplementedError('Not implemented.')
