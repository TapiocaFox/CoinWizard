from utils import ConfigLoader, calculate_gamma, plot_list, pretty_print, plot_tensor
from pipelines.ohlc_pandas_to_torch import OhlcPandasToTorchPipeline
from pipelines.remove_type import RemoveTypePipeline
from pipeline_array import PipelineArray

config = ConfigLoader('config.json')
ppo_agent_config = ConfigLoader('ppo_agent_config.json')
training_config = ConfigLoader('training_config.json')

# Generic config


# PPO agent config


# Training config
episode_steps = training_config.get('episode_steps')
episodes_rounds = training_config.get('episodes_rounds')
primary_instrument_spread = training_config.get('primary_instrument_spread')
train_from_datetime = training_config.getDate('train_start_year', 'train_start_month', 'train_start_day', 'start_hour', 'start_min')
train_to_datetime = training_config.getDate('train_end_year', 'train_end_month', 'train_end_day', 'end_hour', 'end_min')
test_from_datetime = training_config.getDate('test_start_year', 'test_start_month', 'test_start_day', 'start_hour', 'start_min')
test_to_datetime = training_config.getDate('test_end_year', 'test_end_month', 'test_end_day', 'end_hour', 'end_min')

PipelineArray([OhlcPandasToTorchPipeline(), RemoveTypePipeline('candle_stick')], {'instrument_list': ['eurusd'], 'open_prefix': 'open', 'high_prefix': 'high', 'low_prefix': 'low', 'close_prefix': 'close'})
