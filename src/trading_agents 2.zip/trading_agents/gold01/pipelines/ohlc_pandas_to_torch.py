from .pipeline import Pipeline
from torch import Tensor
from pandas import DataFrame
import copy

class OhlcPandasToTorchPipeline(Pipeline):
    def __init__(self):
        super().__init__(DataFrame, Tensor)

    def setupInSpecs(self, in_specs):
        self.in_specs = in_specs
        self.instrument_list = in_specs['instrument_list']
        self.open_prefix = in_specs['open_prefix']
        self.high_prefix = in_specs['high_prefix']
        self.low_prefix = in_specs['low_prefix']
        self.close_prefix = in_specs['close_prefix']
        self.out_specs = None

    def generateOutSpecs(self):
        if self.out_specs is not None:
            return self.out_specs

        self.out_specs = copy.deepcopy(self.in_specs)
        tensor_feature_description_list = []
        instrument_ohlc_index_dict = {}
        for i, instrument in enumerate(self.instrument_list):
            tensor_feature_description_list.append({'type': 'candle_stick', 'instrument': instrument, 'ohlc': 'open'})
            tensor_feature_description_list.append({'type': 'candle_stick', 'instrument': instrument, 'ohlc': 'high'})
            tensor_feature_description_list.append({'type': 'candle_stick', 'instrument': instrument, 'ohlc': 'low'})
            tensor_feature_description_list.append({'type': 'candle_stick', 'instrument': instrument, 'ohlc': 'close'})
            base_index = 4*i
            instrument_ohlc_index_dict[instrument] = [base_index, base_index+1, base_index+2, base_index+3]
        # Generic.
        self.out_specs['tensor_feature_description_list'] = tensor_feature_description_list
        # Candle stick specific.
        # self.out_specs['instrument_ohlc_index_dict'] = instrument_ohlc_index_dict
        # self.out_specs['type_candle_stick_range_list'] = [(0, 4*len(self.instrument_list))]
        return self.out_specs

    def reset(self):
        raise NotImplementedError('Not implemented.')

    def _process(self, data):
        return

# Debug codes
# p = OhlcPandasToTorchPipeline(int, int)
# p.process(1, 2)
# print(OhlcPandasToTorch==Pipeline)
