

class Pipeline:
    def __init__(self, in_type, out_type):
        self.in_type = in_type
        self.out_type = out_type

    def _process(self, data, specs):
        raise NotImplementedError('Not implemented.')
        # return

    def setupInSpecs(self, in_specs):
        raise NotImplementedError('Not implemented.')

    def generateOutSpecs(self):
        raise NotImplementedError('Not implemented.')

    def reset(self):
        raise NotImplementedError('Not implemented.')
        # return

    def process(self, data):
        if not isinstance(data, self.in_type):
            raise TypeError('Expect type "%s" as pipeline\'s input.'%(str(self.in_type)))
        out = self._process(data)
        if not isinstance(out, self.out_type):
            raise TypeError('Expect type "%s" as pipeline\'s output.'%(str(self.out_type)))
        return out

# Debug codes
# p = Pipeline()
# p.process(1, 2)
# print(Pipeline==Pipeline)
