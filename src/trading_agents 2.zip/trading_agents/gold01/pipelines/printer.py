from .pipeline import Pipeline

class PrinterPipeline(Pipeline):
    def __init__(self, in_type, in_specs, out_type):
        super().__init__(in_type, in_specs, out_type)

    def generateOutSpecs(self):
        raise NotImplementedError('Not implemented.')

    def reset(self):
        raise NotImplementedError('Not implemented.')
        
    def _process(self, data, specs):
        return

# Debug codes
# p = OhlcPandasToTorch(int, int)
# p.process(1, 2)
# print(OhlcPandasToTorch==Pipeline)
