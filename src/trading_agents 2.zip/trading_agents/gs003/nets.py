#!/usr/bin/python3

import torch, math
import torch.nn as nn

# http://nlp.seas.harvard.edu/2018/04/03/attention.html

class GsTwolNet(nn.Module):
    def __init__(target_length=30):
        super(FrNet).__init__()
        self.transformer = nn.Transformer()


class GsAttentionLayer(nn.Module):
    def __init__(self, input_size, attention_vector_size, std, dim=-1):
        super(GsAttentionLayer, self).__init__()
        self.std = std
        self.normal_const = (1/(std*math.sqrt(2*math.pi)))

        self.tanh = nn.Tanh()
        self.sigmoid = nn.Sigmoid()

        self.pointer_weight = nn.Linear(attention_vector_size, input_size)
        self.pointer_vector = nn.Linear(input_size, 1)

        self.general_attention_weight = nn.Linear(attention_vector_size, input_size)
        self.softmax = nn.Softmax(dim=1)

    def get_locational_mask(self, pointers, from_index, to_index):
        batch_size = pointers.size(0)

        means = pointers.expand(-1, to_index-from_index, -1)

        if pointers.get_device() >= 0:
            base_tensor = torch.arange(from_index, to_index).to(pointers.get_device())
        else:
            base_tensor = torch.arange(from_index, to_index)

        base_tensor = base_tensor[None, :, None]
        base_tensor = base_tensor.expand(batch_size, -1, -1)

        mask = torch.exp(-0.5*torch.pow((base_tensor - means)/self.std, 2))
        # mask = self.normal_const*torch.exp(-0.5*torch.pow((base_tensor - means)/self.std, 2))
        return mask

    def forward(self, input, attention_vector):
        input_length = input.size(1)

        pointers = input_length*self.sigmoid(self.pointer_vector(self.tanh(self.pointer_weight(attention_vector))))
        # print(pointers)
        locational_mask = self.get_locational_mask(pointers, 1, input_length+1)

        general_attention_vector = self.general_attention_weight(attention_vector)

        # print(torch.bmm(input, general_attention_vector.swapaxes(1, 2)).shape)
        attention_bar = self.softmax(torch.bmm(input, general_attention_vector.swapaxes(1, 2)))
        # print(attention_bar)
        attention = attention_bar*locational_mask

        # attention = locational_mask

        # print(locational_mask)

        x = torch.bmm(attention.swapaxes(1, 2), input)

        return x

class GsNet(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, window_size=360, dropout_p=0.1):
        super(GsNet, self).__init__()

        self.num_layers = 2
        self.hidden_size = hidden_size

        self.tanh = nn.Tanh()
        self.sigmoid = nn.Sigmoid()

        self.gru = nn.GRU(input_size, hidden_size, num_layers=self.num_layers, batch_first=True, bidirectional=True)
        std = window_size/4.0
        self.dropout = nn.Dropout(dropout_p)
        self.attention = GsAttentionLayer(hidden_size*2, hidden_size*4, std=std)
        self.fc1 = nn.Linear(hidden_size*2, hidden_size*2)
        self.fc2 = nn.Linear(hidden_size*2, output_size)

    def forward(self, input):
        if input.get_device() >= 0:
            h_0 = torch.zeros(self.num_layers*2, input.size(0), self.hidden_size).to(input.get_device())
        else:
            h_0 = torch.zeros(self.num_layers*2, input.size(0), self.hidden_size)

        x, _ = self.gru(input, h_0)
        attention_vector = torch.cat((x[:, -1:, :], x[:, :1, :]), 2)
        x = self.attention(x, self.dropout(attention_vector))
        x = self.tanh(self.fc1(x))
        x = self.sigmoid(self.fc2(x))
        return x
