#!/usr/bin/python3

import pytz, torch, math, os
from datetime import datetime, timedelta

import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import trading_agents.kt007.nets as nets
import trading_agents.kt007.dataloader as dataloader
import matplotlib.pyplot as plt
from .timefeatures import time_features

from coin_wizard.technical_indicators import TechnicalIndicators

utc = pytz.utc

### Global settings ###
verbose = False
input_period = 4*24*4
# input_period = 720
decode_inference_len = 48
decode_predict_len = 48
cuda_enabled = True
# cuda_enabled = False
selected_net = 'backup.net'
# selected_net = '720.net'

### Indicator settings ###
moving_average = 9
roc_period=9
rsi_period=14
cci_period=20

### Train settings ###
load_selected_net = False
learning_rate = 0.0001 * 0.1
# learning_rate = learning_rate * 0.69833729609
learning_rate_decay = 0.95**1
epoch_counts = int(512*1) # 6
batch_counts = int(512*2)
# batch_counts = 32
batch_size = 32
batch_accumulation = 1
training_batches_update_epochs = 4

train_start_year = 2003
train_start_month = 1
train_start_day = 1
train_end_year = 2020
train_end_month = 12
train_end_day = 29

test_start_year = 2021
test_start_month = 1
test_start_day = 1
test_end_year = 2021
test_end_month = 4
test_end_day = 8

neighbors = 3
interval = 3

### Running settings ###
net_moving_average = 1
input_additional_period = 450
trade_additional_period = 5
close_steps = decode_predict_len + trade_additional_period
backtesting_plot = False
backtesting_trade_plot = True
backtesting_plot_pause = 0.001
activate_watchdog_cci_threshold = 100
watchdog_active_period = 6 # neighbors*interval
trade_trigger_ratio = 2
trade_trigger_magnitude = 0.0026
trailing_stop_distance = 0.00075
risk_reward_ratio = 0.75
take_profit_magnitude = 0.0008
stop_lost_magnitude = 0.0005
rsi_trade_close_rsi = 35
trade_close_price_distance = 0.0003
trade_close_least_steps = 8
trials = 1
# mode = 'cci'

import coin_wizard.plotter as plotter

ti = TechnicalIndicators()

class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        if not os.path.exists(os.path.join(agent_directory, 'figs')):
            os.makedirs(os.path.join(agent_directory, 'figs'))
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 0

        self.nsp = None
        self.net = None
        self.position = 0

        self.current_trade = None
        self.current_trade_total_steps = 0
        self.current_trade_best_profit = 0
        self.current_trade_worst_loss = 0
        self.current_trade_steps = 0
        self.current_trade_close_steps = 0

        self.total_long_counts = 0
        self.total_short_counts = 0

        self.total_long_pl = 0
        self.total_short_pl = 0

        self.succeeded_trials = 0

        self.watchdog_remaining_active_period = 0

    def _order_canceled_listener(self, order, reason):
        self.position = 0

    def _order_filled_listener(self, order, trade):
        # Record stats
        if trade.getTradeSettings()['units'] > 0:
            self.total_long_counts += 1
        else:
            self.total_short_counts += 1

        self.current_trade = trade
        trade.onReduced(self._trade_reduced_listener)
        trade.onClosed(self._trade_closed_listener)

    def _trade_reduced_listener(self, trade, units, realized_pl, close_price, spread, timestamp):
        pass

    def _trade_closed_listener(self, trade, realized_pl, close_price, spread, timestamp):
        # Record stats
        if trade.getTradeSettings()['units'] > 0:
            self.total_long_pl += realized_pl
        else:
            self.total_short_pl += realized_pl

        self.position = 0

        self.nsp.pushImmediately('Trade closed', 'Trade closed after %d total steps. PL: %.5f. Best profit: %.5f. Worst loss: %.5f.' % (
            self.current_trade_steps, realized_pl, self.current_trade_best_profit, self.current_trade_worst_loss))

    def _neural_net_predict(self, mid):
        # Prepare EurUsd data
        eurusd_hist_data = self.eurusd_inst.getRecentCandles(input_period+input_additional_period, granularity='M15')
        # eurusd_hist_data['ema'] = ti.ema(eurusd_hist_data.close, moving_average)
        eurusd_hist_data['macd'] = ti.macd(eurusd_hist_data.close, 12, 26)
        eurusd_hist_data['roc'] = ti.roc(eurusd_hist_data.close, roc_period)
        eurusd_hist_data['rsi'] = ti.rsi_ema(eurusd_hist_data.close, rsi_period)
        eurusd_hist_data['cci'] = ti.cci(eurusd_hist_data.high, eurusd_hist_data.low, eurusd_hist_data.close, cci_period)
        del eurusd_hist_data['open']
        del eurusd_hist_data['high']
        del eurusd_hist_data['low']

        # # Prepare GbpUsd data
        # gbpusd_hist_data = self.gbpusd_inst.getRecentCandles(input_period+input_additional_period, granularity='M15')
        # gbpusd_hist_data['macd_gbpusd'] = ti.macd(gbpusd_hist_data.close, 12, 26)
        # gbpusd_hist_data['roc_gbpusd'] = ti.roc(gbpusd_hist_data.close, roc_period)
        # gbpusd_hist_data['rsi_gbpusd'] = ti.rsi_ema(gbpusd_hist_data.close, rsi_period)
        # gbpusd_hist_data['cci_gbpusd'] = ti.cci(gbpusd_hist_data.high, gbpusd_hist_data.low, gbpusd_hist_data.close, cci_period)
        # del gbpusd_hist_data['close']
        # del gbpusd_hist_data['open']
        # del gbpusd_hist_data['high']
        # del gbpusd_hist_data['low']
        #
        # # Prepare EurJpy data
        # eurjpy_hist_data = self.eurjpy_inst.getRecentCandles(input_period+input_additional_period, granularity='M15')
        # eurjpy_hist_data['macd_eurjpy'] = ti.macd(eurjpy_hist_data.close, 12, 26)
        # eurjpy_hist_data['roc_eurjpy'] = ti.roc(eurjpy_hist_data.close, roc_period)
        # eurjpy_hist_data['rsi_eurjpy'] = ti.rsi_ema(eurjpy_hist_data.close, rsi_period)
        # eurjpy_hist_data['cci_eurjpy'] = ti.cci(eurjpy_hist_data.high, eurjpy_hist_data.low, eurjpy_hist_data.close, cci_period)
        # del eurjpy_hist_data['close']
        # del eurjpy_hist_data['open']
        # del eurjpy_hist_data['high']
        # del eurjpy_hist_data['low']

        # Since period is set 30
        self.first_valid_idex = 30

        # Merge data
        hist_data = eurusd_hist_data
        # hist_data = eurusd_hist_data.merge(gbpusd_hist_data, how='inner', on='timestamp')
        # hist_data = hist_data.merge(eurjpy_hist_data, how='inner', on='timestamp')
        hist_data.replace([np.inf, -np.inf], np.nan, inplace=True)
        hist_data = hist_data.dropna().reset_index(drop=True)

        # Make input tensor
        input = np.array([
            hist_data.close.to_list(),
            hist_data.macd.to_list(),
            hist_data.roc.to_list(),
            hist_data.rsi.to_list(),
            hist_data.cci.to_list(),
            # hist_data.macd_gbpusd.to_list(),
            # hist_data.roc_gbpusd.to_list(),
            # hist_data.rsi_gbpusd.to_list(),
            # hist_data.cci_gbpusd.to_list(),
            # hist_data.macd_eurjpy.to_list(),
            # hist_data.roc_eurjpy.to_list(),
            # hist_data.rsi_eurjpy.to_list(),
            # hist_data.cci_eurjpy.to_list(),
        ], dtype=np.float32)
        input = np.swapaxes(input, 0, 1)
        input = self.data_scaler.transform(input)
        times = time_features(hist_data['timestamp'], freq='t')

        # Moving average implementation
        encode_inputs_list = []
        encode_times_list = []
        decode_inputs_list = []
        decode_times_list = []

        for i in range(net_moving_average):
            encode_inputs = (input[-(input_period+(i)):, :])[:input_period, :]
            encode_times = (times[-(input_period+(i)):, :])[:input_period, :]
            decode_inputs = np.zeros((decode_inference_len+decode_predict_len, 13), dtype=float)
            decode_inputs[:decode_inference_len, :] = input[-decode_inference_len:, :]
            decode_times = time_features(pd.date_range(start=eurusd_hist_data['timestamp'].tail(1).iloc[0]+timedelta(minutes=1), periods=decode_predict_len, freq='T'), freq='t')
            # print(encode_times[-1, :])
            # print(decode_times[0, :])
            # raise
            # print(times[-decode_inference_len:, :])
            # print(decode_times)
            decode_times = np.concatenate((times[-decode_inference_len:, :], decode_times))

            encode_inputs_list.append(encode_inputs)
            encode_times_list.append(encode_times)
            decode_inputs_list.append(decode_inputs)
            decode_times_list.append(decode_times)

        encode_inputs = torch.tensor(encode_inputs_list, dtype=torch.float32)
        encode_times = torch.tensor(encode_times_list, dtype=torch.float32)
        decode_inputs = torch.tensor(decode_inputs_list, dtype=torch.float32)
        decode_times = torch.tensor(decode_times_list, dtype=torch.float32)

        if cuda_enabled:
            encode_inputs = encode_inputs.cuda()
            encode_times = encode_times.cuda()
            decode_inputs = decode_inputs.cuda()
            decode_times = decode_times.cuda()

        outputs = self.net(encode_inputs, encode_times, decode_inputs, decode_times)

        del encode_inputs
        del encode_times
        del decode_inputs
        del decode_times

        # print(hist_data.ema.to_list()[-1], mid, (hist_data.ema.to_list()[-1]-mid))
        outputs = outputs.sum(0, keepdim=True)/net_moving_average
        prediction = self.data_scaler.inverse_diff_transform_index(0, outputs) # + (hist_data.ema.to_list()[-1]-mid)
        prediction[:, :, 0] = prediction[:, :, 0].clip(min=torch.finfo(torch.float32).eps)
        prediction[:, :, 1] = prediction[:, :, 1].clip(max=-torch.finfo(torch.float32).eps)
        prediction_max = torch.max(prediction[0, :, 0]).item()
        prediction_min = torch.min(prediction[0, :, 1]).item()

        # Plot for backtesting.
        if backtesting_plot == True:
            x = list(range(0, decode_predict_len))
            labels = self.eurusd_inst.foreseeFutureCandles(decode_predict_len, granularity='M15')
            labels = torch.tensor(labels['close'].tolist())
            labels = labels - eurusd_hist_data['close'].tail(1).iloc[0]
            plt.plot(x, labels.tolist(), label='Label')
            plt.plot(x, prediction[0, :, 0].tolist(), label='Predict-CumMax')
            plt.plot(x, prediction[0, :, 1].tolist(), label='Predict-CumMin')
            plt.legend()
            plt.ylim(-0.0075, 0.0075)
            # plt.show(block=False)
            plt.show()
            # plt.pause(backtesting_plot_pause)
            # plt.close()

        return prediction_max, prediction_min

    def _every_15_second_loop(self, BrokerAPI):

        # Is not tradable
        if not self.eurusd_inst.isTradable():
            return

        # Every one minute = 4*15 seconds
        # print(self.every_15_second_loop_count)
        if self.every_15_second_loop_count % 4 == 0:
            self.every_15_second_loop_count = 0
            # print(self.every_15_second_loop_count)

            # Normalize
            bid, ask, timestamp = self.eurusd_inst.getCurrentCloseoutBidAsk()
            mid = 0.5*(bid+ask)

            # Trading algorithm
            units = 1000/0.02

            recent_candles = self.eurusd_inst.getRecentCandles(rsi_period+cci_period+input_additional_period, granularity='M15')
            rsi_list = ti.rsi_ema(recent_candles.close, rsi_period).tail(2)
            rsi_now = rsi_list.iloc[1]
            rsi_previous = rsi_list.iloc[0]

            cci_list = ti.cci(recent_candles.high, recent_candles.low, recent_candles.close, cci_period).tail(2)
            cci_now = cci_list.iloc[1]
            cci_previous = cci_list.iloc[0]

            if verbose:
                print(cci_list)
                print('cci_now: %1.6f, cci_previous: %1.6f'%(cci_now, cci_previous))

            if self.position == 0:
                if ((-activate_watchdog_cci_threshold >= cci_previous and cci_now > cci_previous) or (cci_previous >= activate_watchdog_cci_threshold and cci_now < cci_previous)):
                    self.watchdog_remaining_active_period = watchdog_active_period

                if self.watchdog_remaining_active_period > 0:
                    self.watchdog_remaining_active_period -= 1
                    prediction_max, prediction_min = self._neural_net_predict(mid)

                    if (-prediction_max/prediction_min >= 1):
                        magnitude = prediction_max
                        ratio = -prediction_max/prediction_min
                        triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                        print(timestamp, '[long] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))
                        if(triggered):
                            self.succeeded_trials += 1
                            if self.succeeded_trials >= trials:
                                self.succeeded_trials = 0
                                self.position = 1
                                self.current_trade_best_profit = 0
                                self.current_trade_worst_loss = 0
                                self.current_trade_steps = 0
                                self.current_trade_close_steps = close_steps
                                self.watchdog_remaining_active_period = 0
                                order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                                        "units": units,
                                                        # "take_profit": round(bid + take_profit_magnitude, 8),
                                                        "stop_lost":  round(bid - stop_lost_magnitude, 8),
                                                        "trailing_stop_distance": round(trailing_stop_distance, 8)})
                                order.onCanceled(self._order_canceled_listener)
                                order.onFilled(self._order_filled_listener)

                                # Plot for backtesting.
                                if backtesting_trade_plot == True:
                                    x = list(range(0, decode_predict_len))
                                    eurusd_hist_data = self.eurusd_inst.getRecentCandles(input_period+input_additional_period, granularity='M15')
                                    labels = self.eurusd_inst.foreseeFutureCandles(decode_predict_len, granularity='M15')
                                    labels = torch.tensor(labels['close'].tolist())
                                    labels = labels - eurusd_hist_data['close'].tail(1).iloc[0]
                                    plt.plot(x, labels.tolist(), label='Label')
                                    plt.legend()
                                    plt.ylim(-0.0075, 0.0075)
                                    plt.show()
                        else:
                            self.succeeded_trials = 0
                    else:
                        magnitude = -prediction_min
                        ratio = -prediction_min/prediction_max
                        triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                        print(timestamp, '[short] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))
                        if(triggered):
                            self.succeeded_trials += 1
                            if self.succeeded_trials >= trials:
                                self.succeeded_trials = 0
                                self.position = 2
                                self.current_trade_best_profit = 0
                                self.current_trade_worst_loss = 0
                                self.current_trade_steps = 0
                                self.current_trade_close_steps = close_steps
                                self.watchdog_remaining_active_period = 0

                                order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                                        "units": -units,
                                                        # "take_profit": round(ask - take_profit_magnitude, 8),
                                                        "stop_lost": round(ask + stop_lost_magnitude, 8),
                                                        "trailing_stop_distance": round(trailing_stop_distance, 8)})
                                order.onCanceled(self._order_canceled_listener)
                                order.onFilled(self._order_filled_listener)

                                # Plot for backtesting.
                                if backtesting_trade_plot == True:
                                    x = list(range(0, decode_predict_len))
                                    eurusd_hist_data = self.eurusd_inst.getRecentCandles(input_period+input_additional_period, granularity='M15')
                                    labels = self.eurusd_inst.foreseeFutureCandles(decode_predict_len, granularity='M15')
                                    labels = torch.tensor(labels['close'].tolist())
                                    labels = labels - eurusd_hist_data['close'].tail(1).iloc[0]
                                    plt.plot(x, labels.tolist(), label='Label')
                                    plt.legend()
                                    plt.ylim(-0.0075, 0.0075)
                                    plt.show()
                        else:
                            self.succeeded_trials = 0
                else:
                    self.succeeded_trials = 0

            elif self.position == 1:
                self.current_trade_steps += 1

                if self.current_trade_best_profit < self.current_trade.getUnrealizedPL():
                    self.current_trade_best_profit = self.current_trade.getUnrealizedPL()

                if self.current_trade_worst_loss > self.current_trade.getUnrealizedPL():
                    self.current_trade_worst_loss = self.current_trade.getUnrealizedPL()

                if self.current_trade_steps >= self.current_trade_close_steps or (bid-self.current_trade.getOpenPrice()>trade_close_price_distance and rsi_now >= 100 - rsi_trade_close_rsi and self.current_trade_steps >= trade_close_least_steps):
                    print('Request trade close.')
                    self.current_trade.close()

            elif self.position == 2:
                self.current_trade_steps += 1

                if self.current_trade_best_profit < self.current_trade.getUnrealizedPL():
                    self.current_trade_best_profit = self.current_trade.getUnrealizedPL()

                if self.current_trade_worst_loss > self.current_trade.getUnrealizedPL():
                    self.current_trade_worst_loss = self.current_trade.getUnrealizedPL()

                if self.current_trade_steps >= self.current_trade_close_steps or (self.current_trade.getOpenPrice()-ask>trade_close_price_distance and rsi_now <= rsi_trade_close_rsi and self.current_trade_steps >= trade_close_least_steps):
                    print('Request trade close.')
                    self.current_trade.close()

        self.every_15_second_loop_count += 1

    def run(self, BrokerAPI):
        self.test_mode = True
        self.data_scaler = dataloader.StandardScaler()

        net = nets.TyNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            print(net.cuda())

        self.net = net

        self.eurusd_inst = BrokerAPI.getInstrument('EUR_USD')
        self.eurjpy_inst = BrokerAPI.getInstrument('EUR_JPY')
        self.gbpusd_inst = BrokerAPI.getInstrument('GBP_USD')
        self.account = BrokerAPI.getAccount()

        self.nsp = BrokerAPI.getNotificationServiceProvider()
        BrokerAPI.onEvery15Second(self._every_15_second_loop)

    def stop_running(self, BrokerAPI):
        self.nsp.pushImmediately('Running stop', 'Long Pl: %.5f, Counts: %d, Avg: %.5f.\nShort Pl: %.5f, Counts: %d, Avg: %.5f.' % (
            self.total_long_pl, self.total_long_counts, self.total_long_pl/max(self.total_long_counts, 1), self.total_short_pl, self.total_short_counts, self.total_short_pl/max(self.total_short_counts, 1)))

    def train(self, BrokerAPI):
        global learning_rate
        net = nets.TyNet()

        if load_selected_net:
            net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
            print('Net "'+selected_net+'" loaded.')

        net.train()

        if cuda_enabled:
            torch.cuda.empty_cache()
            print(net.cuda())

        dl = dataloader.EurUsdDataLoader(
            utc.localize(datetime(train_start_year, train_start_month, train_start_day, 0, 0)),
            utc.localize(datetime(train_end_year, train_end_month, train_end_day, 23, 59)),
            moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)
        test_dl = dataloader.EurUsdDataLoader(
            utc.localize(datetime(test_start_year, test_start_month, test_start_day, 0, 0)),
            utc.localize(datetime(test_end_year, test_end_month, test_end_day, 23, 59)),
            moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)

        criterion = torch.nn.MSELoss()
        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        training_batches = dl.generateBatches(batch_counts, batch_size, input_period=input_period, inference_len=decode_inference_len, out_length=decode_predict_len, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
        test_batches = test_dl.generateBatches(1, batch_size, input_period=input_period, inference_len=decode_inference_len, out_length=decode_predict_len, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
        t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]

        loss_list = []
        test_loss_list = []
        for epoch in range(epoch_counts):
            if (epoch - 1) % training_batches_update_epochs == training_batches_update_epochs-1 and epoch != 0:
                del training_batches

                if cuda_enabled:
                    net.cpu()
                    torch.cuda.empty_cache()

                torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/backup.net"))

                if cuda_enabled:
                    net.cuda()

                training_batches = dl.generateBatches(batch_counts, batch_size, input_period=input_period, inference_len=decode_inference_len, out_length=decode_predict_len, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
                learning_rate = learning_rate*learning_rate_decay
                for param_group in optimizer.param_groups:
                    param_group['lr'] = learning_rate
                print('Training batches updated.')

            running_loss = 0.0
            optimizer.zero_grad()
            steps = 0
            for encode_inputs, encode_times, decode_inputs, decode_times, labels in training_batches:

                outputs = net(encode_inputs, encode_times, decode_inputs, decode_times)

                loss = criterion(outputs, labels)
                running_loss += loss.item()
                loss = loss/batch_accumulation
                loss.backward()

                if (steps+1) == batch_counts or (steps+1)%batch_accumulation == 0:
                    optimizer.step()
                    optimizer.zero_grad()

                steps += 1

            x = list(range(0, decode_predict_len))
            # plt.plot(x, dl.convertToCloseDiffRaw(labels[0, :, 0]).tolist(), label='Label-Linear')
            plt.plot(x, dl.convertToCloseDiffRaw(labels[0, :, 0]).tolist(), label='Label-CumMax')
            plt.plot(x, dl.convertToCloseDiffRaw(labels[0, :, 1]).tolist(), label='Label-CumMin')
            # plt.plot(x, dl.convertToCloseDiffRaw(outputs[0, :, 0]).tolist(), label='Predict-Linear')
            plt.plot(x, dl.convertToCloseDiffRaw(outputs[0, :, 0]).tolist(), label='Predict-CumMax')
            plt.plot(x, dl.convertToCloseDiffRaw(outputs[0, :, 1]).tolist(), label='Predict-CumMin')
            plt.legend()
            plt.savefig(self.agent_directory +'/figs/'+ datetime.now().strftime("/KT_%Y_%m_%d_%H_%M.png"))
            plt.clf()

            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)
            test_loss = criterion(test_outputs, t_labels)

            print("Epoch: %d, loss: %1.8f, test loss: %1.8f" % (epoch, math.sqrt(running_loss/batch_counts), math.sqrt(test_loss.item())))

            loss_list.append(math.sqrt(running_loss/batch_counts))
            test_loss_list.append(math.sqrt(test_loss.item()))
            x = list(range(0, epoch+1))
            plt.plot(x, loss_list, label='Loss')
            plt.plot(x, test_loss_list, label='Test-Loss')
            plt.legend()
            plt.savefig(self.agent_directory + '/loss.png')
            plt.clf()

        if cuda_enabled:
            net.cpu()
        print(self.agent_directory + datetime.now().strftime("/KT_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/KT_%Y_%m_%d_%H_%M.net"))

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        cuda_enabled = False
        self.test_mode = True
        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 1, 1, 0, 0)), utc.localize(datetime(2021, 5, 29, 23, 59)), moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)
        # test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2021, 2, 1, 0, 0)), utc.localize(datetime(2021, 5, 29, 23, 59)), moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)
        # test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2019, 1, 1, 0, 0)), utc.localize(datetime(2019, 4, 8, 23, 59)), moving_average=moving_average, roc_period=roc_period, rsi_period=rsi_period, cci_period=cci_period)

        net = nets.TyNet()
        net.load_state_dict(torch.load(self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            net.cuda()

        while(True):
            test_batches = test_dl.generateBatches(1, batch_size, input_period=input_period, inference_len=decode_inference_len, out_length=decode_predict_len, neighbors=neighbors, interval=interval, cuda=cuda_enabled)
            t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times, t_labels = test_batches[0]
            test_outputs = net(t_encode_inputs, t_encode_times, t_decode_inputs, t_decode_times)
            test_outputs = test_dl.convertToCloseDiffRaw(test_outputs)
            test_outputs[:, :, 0] = test_outputs[:, :, 0].clip(min=torch.finfo(torch.float32).eps)
            test_outputs[:, :, 1] = test_outputs[:, :, 1].clip(max=-torch.finfo(torch.float32).eps)

            for i in range(batch_size):
                prediction_max = torch.max(test_outputs[i, :, 0]).item()
                prediction_min = torch.min(test_outputs[i, :, 1]).item()

                # print('[long] magnitude: %1.6f, ratio: %1.3f [short] magnitude: %1.6f, ratio: %1.3f'%(t_max, -t_max/t_min, -t_min, -t_min/t_max))
                if -prediction_max/prediction_min >= 1:
                    magnitude = prediction_max
                    ratio = -prediction_max/prediction_min
                    triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                    print('[long] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))
                else:
                    magnitude = -prediction_min
                    ratio = -prediction_min/prediction_max
                    triggered = ratio >= trade_trigger_ratio and magnitude >= trade_trigger_magnitude
                    print('[short] magnitude: %1.6f, ratio: %1.3f, triggered: %r'%(magnitude, ratio, triggered))

                if triggered or True:
                    # if (t_max > tp and t_min > -sl) or (t_min < -tp and t_max < sl):
                    x = list(range(0, decode_predict_len))
                    # plt.plot(x, test_dl.convertToCloseDiffRaw(t_labels[i, :, 0]).tolist(), label='Label-Linear')
                    plt.plot(x, test_dl.convertToCloseDiffRaw(t_labels[i, :, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, test_dl.convertToCloseDiffRaw(t_labels[i, :, 1]).tolist(), label='Label-CumMin')
                    # plt.plot(x, test_dl.convertToCloseDiffRaw(test_outputs[i, :, 0]).tolist(), label='Predict-Linear')
                    plt.plot(x, test_outputs[i, :, 0].tolist(), label='Predict-CumMax')
                    plt.plot(x, test_outputs[i, :, 1].tolist(), label='Predict-CumMin')
                    plt.legend()
                    plt.ylim(-0.0075, 0.0075)
                    plt.show()

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
