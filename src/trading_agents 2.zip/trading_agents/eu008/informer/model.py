import torch
import torch.nn as nn
import torch.nn.functional as F

from .encoder import Encoder, EncoderLayer, ConvLayer, EncoderStack
from .decoder import Decoder, DecoderLayer
from .attn import FullAttention, ProbAttention, AttentionLayer
from .embed import DataEmbedding, GranularityEmbedding

class GranularityInformer(nn.Module):
    def __init__(self, enc_in_list, dec_in, c_out, out_len,
                factor=5, d_model=512, n_heads=8, e_layers=3, d_layers=2, d_ff=512,
                dropout=0.0, attn='prob', embed='fixed', freq='h', activation='gelu',
                output_attention = False, distil=True, single_encoder=False,
                device=torch.device('cuda:0')):
        super(GranularityInformer, self).__init__()
        self.pred_len = out_len
        self.attn = attn
        self.output_attention = output_attention
        self.granularity_level = len(enc_in_list)
        self.single_encoder = single_encoder
        # Encoding
        if single_encoder:
            self.enc_embedding = DataEmbedding(enc_in_list[0], d_model, embed, freq, dropout)
        else:
            self.enc_embedding_list = nn.ModuleList([DataEmbedding(enc_in, d_model, embed, freq, dropout) for enc_in in enc_in_list])

        self.dec_embedding = DataEmbedding(dec_in, d_model, embed, freq, dropout)
        # Attention
        Attn = ProbAttention if attn=='prob' else FullAttention
        # Encoder
        if single_encoder:
            self.encoder = Encoder(
               [
                   EncoderLayer(
                       AttentionLayer(Attn(False, factor, attention_dropout=dropout, output_attention=output_attention),
                                   d_model, n_heads),
                       d_model,
                       d_ff,
                       dropout=dropout,
                       activation=activation
                   ) for l in range(e_layers)
               ],
               [
                   ConvLayer(
                       d_model
                   ) for l in range(e_layers-1)
               ] if distil else None,
               norm_layer=torch.nn.LayerNorm(d_model)
           )
        else:
            self.encoder_list = nn.ModuleList([
                 Encoder(
                    [
                        EncoderLayer(
                            AttentionLayer(Attn(False, factor, attention_dropout=dropout, output_attention=output_attention),
                                        d_model, n_heads),
                            d_model,
                            d_ff,
                            dropout=dropout,
                            activation=activation
                        ) for l in range(e_layers)
                    ],
                    [
                        ConvLayer(
                            d_model
                        ) for l in range(e_layers-1)
                    ] if distil else None,
                    norm_layer=torch.nn.LayerNorm(d_model)
                ) for i in range(self.granularity_level)
            ])
        # GranularityEmbedding
        self.gran_embedding = GranularityEmbedding(d_model, self.granularity_level)
        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AttentionLayer(Attn(True, factor, attention_dropout=dropout, output_attention=False),
                                d_model, n_heads),
                    AttentionLayer(FullAttention(False, factor, attention_dropout=dropout, output_attention=False),
                                d_model, n_heads),
                    d_model,
                    d_ff,
                    dropout=dropout,
                    activation=activation,
                )
                for l in range(d_layers)
            ],
            norm_layer=torch.nn.LayerNorm(d_model)
        )
        # self.end_conv1 = nn.Conv1d(in_channels=label_len+out_len, out_channels=out_len, kernel_size=1, bias=True)
        # self.end_conv2 = nn.Conv1d(in_channels=d_model, out_channels=c_out, kernel_size=1, bias=True)
        self.projection = nn.Linear(d_model, c_out, bias=True)

    def forward(self, x_enc_list, x_mark_enc_list, x_dec, x_mark_dec,
                enc_self_mask=None, dec_self_mask=None, dec_enc_mask=None):
        device = x_enc_list[0].get_device()

        if self.single_encoder:
            enc_out_list = [self.enc_embedding(x_enc_list[i], x_mark_enc_list[i]) for i in range(self.granularity_level)]
            enc_out_list = [self.encoder(enc_out_list[i], attn_mask=enc_self_mask)[0] for i in range(self.granularity_level)]
        else:
            enc_out_list = [self.enc_embedding_list[i](x_enc_list[i], x_mark_enc_list[i]) for i in range(self.granularity_level)]
            enc_out_list = [self.encoder_list[i](enc_out_list[i], attn_mask=enc_self_mask)[0] for i in range(self.granularity_level)]

        # print(enc_out_list[0].shape)
        if device >= 0:
            enc_out_x_mark_list = [torch.ones(enc_out_list[i].shape[0],
                                             enc_out_list[i].shape[1],
                                             1).to(device)*i for i in range(self.granularity_level)]
        else:
            enc_out_x_mark_list = [torch.ones(enc_out_list[i].shape[0],
                                             enc_out_list[i].shape[1],
                                             1)*i for i in range(self.granularity_level)]
        enc_out = torch.cat(enc_out_list, 1)
        enc_out_x_mark = torch.cat(enc_out_x_mark_list, 1)

        enc_out = self.gran_embedding(enc_out, enc_out_x_mark)

        dec_out = self.dec_embedding(x_dec, x_mark_dec)
        dec_out = self.decoder(dec_out, enc_out, x_mask=dec_self_mask, cross_mask=dec_enc_mask)
        dec_out = self.projection(dec_out)

        # dec_out = self.end_conv1(dec_out)
        # dec_out = self.end_conv2(dec_out.transpose(2,1)).transpose(1,2)
        if self.output_attention:
            return dec_out[:,-self.pred_len:,:], attns
        else:
            return dec_out[:,-self.pred_len:,:] # [B, L, D]
