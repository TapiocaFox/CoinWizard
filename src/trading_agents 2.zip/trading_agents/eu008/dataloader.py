#!/usr/bin/python3

import torch, random, math

import coin_wizard.historical_pair_data as hist
import numpy as np
from coin_wizard.technical_indicators import TechnicalIndicators
from datetime import datetime, timedelta
from .timefeatures import time_features
import matplotlib.pyplot as plt

import coin_wizard.plotter as plotter

time_delta_1_days = timedelta(days=7)

ti = TechnicalIndicators()

granularity_time_delta = {
    "M1": timedelta(seconds=60),
    "M5": timedelta(seconds=60*5),
    "M15": timedelta(seconds=60*15),
    "M30": timedelta(seconds=60*30),
    "H1": timedelta(seconds=60*60),
    "H4": timedelta(seconds=60*240),
    "D": timedelta(seconds=60*60*24),
}

class StandardScaler():
    def __init__(self, mean=None, std=None):
        self.mean = mean
        self.std = std

    def fit(self, data):
        self.mean = data.mean(0)
        self.std = data.std(0)
        print('mean:')
        print(self.mean.tolist())
        print('std:')
        print(self.std.tolist())
        print('shape:')
        print(self.std.shape)

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean) / std

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std) + mean

    def transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean[i]) / std[i]

    def diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return data / std[i]

    def inverse_transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i]) + mean[i]

    def inverse_diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i])

class EurUsdDataLoader(object):
    def __init__(self, granularities=None, from_datetime=None, to_datetime=None, moving_average=9, roc_period=9, rsi_period=14, cci_period=20, only_data_scaler=False):
        # self.data_scaler_granularities = [None for g in granularities]
        self.data_scaler_granularities = [
            StandardScaler(np.array([1.2418469190597534, 0, 0, 0, 50, 0])
            , np.array([0.1321103423833847, 0.0002312215801794082, 0.00017482321709394455, 0.0004674667143262923, 15.807493209838867, 87.22274017333984])),
            StandardScaler(np.array([1.2419986724853516, 0, 0, 0, 50, 0])
            , np.array([0.1340758055448532, 0.0005008766311220825, 0.0003799915430136025, 0.0009911214001476765, 15.22752857208252, 87.41263580322266])),
            StandardScaler(np.array([1.2416694164276123, 0, 0, 0, 50, 0])
            , np.array([0.13439881801605225, 0.0008674715063534677, 0.0006583433714695275, 0.0017129803309217095, 15.515338897705078, 88.94762420654297])),
            StandardScaler(np.array([1.2416210174560547, 0, 0, 0, 50, 0])
            , np.array([0.13436149060726166, 0.001732577569782734, 0.0013110550353303552, 0.0034229604061692953, 16.782548904418945, 91.32881164550781])),
            StandardScaler(np.array([1.241703987121582, 0, 0, 0, 50, 0])
            , np.array([0.1342923790216446, 0.0033929143100976944, 0.002575057093054056, 0.0067379106767475605, 17.66691017150879, 89.56181335449219])),
            StandardScaler(np.array([1.2415261268615723, 0, 0, 0, 50, 0])
            , np.array([0.13428528606891632, 0.007825671695172787, 0.005986070726066828, 0.015159323811531067, 16.969181060791016, 87.380859375])),
        ]

        if not only_data_scaler:
            self.granularities = granularities

            self.hist_data_granularities = [None for g in granularities]
            self.time_granularities = [None for g in granularities]
            self.time_df_granularities = [None for g in granularities]

            for index, granularity in enumerate(granularities):
                eurusd_hist_data = hist.get_historical_pair_data_pandas('eurusd', from_datetime, to_datetime, granularity=granularity)

                eurusd_hist_data['macd_12_26'] = ti.macd(eurusd_hist_data.close, 12, 26)
                eurusd_hist_data['macd_26_40'] = ti.macd(eurusd_hist_data.close, 26, 40)
                eurusd_hist_data['roc'] = ti.roc(eurusd_hist_data.close, roc_period)
                eurusd_hist_data['rsi'] = ti.rsi_ema(eurusd_hist_data.close, rsi_period)
                eurusd_hist_data['cci'] = ti.cci(eurusd_hist_data.high, eurusd_hist_data.low, eurusd_hist_data.close, cci_period)
                del eurusd_hist_data['open']
                del eurusd_hist_data['high']
                del eurusd_hist_data['low']

                hist_data = eurusd_hist_data

                hist_data.replace([np.inf, -np.inf], np.nan, inplace=True)
                hist_data = hist_data.dropna()
                hist_data = hist_data.sort_values(by=['timestamp']).reset_index(drop=True)

                hist_data_np = np.array([
                    hist_data.close.to_list(),
                    hist_data.macd_12_26.to_list(),
                    hist_data.macd_26_40.to_list(),
                    hist_data.roc.to_list(),
                    hist_data.rsi.to_list(),
                    hist_data.cci.to_list(),
                ], dtype=np.float32)

                hist_data_np = np.swapaxes(hist_data_np, 0, 1)

                data_scaler = self.data_scaler_granularities[index]
                # data_scaler = StandardScaler()
                # print(hist_data_np)
                # data_scaler.fit(hist_data_np)

                hist_data_np = data_scaler.transform(hist_data_np)

                time_np = time_features(hist_data['timestamp'], freq='t')

                self.hist_data_granularities[index] = hist_data_np
                self.time_granularities[index] = time_np
                self.time_df_granularities[index] = hist_data.timestamp
                # self.data_scaler_granularities[index] = data_scaler
                # print(hist_data)
            #     print(hist_data_np)
                # print(hist_data_np.shape)
            #     print(time_np)
                # print(time_np.shape)
                # print(time_np.shape)
                # print(hist_data.timestamp)
            # raise

    def convertToCloseRaw(self, granularity, data):
        return self.data_scaler_granularities[granularity].inverse_transform_index(0, data)

    def convertToCloseDiffRaw(self, granularity, data):
        return self.data_scaler_granularities[granularity].inverse_diff_transform_index(0, data)
    # 0.0032
    def generateBatches(self, batch_counts, batch_size, input_period_list, cci_trigger_granularity, inference_granularity, inference_length, prediction_granularity, prediction_length, prediction_resolution, neighbors=3, interval=30, shape_exp=np.exp(1)/2, decay_exp=1.001, degree=17, clip_value=0.0018, cci_threshold=100, weak_record_threshold=0.00055, weak_record_dropout=0, cuda=True, debug_plot=False): # 1.61803398875 1.05
        # Variables
        cci_index = 5
        granularities = self.granularities
        batch_list = []

        # Data
        hist_data_granularities = self.hist_data_granularities
        time_granularities = self.time_granularities
        time_df_granularities = self.time_df_granularities
        data_scaler_granularities = self.data_scaler_granularities

        # Constants
        decay_array = np.power(decay_exp, -np.arange(prediction_length))
        x_axis = np.arange(prediction_length)
        clip_value = data_scaler_granularities[prediction_granularity].diff_transform_index(0, clip_value)

        # Prediction and referance
        prediction_hist_data = hist_data_granularities[prediction_granularity]
        prediction_time_np = time_granularities[prediction_granularity]
        prediction_time_df = time_df_granularities[prediction_granularity]
        prediction_data_scaler = data_scaler_granularities[prediction_granularity]
        prediction_input_period = input_period_list[prediction_granularity]

        cci_trigger_hist_data = hist_data_granularities[cci_trigger_granularity]
        cci_trigger_time_np = time_granularities[cci_trigger_granularity]
        cci_trigger_time_df = time_df_granularities[cci_trigger_granularity]
        cci_trigger_data_scaler = data_scaler_granularities[cci_trigger_granularity]
        cci_trigger_input_period = input_period_list[cci_trigger_granularity]

        inference_hist_data = hist_data_granularities[inference_granularity]
        inference_time_np = time_granularities[inference_granularity]
        inference_time_df = time_df_granularities[inference_granularity]
        inference_data_scaler = data_scaler_granularities[inference_granularity]
        inference_input_period = input_period_list[inference_granularity]

        first_valid_timestamp_granularities = [time_df_granularities[granularity].iloc[input_period] for granularity, input_period in enumerate(input_period_list)]
        first_valid_timestamp = max(first_valid_timestamp_granularities)
        first_valid_index = cci_trigger_time_df[cci_trigger_time_df>=first_valid_timestamp].index[0]
        latest_valid_timestamp = min([time_df_granularities[index].iloc[-1] for index, g in enumerate(granularities)])
        latest_valid_timestamp = min([latest_valid_timestamp, time_df_granularities[prediction_granularity].iloc[-prediction_length-1]])
        latest_valid_index = cci_trigger_time_df[cci_trigger_time_df>=latest_valid_timestamp].index[0]

        # print(first_valid_index)
        # print(latest_valid_index)
        # print(inference_time_df[inference_time_df<=first_valid_timestamp])
        # print(inference_time_df[inference_time_df>=latest_valid_timestamp])

        for i in range(batch_counts):
            encode_inputs_list = [[] for g in granularities]
            encode_times_list = [[] for g in granularities]
            decode_inputs = []
            decode_times = []
            labels = []

            j = 0

            while j < batch_size:
                if j%neighbors == 0:
                    random_index = None
                    cci = 0
                    previous_cci = 0
                    while random_index is None or ((-cci_threshold < previous_cci or cci <= previous_cci) and (previous_cci < cci_threshold or cci >= previous_cci)):
                        random_index = random.randint(first_valid_index, latest_valid_index-(neighbors-1)*interval)
                        cci = cci_trigger_data_scaler.inverse_transform_index(cci_index, cci_trigger_hist_data[random_index, cci_index])
                        previous_cci = cci_trigger_data_scaler.inverse_transform_index(cci_index, cci_trigger_hist_data[random_index-1, cci_index])
                        # print(cci)
                        # raise
                    # print('sel', cci, previous_cci)
                else:
                    random_index += random.randint(1, interval)

                random_index_timestamp = cci_trigger_time_df[random_index]+granularity_time_delta[granularities[cci_trigger_granularity]]

                decode_inference = None
                decode_inference_time = None

                # print('\nTS', random_index_timestamp)

                for index, granularity in enumerate(granularities):
                    hist_data = hist_data_granularities[index]
                    time = time_granularities[index]
                    time_df = time_df_granularities[index]
                    input_period = input_period_list[index]

                    # granularity_random_index = time_df[time_df<=random_index_timestamp].index[-1]
                    granularity_random_index = time_df.searchsorted(random_index_timestamp-granularity_time_delta[granularity], side='right')
                    # if time_df.iloc[granularity_random_index] > random_index_timestamp-granularity_time_delta[granularities[granularity]]:
                    granularity_random_index -= 1

                    # print(time_df.iloc[granularity_random_index+1-input_period:granularity_random_index+1])
                    # print(time_features(time_df.iloc[granularity_random_index+1-input_period:granularity_random_index+1], freq='t'))
                    # print(time[granularity_random_index+1-input_period:granularity_random_index+1])
                    # print(time_df[time_df<=random_index_timestamp])
                    # print(random_index_timestamp)
                    # print(granularity_random_index)
                    # print(time_df.iloc[granularity_random_index])



                    encode_input = hist_data[granularity_random_index+1-input_period:granularity_random_index+1, :]
                    encode_time = time[granularity_random_index+1-input_period:granularity_random_index+1, :]
                    encode_inputs_list[index].append(encode_input)
                    encode_times_list[index].append(encode_time)

                    if index == inference_granularity:
                        decode_inference = encode_input[-inference_length:, :]
                        decode_inference_time = encode_time[-inference_length:, :]
                    # print(encode_input)
                # raise

                # prediction_random_index = prediction_time_df[prediction_time_df>random_index_timestamp].index[0]
                prediction_random_index = prediction_time_df.searchsorted(random_index_timestamp, side='left')

                # if prediction_time_df.iloc[prediction_random_index] == random_index_timestamp:
                #     prediction_random_index += 1

                # print(prediction_time_df.iloc[prediction_random_index:prediction_random_index+prediction_length])
                # print(time_features(prediction_time_df.iloc[prediction_random_index:prediction_random_index+prediction_length], freq='t'))
                # print(prediction_time_np[prediction_random_index:prediction_random_index+prediction_length])

                prediction_resolution_steps = int(prediction_length/prediction_resolution)

                decode_input = np.zeros((prediction_resolution, decode_inference.shape[-1]))
                decode_input = np.concatenate([decode_inference, decode_input], axis=0)
                decode_time = np.concatenate([decode_inference_time, prediction_time_np[prediction_random_index:prediction_random_index+prediction_length:prediction_resolution_steps, :]], axis=0)

                label = prediction_hist_data[prediction_random_index:prediction_random_index+prediction_length, 0] - prediction_hist_data[prediction_random_index, 0]
                label = label.clip(min=-clip_value, max=clip_value)
                if debug_plot:
                    plot_l = label
                poly = np.poly1d(np.polyfit(x_axis, label, degree))

                label = poly(x_axis)

                max_acc = np.maximum.accumulate(label).clip(min=0)
                min_acc = np.minimum.accumulate(label).clip(max=0)

                if shape_exp <= 1:
                    label = np.array([
                        decay_array*max_acc,
                        decay_array*min_acc
                    ]).transpose()
                else:
                    # print(np.power(shape_exp, label/np.maximum.accumulate(label)-1))*np.maximum.accumulate(label)))
                    # raise

                    label = np.array([
                        decay_array*np.power(shape_exp, label/np.maximum(max_acc, np.finfo(np.float32).eps)-1).clip(max=1)*max_acc,
                        decay_array*np.power(shape_exp, label/np.minimum(min_acc, -np.finfo(np.float32).eps)-1).clip(max=1)*min_acc
                    ]).transpose()

                if j%neighbors == 0:
                    max_abs = prediction_data_scaler.inverse_diff_transform_index(0, np.amax(np.absolute(label)))
                    # print(max_abs)
                    if weak_record_dropout > 0 and max_abs < weak_record_threshold and random.uniform(0, 1) < weak_record_dropout:
                        # print('dropped')
                        continue

                if debug_plot:
                    x = np.arange(prediction_length)
                    plt.plot(x, self.convertToCloseDiffRaw(prediction_granularity, label[:, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, self.convertToCloseDiffRaw(prediction_granularity, label[:, 1]).tolist(), label='Label-CumMin')

                    plt.plot(x, self.convertToCloseDiffRaw(prediction_granularity, plot_l).tolist(), label='Label-EMA')
                    plt.legend()
                    plt.show()

                    x = np.arange(prediction_resolution)
                    plt.plot(x, self.convertToCloseDiffRaw(prediction_granularity, label[::prediction_resolution_steps, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, self.convertToCloseDiffRaw(prediction_granularity, label[::prediction_resolution_steps, 1]).tolist(), label='Label-CumMin')

                    plt.plot(x, self.convertToCloseDiffRaw(prediction_granularity, plot_l[::prediction_resolution_steps]).tolist(), label='Label-EMA')
                    plt.legend()
                    plt.show()

                # raise
                decode_inputs.append(decode_input)
                decode_times.append(decode_time)
                labels.append(label[::prediction_resolution_steps, :])
                j += 1

            encode_inputs_list = [torch.tensor(encode_inputs, dtype=torch.float32) for encode_inputs in encode_inputs_list]
            encode_times_list = [torch.tensor(encode_times, dtype=torch.float32) for encode_times in encode_times_list]
            decode_inputs = torch.tensor(decode_inputs, dtype=torch.float32)
            decode_times = torch.tensor(decode_times, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.float32)

            if cuda:
                encode_inputs_list = [encode_inputs.cuda() for encode_inputs in encode_inputs_list]
                encode_times_list = [encode_times.cuda() for encode_times in encode_times_list]
                decode_inputs = decode_inputs.cuda()
                decode_times = decode_times.cuda()
                labels = labels.cuda()

            batch_list.append([encode_inputs_list, encode_times_list, decode_inputs, decode_times, labels])
            # print(i)
        return batch_list
