#!/usr/bin/python3

import torch, math
import torch.nn as nn
from trading_agents.bn010.informer.model import GranularityInformer

class BnNet(nn.Module):
    def __init__(self):
        super(BnNet, self).__init__()
        self.decode_predict_len = 24
        self.informer = GranularityInformer([6, 6, 6], 6, 2, self.decode_predict_len, factor=5, e_layers=4, d_layers=2,
                                            dropout=0.1, data_dropout_k=0.5, data_dropout=0.2, structure_dropout=0.1, granularities_dropout=[True, True, True],
                                            d_model=512, d_ff=2048, embed='timeF', freq='t')

        # self.informer = GranularityInformer([6, 6, 6], 6, 2, self.decode_predict_len, factor=5, e_layers=4, d_layers=2,
        #                                     dropout=0.2, data_dropout_k=0.5, data_dropout=0.4, structure_dropout=0.2, granularities_dropout=[True, True, True],
        #                                     d_model=512, d_ff=2048, embed='timeF', freq='t')

    def forward(self, encode_input, encode_time, decode_input, decode_time):
        x = self.informer(encode_input, encode_time, decode_input, decode_time)
        return x
