#!/usr/bin/python3

import torch, random, math

import coin_wizard.historical_pair_data as hist
import numpy as np
from coin_wizard.technical_indicators import TechnicalIndicators
from datetime import datetime, timedelta
from .timefeatures import time_features
import matplotlib.pyplot as plt

import coin_wizard.plotter as plotter

time_delta_1_days = timedelta(days=7)

ti = TechnicalIndicators()

granularity_time_delta = {
    "M1": timedelta(seconds=60),
    "M5": timedelta(seconds=60*5),
    "M15": timedelta(seconds=60*15),
    "M30": timedelta(seconds=60*30),
    "H1": timedelta(seconds=60*60),
    "H4": timedelta(seconds=60*240),
    "D": timedelta(seconds=60*60*24),
}

class DataScaler():
    def __init__(self, mean=None, std=None, inverted=None):
        self.mean = mean
        self.std = std
        self.inverted = inverted
        # print(mean, std)

    def fit(self, data):
        self.mean = np.array(data.mean(0))
        # self.std = data.std(0)
        self.std = np.array(data.rolling(24*60).std(0).dropna().mean(0))

        print('mean, std:')
        print('np.array('+str(self.mean.tolist())+'), np.array('+str(self.std.tolist())+')')
        print('shape:')
        print(self.std.shape)

    def transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean) / std

    def inverse_transform(self, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std) + mean

    def diff_transform(self, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return data / std

    def inverse_diff_transform(self, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std)

    def transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data - mean[i]) / std[i]

    def diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return data / std[i]

    def inverse_transform_index(self, i, data):
        mean = torch.from_numpy(self.mean).type_as(data).to(data.device) if torch.is_tensor(data) else self.mean
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i]) + mean[i]

    def inverse_diff_transform_index(self, i, data):
        std = torch.from_numpy(self.std).type_as(data).to(data.device) if torch.is_tensor(data) else self.std
        return (data * std[i])

    def return_inverted_data_scaler(self):
        return DataScaler(self.inverted[0], self.inverted[1])

class DataLoader(object):
    def __init__(self, instrument_list, instrument_datascaler_list, macd_amplifier, granularities=None, from_datetime=None, to_datetime=None, momentum_period=9, rsi_period=14, cci_period=20):
        # self.data_scaler_granularities = [None for g in granularities]
        self.instrument_list = []
        instrument_list_ = []

        self.instrument_datascaler_list = []

        for index, instrument in enumerate(instrument_list):
            self.instrument_list.append(instrument)
            self.instrument_list.append(instrument+'_inverted')
            instrument_list_.append((instrument, False))
            instrument_list_.append((instrument, True))
            self.instrument_datascaler_list.append(instrument_datascaler_list[index])
            self.instrument_datascaler_list.append(instrument_datascaler_list[index].return_inverted_data_scaler())

        instrument_datascaler_list = self.instrument_datascaler_list

        self.granularities = granularities

        self.hist_data_granularities = [[None for g in granularities] for i in range(2*len(instrument_list))]
        self.time_granularities = [[None for g in granularities] for i in range(2*len(instrument_list))]
        self.time_df_granularities = [[None for g in granularities] for i in range(2*len(instrument_list))]

        for instrument_index, instrument_n_invert in enumerate(instrument_list_):
            instrument = instrument_n_invert[0]
            invert = instrument_n_invert[1]
            for granularity_index, granularity in enumerate(granularities):
                hist_data = hist.get_historical_pair_data_pandas(instrument, from_datetime, to_datetime, granularity=granularity, invert=invert)
                # print(hist_data)
                hist_data.open = instrument_datascaler_list[instrument_index].transform(hist_data.open)
                hist_data.low = instrument_datascaler_list[instrument_index].transform(hist_data.low)
                hist_data.high = instrument_datascaler_list[instrument_index].transform(hist_data.high)
                hist_data.close = instrument_datascaler_list[instrument_index].transform(hist_data.close)

                # print(macd_amplifier[granularity_index])
                hist_data['macd_12_26'] = ti.macd(hist_data.close, 12, 26)*macd_amplifier[granularity_index]
                hist_data['macd_26_40'] = ti.macd(hist_data.close, 26, 40)*macd_amplifier[granularity_index]
                hist_data['momentum'] = ti.momentum(hist_data.close, momentum_period)
                hist_data['rsi'] = ti.rsi_ema(hist_data.close, rsi_period)/50 - 1.0
                hist_data['cci'] = ti.cci(hist_data.high, hist_data.low, hist_data.close, cci_period)/200
                del hist_data['open']
                del hist_data['high']
                del hist_data['low']

                hist_data = hist_data

                hist_data.replace([np.inf, -np.inf], np.nan, inplace=True)
                hist_data = hist_data.dropna()
                hist_data = hist_data.sort_values(by=['timestamp']).reset_index(drop=True)

                hist_data_np = np.array([
                    hist_data.close.to_list(),
                    hist_data.macd_12_26.to_list(),
                    hist_data.macd_26_40.to_list(),
                    hist_data.momentum.to_list(),
                    hist_data.rsi.to_list(),
                    hist_data.cci.to_list(),
                ], dtype=np.float32)

                hist_data_np = np.swapaxes(hist_data_np, 0, 1)

                time_np = time_features(hist_data['timestamp'], freq='t')

                self.hist_data_granularities[instrument_index][granularity_index] = hist_data_np
                self.time_granularities[instrument_index][granularity_index] = time_np
                self.time_df_granularities[instrument_index][granularity_index] = hist_data.timestamp

        # print(self.instrument_list)

    def generateBatches(self, batch_counts, batch_size, input_period_list, cci_trigger_granularity, inference_granularity, inference_length, prediction_granularity, prediction_length, prediction_resolution, neighbors=3, interval=30, shape_exp=np.exp(1)/2, decay_exp=1.001, degree=5, clip_value=0.0026, clip_value_instrument_index=0, cci_threshold=100, weak_record_threshold=0.00055, weak_record_dropout=0, cuda=True, debug_plot=False): # 1.61803398875 1.05
        # Variables
        cci_index = 5
        granularities = self.granularities
        batch_list = []

        clip_value_instrument_index= 2*clip_value_instrument_index

        # Data
        instrument_list = self.instrument_list
        instrument_datascaler_list = self.instrument_datascaler_list
        hist_data_granularities_instrument = self.hist_data_granularities
        time_granularities_instrument = self.time_granularities
        time_df_granularities_instrument = self.time_df_granularities

        # Constants
        decay_array = np.power(decay_exp, -np.arange(prediction_length))
        x_axis = np.arange(prediction_length)
        clip_value = instrument_datascaler_list[clip_value_instrument_index].diff_transform(clip_value)

        # Prediction and referance
        prediction_hist_data_instrument = [hist_data_granularities_instrument[i][prediction_granularity] for i, _ in enumerate(instrument_list)]
        prediction_time_np_instrument = [time_granularities_instrument[i][prediction_granularity] for i, _ in enumerate(instrument_list)]
        prediction_time_df_instrument = [time_df_granularities_instrument[i][prediction_granularity] for i, _ in enumerate(instrument_list)]
        prediction_input_period = input_period_list[prediction_granularity]

        cci_trigger_hist_data_instrument = [hist_data_granularities_instrument[i][cci_trigger_granularity] for i, _ in enumerate(instrument_list)]
        cci_trigger_time_np_instrument = [time_granularities_instrument[i][cci_trigger_granularity] for i, _ in enumerate(instrument_list)]
        cci_trigger_time_df_instrument = [time_df_granularities_instrument[i][cci_trigger_granularity] for i, _ in enumerate(instrument_list)]
        cci_trigger_input_period = input_period_list[cci_trigger_granularity]

        inference_hist_data_instrument = [hist_data_granularities_instrument[i][inference_granularity] for i, _ in enumerate(instrument_list)]
        inference_time_np_instrument = [time_granularities_instrument[i][inference_granularity] for i, _ in enumerate(instrument_list)]
        inference_time_df_instrument = [time_df_granularities_instrument[i][inference_granularity] for i, _ in enumerate(instrument_list)]
        inference_input_period = input_period_list[inference_granularity]

        first_valid_timestamp_granularities_instrument = [[time_df_granularities_instrument[i][granularity].iloc[input_period] for granularity, input_period in enumerate(input_period_list)] for i, _ in enumerate(instrument_list)]
        first_valid_timestamp_instrument = [max(first_valid_timestamp_granularities_instrument[i]) for i, _ in enumerate(instrument_list)]
        first_valid_index_instrument = [cci_trigger_time_df_instrument[i][cci_trigger_time_df_instrument[i]>=first_valid_timestamp_instrument[i]].index[0] for i, _ in enumerate(instrument_list)]
        latest_valid_timestamp_instrument = [min([time_df_granularities_instrument[i][index].iloc[-1] for index, g in enumerate(granularities)]) for i, _ in enumerate(instrument_list)]
        latest_valid_timestamp_instrument = [min([latest_valid_timestamp_instrument[i], time_df_granularities_instrument[i][prediction_granularity].iloc[-prediction_length-1]]) for i, _ in enumerate(instrument_list)]
        latest_valid_index_instrument = [cci_trigger_time_df_instrument[i][cci_trigger_time_df_instrument[i]>=latest_valid_timestamp_instrument[i]].index[0] for i, _ in enumerate(instrument_list)]

        # print(first_valid_timestamp_instrument)
        # print(latest_valid_timestamp_instrument)
        # print(first_valid_index_instrument)
        # print(latest_valid_index_instrument)
        # print(inference_time_df[inference_time_df<=first_valid_timestamp])
        # print(inference_time_df[inference_time_df>=latest_valid_timestamp])

        for i in range(batch_counts):
            encode_inputs_list = [[] for g in granularities]
            encode_times_list = [[] for g in granularities]
            decode_inputs = []
            decode_times = []
            labels = []

            j = 0

            while j < batch_size:
                if j%neighbors == 0:
                    random_instrument_index = random.randint(0, len(instrument_list)-1)

                    hist_data_granularities = hist_data_granularities_instrument[random_instrument_index]
                    time_granularities = time_granularities_instrument[random_instrument_index]
                    time_df_granularities = time_df_granularities_instrument[random_instrument_index]

                    # clip_value = clip_value_instrument[random_instrument_index]

                    prediction_hist_data = prediction_hist_data_instrument[random_instrument_index]
                    prediction_time_np = prediction_time_np_instrument[random_instrument_index]
                    prediction_time_df = prediction_time_df_instrument[random_instrument_index]
                    prediction_input_period = prediction_input_period

                    cci_trigger_hist_data = cci_trigger_hist_data_instrument[random_instrument_index]
                    cci_trigger_time_np = cci_trigger_time_np_instrument[random_instrument_index]
                    cci_trigger_time_df = cci_trigger_time_df_instrument[random_instrument_index]
                    cci_trigger_input_period = cci_trigger_input_period

                    inference_hist_data = inference_hist_data_instrument[random_instrument_index]
                    inference_time_np = inference_time_np_instrument[random_instrument_index]
                    inference_time_df = inference_time_df_instrument[random_instrument_index]
                    inference_input_period = inference_input_period

                    first_valid_timestamp_granularities = first_valid_timestamp_granularities_instrument[random_instrument_index]
                    first_valid_timestamp = first_valid_timestamp_instrument[random_instrument_index]
                    first_valid_index = first_valid_index_instrument[random_instrument_index]
                    latest_valid_timestamp = latest_valid_timestamp_instrument[random_instrument_index]
                    latest_valid_index = latest_valid_index_instrument[random_instrument_index]

                    data_scaler = instrument_datascaler_list[random_instrument_index]

                    random_index = None
                    cci = 0
                    previous_cci = 0
                    while random_index is None or ((-cci_threshold < previous_cci or cci <= previous_cci) and (previous_cci < cci_threshold or cci >= previous_cci)):
                        random_index = random.randint(first_valid_index, latest_valid_index-(neighbors-1)*interval)
                        cci = cci_trigger_hist_data[random_index, cci_index]*100
                        previous_cci = cci_trigger_hist_data[random_index-1, cci_index]*100
                        # print(cci)
                        # raise
                    # print('sel', cci, previous_cci)
                else:
                    random_index += random.randint(1, interval)

                random_index_timestamp = cci_trigger_time_df[random_index]+granularity_time_delta[granularities[cci_trigger_granularity]]

                decode_inference = None
                decode_inference_time = None

                # print('\nTS', random_index_timestamp)

                for index, granularity in enumerate(granularities):
                    hist_data = hist_data_granularities[index]
                    time = time_granularities[index]
                    time_df = time_df_granularities[index]
                    input_period = input_period_list[index]

                    # granularity_random_index = time_df[time_df<=random_index_timestamp].index[-1]
                    granularity_random_index = time_df.searchsorted(random_index_timestamp-granularity_time_delta[granularity], side='right')
                    # if time_df.iloc[granularity_random_index] > random_index_timestamp-granularity_time_delta[granularities[granularity]]:
                    granularity_random_index -= 1

                    # print(time_df.iloc[granularity_random_index+1-input_period:granularity_random_index+1])
                    # print(time_features(time_df.iloc[granularity_random_index+1-input_period:granularity_random_index+1], freq='t'))
                    # print(time[granularity_random_index+1-input_period:granularity_random_index+1])
                    # print(time_df[time_df<=random_index_timestamp])
                    # print(random_index_timestamp)
                    # print(granularity_random_index)
                    # print(time_df.iloc[granularity_random_index])



                    encode_input = hist_data[granularity_random_index+1-input_period:granularity_random_index+1, :].copy()
                    # print(encode_input[: , 0])
                    # print(encode_input[-1, 0])
                    encode_input[:, 0] = encode_input[:, 0] - encode_input[-1, 0]


                    # x = np.arange(input_period)
                    # plt.plot(x, (encode_input[:, 0]).tolist(), label='close')
                    # plt.plot(x, (encode_input[:, 1]).tolist(), label='macd1')
                    # plt.plot(x, (encode_input[:, 2]).tolist(), label='macd2')
                    # plt.plot(x, (encode_input[:, 3]).tolist(), label='momentum')
                    # plt.plot(x, (encode_input[:, 4]).tolist(), label='rsi')
                    # plt.plot(x, (encode_input[:, 5]).tolist(), label='cci')
                    # plt.title(str(random_instrument_index)+' '+str(instrument_list[random_instrument_index])+' '+str(granularity))
                    # plt.legend()
                    # plt.show()

                    encode_time = time[granularity_random_index+1-input_period:granularity_random_index+1, :]
                    encode_inputs_list[index].append(encode_input)
                    encode_times_list[index].append(encode_time)

                    if index == inference_granularity:
                        decode_inference = encode_input[-inference_length:, :]
                        # print(decode_inference[:, 0])
                        decode_inference_time = encode_time[-inference_length:, :]
                    # print(encode_input)
                # raise

                # prediction_random_index = prediction_time_df[prediction_time_df>random_index_timestamp].index[0]
                prediction_random_index = prediction_time_df.searchsorted(random_index_timestamp, side='left')

                # if prediction_time_df.iloc[prediction_random_index] == random_index_timestamp:
                #     prediction_random_index += 1

                # print(prediction_time_df.iloc[prediction_random_index:prediction_random_index+prediction_length])
                # print(time_features(prediction_time_df.iloc[prediction_random_index:prediction_random_index+prediction_length], freq='t'))
                # print(prediction_time_np[prediction_random_index:prediction_random_index+prediction_length])

                prediction_resolution_steps = int(prediction_length/prediction_resolution)

                decode_input = np.zeros((prediction_resolution, decode_inference.shape[-1]))
                decode_input = np.concatenate([decode_inference, decode_input], axis=0)
                decode_time = np.concatenate([decode_inference_time, prediction_time_np[prediction_random_index:prediction_random_index+prediction_length:prediction_resolution_steps, :]], axis=0)

                label = prediction_hist_data[prediction_random_index:prediction_random_index+prediction_length, 0] - (prediction_hist_data[prediction_random_index, 0]+prediction_hist_data[prediction_random_index-1, 0])/2.0
                label = label.clip(min=-clip_value, max=clip_value)
                if debug_plot:
                    plot_l = label
                poly = np.poly1d(np.polyfit(x_axis, label, degree))

                label = poly(x_axis)

                max_acc = np.maximum.accumulate(label).clip(min=0)
                min_acc = np.minimum.accumulate(label).clip(max=0)

                if shape_exp <= 1:
                    label = np.array([
                        decay_array*max_acc,
                        decay_array*min_acc
                    ]).transpose()
                else:
                    # print(np.power(shape_exp, label/np.maximum.accumulate(label)-1))*np.maximum.accumulate(label)))
                    # raise

                    label = np.array([
                        decay_array*np.power(shape_exp, label/np.maximum(max_acc, np.finfo(np.float32).eps)-1).clip(max=1)*max_acc,
                        decay_array*np.power(shape_exp, label/np.minimum(min_acc, -np.finfo(np.float32).eps)-1).clip(max=1)*min_acc
                    ]).transpose()

                if j%neighbors == 0:
                    max_abs = data_scaler.inverse_diff_transform(np.amax(np.absolute(label)))
                    # print(max_abs)
                    if weak_record_dropout > 0 and max_abs < weak_record_threshold and random.uniform(0, 1) < weak_record_dropout:
                        # print('dropped')
                        continue

                if debug_plot:
                    print(random_instrument_index)
                    data_scaler = instrument_datascaler_list[clip_value_instrument_index]
                    x = np.arange(prediction_length)
                    plt.plot(x, data_scaler.inverse_diff_transform(label[:, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, data_scaler.inverse_diff_transform(label[:, 1]).tolist(), label='Label-CumMin')

                    plt.plot(x, data_scaler.inverse_diff_transform(plot_l).tolist(), label='Label-EMA')
                    plt.legend()
                    plt.show()

                    x = np.arange(prediction_resolution)
                    plt.plot(x, data_scaler.inverse_diff_transform(label[::prediction_resolution_steps, 0]).tolist(), label='Label-CumMax')
                    plt.plot(x, data_scaler.inverse_diff_transform(label[::prediction_resolution_steps, 1]).tolist(), label='Label-CumMin')

                    plt.plot(x, data_scaler.inverse_diff_transform(plot_l[::prediction_resolution_steps]).tolist(), label='Label-EMA')
                    plt.legend()
                    plt.show()

                # raise
                decode_inputs.append(decode_input)
                decode_times.append(decode_time)
                labels.append(label[::prediction_resolution_steps, :])
                j += 1

            encode_inputs_list = [torch.tensor(encode_inputs, dtype=torch.float32) for encode_inputs in encode_inputs_list]
            encode_times_list = [torch.tensor(encode_times, dtype=torch.float32) for encode_times in encode_times_list]
            decode_inputs = torch.tensor(decode_inputs, dtype=torch.float32)
            decode_times = torch.tensor(decode_times, dtype=torch.float32)
            labels = torch.tensor(labels, dtype=torch.float32)

            if cuda:
                encode_inputs_list = [encode_inputs.cuda() for encode_inputs in encode_inputs_list]
                encode_times_list = [encode_times.cuda() for encode_times in encode_times_list]
                decode_inputs = decode_inputs.cuda()
                decode_times = decode_times.cuda()
                labels = labels.cuda()

            batch_list.append([encode_inputs_list, encode_times_list, decode_inputs, decode_times, labels])
            # print(i)
        return batch_list
