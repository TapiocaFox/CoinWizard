import torch
import torch.nn as nn

import numpy as np

from math import ceil

class DataDropout(nn.Module):
    def __init__(self, dropout_keep=0.5, dropout=0.2):
        super(DataDropout, self).__init__()
        self.dropout_keep = dropout_keep
        self.dropout = dropout

    def forward(self, x, x_mark):
        if self.training:
            device = x.get_device()

            dropout_keep = self.dropout_keep
            dropout = self.dropout

            B, L, D = x.shape

            if device >= 0:
                mask = (torch.rand(B, L, device=device) <= (1-dropout)).double()
                preserve_mask = torch.rand(B, L, device=device)

            else:
                mask = (torch.rand(B, L) <= (1-dropout)).double()
                preserve_mask = torch.rand(B, L)

            # mask = torch.bernoulli(mask)

            preserve_mask_top_k = torch.topk(preserve_mask, ceil(L*dropout_keep))[0]
            preserve_mask = preserve_mask >= preserve_mask_top_k[:, -1:]

            mask[preserve_mask] = 1

            mask = mask.unsqueeze(2)

            return mask*x, mask*x_mark, mask
            # return x
        else:
            B, L, D = x.shape

            device = x.get_device()
            if device >= 0:
                mask = torch.ones(B, L, device=device)

            else:
                mask = torch.ones(B, L)

            mask = mask.unsqueeze(2)

            return x, x_mark, mask

class MultiHeadDropout(nn.Module):
    def __init__(self, dropout=0.1):
        super(MultiHeadDropout, self).__init__()
        self.dropout = dropout

    def forward(self, x):
        if self.training:
            device = x.get_device()

            dropout = self.dropout

            B, L, H, D = x.shape

            if device >= 0:
                mask = (torch.rand(B, L, H, device=device) <= (1-dropout)).double()
            else:
                mask = (torch.rand(B, L, H) <= (1-dropout)).double()

            # mask = torch.bernoulli(mask)
            active_counts = torch.sum(mask, dim=2, keepdim=True)
            # print(active_counts)
            mask = (H/active_counts)*mask
            # print(mask)
            mask = mask.expand(B, L, H).unsqueeze(3).expand(B, L, H, D)
            # print(mask)
            # print(active_counts)

            return x*mask
        else:
            return x

# a = torch.arange(3*5*2)
# b = torch.arange(3*5*1)
# a = a.view(3, 5, 2)
# b = b.view(3, 5, 1)
# d = DataDropout()
# print(d(a, b))
#
# c = torch.arange(3*5*8*2)
# c = c.view(3, 5, 8, 2)
# d2 = MultiHeadDropout()
# print(d2(c))
