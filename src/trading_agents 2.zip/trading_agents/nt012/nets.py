import torch
from torch import nn

from einops import rearrange, repeat
from einops.layers.torch import Rearrange

from math import ceil
# helpers

def pair(t):
    return t if isinstance(t, tuple) else (t, t)

# classes
class PatchDropout(nn.Module):
    def __init__(self, dropout=0.2, dropout_k=0.5):
        super().__init__()
        self.dropout = dropout
        self.dropout_keep = dropout_k

    def forward(self, x):
        dropout = self.dropout
        dropout_keep = self.dropout_keep
        device = x.get_device()
        device = device if device>=0 else 'cpu'

        if self.training and True:
            B, PN, _ = x.shape

            # Patches dropout
            mask = torch.ones(B, PN, device=device)*(1-dropout)
            preserve_mask = torch.rand(B, PN, device=device)

            mask = torch.bernoulli(mask)

            preserve_mask_top_k = torch.topk(preserve_mask, ceil(PN*dropout_keep))[0]
            preserve_mask = preserve_mask >= preserve_mask_top_k[:, -1:]

            mask[preserve_mask] = 1

            mask = mask.unsqueeze(2)

            return mask*x
        else:
            return x

class FeatureDropout(nn.Module):
    def __init__(self, dropout=0.2, dropout_k=0.5):
        super().__init__()
        self.dropout = dropout
        self.dropout_keep = dropout_k

    def forward(self, x):
        dropout = self.dropout
        dropout_keep = self.dropout_keep
        device = x.get_device()
        device = device if device>=0 else 'cpu'

        if self.training and True:
            B, _, D = x.shape
            # Feature dropout
            f_mask = torch.ones(B, D, device=device)*(1-dropout)
            f_preserve_mask = torch.rand(B, D, device=device)

            f_mask = torch.bernoulli(f_mask)

            f_preserve_mask_top_k = torch.topk(f_preserve_mask, ceil(D*dropout_keep))[0]
            f_preserve_mask = f_preserve_mask >= f_preserve_mask_top_k[:, -1:]

            f_mask[f_preserve_mask] = 1

            f_mask = f_mask.unsqueeze(1)

            return f_mask*x
        else:
            return x

class GranularityDropout(nn.Module):
    def __init__(self, dropout=0.1, granularities = []):
        super().__init__()
        self.dropout = dropout
        self.granularities = granularities

    def forward(self, x):
        dropout = self.dropout
        granularities = self.granularities
        device = x[0].get_device()
        device = device if device>=0 else 'cpu'

        if self.training and True:
            B, _ = x[0].shape

            preserve_mask = torch.rand(B, len(granularities), device=device)

            preserve_mask_top_k = torch.topk(preserve_mask, 1)[0]
            preserve_mask = preserve_mask >= preserve_mask_top_k[:, -1:]

            preserve_counts = torch.zeros(B, device=device).unsqueeze(1)
            for index, do_dropout in enumerate(granularities):
                if do_dropout:
                    mask = torch.ones(B, device=device)*(1-dropout)

                    mask = torch.bernoulli(mask)

                    mask = (torch.logical_or(mask, preserve_mask[:, index])).float()
                    mask = mask.unsqueeze(1)

                    x[index] = mask*x[index]
                    preserve_counts+=mask
            return x, preserve_counts

        else:
            granularities = self.granularities
            B, _ = x[0].shape
            preserve_counts = (torch.ones(B, device=device)*len(granularities)).unsqueeze(1)
            return x, preserve_counts

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn
    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)

class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )
    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.heads = heads
        self.scale = dim_head ** -0.5

        self.attend = nn.Softmax(dim = -1)
        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale

        attn = self.attend(dots)

        out = torch.matmul(attn, v)
        out = rearrange(out, 'b h n d -> b n (h d)')
        return self.to_out(out)

class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, mlp_dim, dropout = 0.):
        super().__init__()
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                PreNorm(dim, Attention(dim, heads = heads, dim_head = dim_head, dropout = dropout)),
                PreNorm(dim, FeedForward(dim, mlp_dim, dropout = dropout))
            ]))
    def forward(self, x):
        for attn, ff in self.layers:
            x = attn(x) + x
            x = ff(x) + x
        return x

class ViT1D(nn.Module):
    def __init__(self, *, sequence_length, patch_length, in_dim, dim, depth, heads, mlp_dim, pool = 'cls', dim_head = 64, dropout = 0., emb_dropout = 0., patch_dropout=0.2, patch_dropout_k=0.5):
        super().__init__()

        assert sequence_length % patch_length == 0, 'Image dimensions must be divisible by the patch size.'

        num_patches = (sequence_length // patch_length)
        patch_dim = in_dim * patch_length
        assert pool in {'cls', 'mean'}, 'pool type must be either cls (cls token) or mean (mean pooling)'

        self.to_patch_embedding = nn.Sequential(
            Rearrange('b (p_num p_len) in_dim -> b p_num (p_len in_dim)', p_len = patch_length),
            PatchDropout(patch_dropout, patch_dropout_k),
            nn.Linear(patch_dim, dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout)

        self.pool = pool
        self.to_latent = nn.Identity()


    def forward(self, x):
        x = self.to_patch_embedding(x)
        b, n, _ = x.shape

        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b = b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        x = self.transformer(x)

        x = x.mean(dim = 1) if self.pool == 'mean' else x[:, 0]

        x = self.to_latent(x)

        return x

class DecoderTransformer(nn.Module):
    def __init__(self, *, sequence_length, in_dim, dim, depth, heads, mlp_dim, pool = 'cls', dim_head = 64, dropout = 0., emb_dropout = 0.):
        super().__init__()

        assert pool in {'cls', 'mean'}, 'pool type must be either cls (cls token) or mean (mean pooling)'

        self.input_embedding = nn.Sequential(
            nn.Linear(in_dim, dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, sequence_length + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout)

        self.pool = pool
        self.to_latent = nn.Identity()


    def forward(self, x):
        x = self.input_embedding(x)
        b, n, _ = x.shape

        cls_tokens = repeat(self.cls_token, '() n d -> b n d', b = b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        x = self.transformer(x)

        x = x.mean(dim = 1) if self.pool == 'mean' else x[:, 0]

        x = self.to_latent(x)

        return x

class NtNet(nn.Module):
    def __init__(self, sequence_length_list=[288, 288, 288], in_dim_list=[6, 6, 6], granularities_dropout_list=[True, True, True], vit_depth=4, decoder_transformer_depth=2, patch_length=12, heads=8, d_model=512, mlp_dim=2048, dropout=0.1, preserve_dropout=0.2, preserve_dropout_k=0.5, num_classes=2):
        super().__init__()

        self.d_model = d_model
        self.num_classes = num_classes

        dim_head = (d_model // heads)

        self.feature_dropout = FeatureDropout(preserve_dropout, preserve_dropout_k)

        self.vit_list = nn.ModuleList([
            nn.Sequential(
                ViT1D(
                    sequence_length=sequence_length,
                    patch_length=patch_length,
                    in_dim=in_dim,
                    dim=d_model,
                    depth=vit_depth,
                    heads=heads,
                    mlp_dim=mlp_dim,
                    dropout=dropout,
                    emb_dropout=dropout,
                    patch_dropout=preserve_dropout,
                    patch_dropout_k=preserve_dropout_k
                ),
                nn.LayerNorm(d_model)
            )
            for sequence_length, in_dim in zip(sequence_length_list, in_dim_list)
        ])

        self.decoder = DecoderTransformer(
                        sequence_length=len(sequence_length_list),
                        in_dim=d_model,
                        dim=d_model,
                        depth=decoder_transformer_depth,
                        heads=heads,
                        mlp_dim=mlp_dim,
                        dropout=dropout,
                        emb_dropout=dropout
                    )

        # self.gran_dropout = GranularityDropout(dropout, granularities_dropout_list)

        self.mlp_head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, num_classes)
        )

        self.sigmoid = torch.sigmoid

    def forward(self, x_list):
        granularity = len(self.vit_list)
        vit_out_list = [self.vit_list[i](self.feature_dropout(x_list[i])) for i in range(granularity)]
        # vit_out_list = [self.vit_list[i](x_list[i]) for i in range(granularity)]
        # vit_out_list = [vit_out for vit_out in vit_out_list]
        # vit_out_list, vit_out_pre_count = self.gran_dropout(vit_out_list)
        # vit_out_sum = torch.stack(vit_out_list, dim=0).sum(dim=0)
        # vit_out_mean = vit_out_sum/vit_out_pre_count # Mean pooling
        # vit_out_mean = vit_out_sum/granularity # Mean pooling
        x = torch.stack(vit_out_list, dim=1)
        x = self.decoder(x)
        x = self.mlp_head(x)
        x = self.sigmoid(x)
        return x

    def fine_tune(self):
        d_model = self.d_model
        num_classes = self.num_classes

        for param in self.parameters():
            param.requires_grad = False

        self.mlp_head = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, num_classes)
        )
