#!/usr/bin/python3

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math
import coin_wizard.historical_pair_data as hist
from trading_agents.hb001.train_utils import generate_training_batches_and_labels


import pytz
utc = pytz.utc
from datetime import datetime

class HbNet(nn.Module):
    def __init__(self):
        super(HbNet, self).__init__()
        # 4984
        self.conv1 = nn.Conv1d(4, 16, 8, stride=4)
        self.pool = nn.MaxPool1d(15)
        self.sigmoid = nn.Sigmoid()
        self.tanh = nn.Tanh()
        self.lrelu = nn.LeakyReLU()
        self.conv2 = nn.Conv1d(16, 16, 10, stride=1)
        self.fc1 = nn.Linear(16*74, 592)
        self.fc2 = nn.Linear(592, 360)
        # self.fc3 = nn.Linear(296, 60)
        # self.fc1 = nn.Linear(16 * 1, 120)

    def forward(self, x):
        # print(self.conv1(x).shape)
        x = self.pool(self.tanh(self.conv1(x)))
        # print(x.shape)
        x = self.tanh(self.conv2(x))
        # print(x.shape)
        x = x.view(-1, 16*74)
        x = self.tanh(self.fc1(x))
        x = self.lrelu(self.fc2(x))
        # x = self.lrelu(self.fc3(x))
        return x

class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)

    def run(self, BrokerAPI):
        pass

    def stop_running(self, BrokerAPI):
        pass

    def train(self, BrokerAPI):
        data = hist.get_historical_pair_data('eurusd', utc.localize(datetime(2019, 1, 8, 0, 0)), utc.localize(datetime(2021, 1, 8, 23, 59)))
        # print(data)
        data = data.view((np.double, 5))
        data = np.delete(data, 0, 1)
        data = np.swapaxes(data, 0, 1)
        # data = data.astype(np.double)
        print(data.shape)

        # data = data[np.newaxis, :, :, ]
        offset = 90

        training_batches = generate_training_batches('eurusd', utc.localize(datetime(2019, 1, 8, 0, 0)), utc.localize(datetime(2021, 1, 8, 23, 59)), cuda = True)

        net = HbNet()
        print(net.cuda())
        criterion = nn.MSELoss()
        # optimizer = optim.SGD(net.parameters(), lr=0.01, momentum=0.9)
        optimizer = optim.Adam(net.parameters(), lr=0.000005)

        for epoch in range(120*14):  # loop over the dataset multiple times
            running_loss = 0.0
            for i, training_batche in enumerate(training_batches):
                # get the inputs; data is a list of [inputs, labels]
                inputs = []
                for j in range(500):
                    input = data[:, 10*i+100*j:4984+10*i+100*j]
                    # input = input[np.newaxis, :, :, ]
                    inputs.append(input)
                inputs = np.array(inputs)
                inputs = torch.from_numpy(inputs)
                inputs = torch.tensor(inputs, dtype=torch.float32)
                inputs = inputs.cuda()

                labels = []
                for j in range(500):
                    # label = data[:, 4984+10*i+100*j:4984+10*i+100*j+30].flatten()
                    label = data[:, 4984+10*i+100*j:4984+10*i+100*j+offset].flatten()
                    # input = input[np.newaxis, :, :, ]
                    labels.append(label)

                labels = np.array(labels)
                labels = torch.from_numpy(labels)
                labels = torch.tensor(labels, dtype=torch.float32)
                labels = labels.cuda()

                # print(inputs, labels, inputs.shape, labels.shape)
                # raise
                # zero the parameter gradients
                optimizer.zero_grad()

                # forward + backward + optimize
                outputs = net(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

                # print statistics
                running_loss += loss.item()
                if i % 10 == 9:    # print every 2000 mini-batches
                    print('[%d, %5d] loss: %.12f' %
                          (epoch + 1, i + 1, running_loss / 10))
                    print(math.sqrt(running_loss / 10))
                    running_loss = 0.0

        # net.device('cpu')
        x = data [:, 0:4984]
        print(x)
        print(x.shape)
        # print(x.flatten())
        # print(x)
        # print(x.shape)
        x = x[np.newaxis, :, :, ]

        x = torch.from_numpy(x)
        x = torch.tensor(x, dtype=torch.float32)
        net.cpu()
        outputs = net(x)
        print('outputs')

        print(outputs[:, 0:offset][0].detach().numpy())
        print(outputs[:, offset:offset*2][0].detach().numpy())
        print(outputs[:, offset*2:offset*3][0].detach().numpy())
        print(outputs[:, offset*3:offset*4][0].detach().numpy())

        c = pd.DataFrame({
            'open': outputs[:, 0:offset][0].detach().numpy(),
            'high': outputs[:, offset:offset*2][0].detach().numpy(),
            'low': outputs[:, offset*2:offset*3][0].detach().numpy(),
            'close': outputs[:, offset*3:offset*4][0].detach().numpy()
        })

        import plotly.graph_objects as go
        fig = go.Figure(data=[go.Candlestick(
                open=c['open'],
                high=c['high'],
                low=c['low'],
                close=c['close'])])

        fig.show()

        d = data[:, 4984:4984+offset]
        c = pd.DataFrame({
            'open': d[0],
            'high': d[1],
            'low': d[2],
            'close': d[3]
        })

        fig = go.Figure(data=[go.Candlestick(
                open=c['open'],
                high=c['high'],
                low=c['low'],
                close=c['close'])])

        fig.show()
        print(data[:, 4984:4984+offset])
        print(data[:, 4984:4984+offset].flatten())

        # print(outputs[:, 0:30])
        # print(outputs[:, 30:60])
        # print(outputs[:, 60:90])
        # print(outputs[:, 90:120])
        # print(data[:, 4984:4984+30])
        # print(data[:, 4984:4984+30].flatten())


    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        pass

    def stop_testing(self, BacktestBrokerAPI):
        pass
