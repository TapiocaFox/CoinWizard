#!/usr/bin/python3

import torch
import torch.nn as nn

class HbNet(nn.Module):
    def __init__(self):
        super(HbNet, self).__init__()
        # 4984
        self.sigmoid = nn.Sigmoid()
        self.softmax = nn.Softmax(dim=1)
        self.tanh = nn.Tanh()
        self.lrelu = nn.LeakyReLU()
        self.relu = nn.ReLU()
        self.conv1 = nn.Conv2d(4, 64, 3, stride=1)
        # self.pool = nn.MaxPool1d(2)
        self.conv2 = nn.Conv2d(64, 32, 3, stride=1)
        # self.conv3 = nn.Conv2d(48, 24, 3, stride=1)
        self.pool = nn.MaxPool2d(2)
        self.fc1 = nn.Linear(32*14*14, 360)
        self.fc2 = nn.Linear(360, 3)
        # self.fc3 = nn.Linear(output_counts*64, output_counts)
        # self.fc1 = nn.Linear(16 * 1, 120)

    def forward(self, x):
        # print(self.conv1(x).shape)
        x = self.lrelu(self.conv1(x))
        # print(x.shape)
        # raise

        x = self.pool(x)
        # print(x.shape)

        x = self.lrelu(self.conv2(x))
        # print(x.shape)
        # raise
        x = self.pool(x)

        # x = self.relu(self.conv3(x))
        # print(x.shape)
        # raise
        # x = self.pool(x)
        # print(x.shape)
        # raise
        x = x.view(-1, 32*14*14)
        x = self.fc1(x)
        # x = self.fc2(x)
        x = self.softmax(self.fc2(x))
        # x = self.softmax(self.fc2(x))
        # x = self.softmax(self.fc3(x))
        # x = self.
        # x = self.lrelu(self.fc4(x))
        return x

class JvnNet(nn.Module):
    def __init__(self):
        super(JvnNet, self).__init__()
        self.softmax = nn.Softmax(dim=1)
        self.tanh = nn.Tanh()
        self.lrelu = nn.LeakyReLU()
        self.relu = nn.ReLU()
        self.conv1 = nn.Conv1d(4, 72, 3, stride=1)
        # self.pool = nn.MaxPool1d(2)
        self.conv2 = nn.Conv1d(72, 72, 5, stride=1)
        # self.conv3 = nn.Conv2d(48, 24, 3, stride=1)
        self.pool = nn.MaxPool1d(2)
        # self.pool = nn.AvgPool1d(2)
        self.fc1 = nn.Linear(72*118, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, 3)

    def forward(self, x):
        # print(self.conv1(x).shape)
        x = self.lrelu(self.conv1(x))
        # print(x.shape)
        # raise

        x = self.pool(x)
        # print(x.shape)

        x = self.lrelu(self.conv2(x))
        # print(x.shape)
        # raise
        x = self.pool(x)

        # x = self.relu(self.conv3(x))
        # print(x.shape)
        # raise
        # x = self.pool(x)
        # print(x.shape)
        # raise
        x = x.view(-1, 72*118)
        x = self.lrelu(self.fc1(x))
        x = self.lrelu(self.fc2(x))
        x = self.softmax(self.fc3(x))
        return x
