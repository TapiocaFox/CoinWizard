
class RewardCalculator(object):
    def reward_idle(self, episode_index, current_episode_steps, action):
        return 0
        # return -self.idle_punishment_ratio

    def reward_invalid_action(self, episode_index, current_episode_steps, action):
        return -self.invalid_action_punishment_ratio

    def reward_trade_open(self, episode_index, current_episode_steps, action):
        episode_candles, start_index = self.episode_candles_start_index_list[episode_index]
        primary_candles = episode_candles[self.primary_granularity]
        self.open_price_list[episode_index] = primary_candles.loc[start_index+current_episode_steps-1].close
        # print('reg', primary_candles.loc[start_index+current_episode_steps-1])
        return -self.trade_open_cost

    def reward_trade_step(self, episode_index, current_episode_steps, action):
        episode_candles, start_index = self.episode_candles_start_index_list[episode_index]
        primary_candles = episode_candles[self.primary_granularity]
        diff = primary_candles.loc[start_index+current_episode_steps-1].close - primary_candles.loc[start_index+current_episode_steps-1-1].close
        diff = self.trade_step_reward_ratio*diff
        return diff/self.average_diff_sum_list[episode_index]

    def reward_trade_accumulated_steps(self, episode_index, current_episode_steps, action):
        # self.accumulated_trade_steps_list[episode_index] += 1
        # accu_steps = self.accumulated_trade_steps_list[episode_index]
        # if accu_steps >= self.trade_max_accumulated_steps:
        #     return -(self.trade_max_accumulated_steps_punishment_increase*(accu_steps-self.trade_max_accumulated_steps) + self.trade_max_accumulated_steps_punishment_ratio)
        return 0

    def reward_trade_close(self, episode_index, current_episode_steps, action):
        episode_candles, start_index = self.episode_candles_start_index_list[episode_index]
        primary_candles = episode_candles[self.primary_granularity]
        reward = primary_candles.loc[start_index+current_episode_steps-1].close - self.open_price_list[episode_index]
        self.open_price_list[episode_index] = None
        self.accumulated_trade_steps_list[episode_index] = 0
        return reward/self.average_diff_sum_list[episode_index]

    def reward_long_open(self, episode_index, current_episode_steps, action):
        reward = self.reward_trade_open(episode_index, current_episode_steps, action)
        self.long_counts_list[episode_index] += 1
        self.total_profit_loss_list[episode_index] += reward
        self.total_long_profit_loss_list[episode_index] += reward
        return reward

    def reward_long_step(self, episode_index, current_episode_steps, action):
        self.long_steps_list[episode_index] += 1
        reward = self.reward_trade_step(episode_index, current_episode_steps, action)
        reward += self.reward_trade_accumulated_steps(episode_index, current_episode_steps, action)
        return reward

    def reward_long_close(self, episode_index, current_episode_steps, action):
        reward = self.reward_trade_close(episode_index, current_episode_steps, action) # - self.trade_open_cost
        self.total_profit_loss_list[episode_index] += reward
        self.total_long_profit_loss_list[episode_index] += reward
        return 0
        # return reward

    def reward_short_open(self, episode_index, current_episode_steps, action):
        reward = self.reward_trade_open(episode_index, current_episode_steps, action)
        self.short_counts_list[episode_index] += 1
        self.total_profit_loss_list[episode_index] += reward
        self.total_short_profit_loss_list[episode_index] += reward
        return reward

    def reward_short_step(self, episode_index, current_episode_steps, action):
        self.short_steps_list[episode_index] += 1
        reward = -self.reward_trade_step(episode_index, current_episode_steps, action)
        reward += self.reward_trade_accumulated_steps(episode_index, current_episode_steps, action)
        return reward

    def reward_short_close(self, episode_index, current_episode_steps, action):
        reward = -self.reward_trade_close(episode_index, current_episode_steps, action) # - self.trade_open_cost
        self.total_profit_loss_list[episode_index] += reward
        self.total_short_profit_loss_list[episode_index] += reward
        return 0
        # return reward

    def __init__(self):
        # Settings
        self.invalid_action_punishment_ratio = 0.5  # wrt avg diff sum
        self.trade_step_reward_ratio = 1.0  # wrt avg diff sum
        self.trade_open_cost = 1.0  # wrt avg diff sum
        # self.idle_punishment_ratio = self.trade_open_cost/288 # wrt avg diff sum
        # self.trade_max_accumulated_steps_punishment_ratio = self.idle_punishment_ratio # wrt avg diff sum
        # self.trade_max_accumulated_steps_punishment_increase = 0.05*self.idle_punishment_ratio
        # self.trade_max_accumulated_steps = 288
        # self.trade_win_reward_ratio = 1 # wrt avg diff sum
        # self.trade_lose_punishment_ratio = 1 # wrt avg diff sum
        # self.episode_win_reward_ratio = 10 # wrt avg diff sum
        # self.episode_lose_punishment_ratio = 10 # wrt avg diff sum

        self.position_action_to_reward_function_table = [
              [[self.reward_idle], [self.reward_long_step, self.reward_long_open], [self.reward_short_step, self.reward_short_open], [self.reward_idle, self.reward_invalid_action]],
              [[self.reward_long_step], [self.reward_long_step, self.reward_invalid_action], [self.reward_long_step, self.reward_invalid_action], [self.reward_idle, self.reward_long_close]],
              [[self.reward_short_step], [self.reward_short_step, self.reward_invalid_action], [self.reward_short_step, self.reward_invalid_action], [self.reward_idle, self.reward_short_close]],
              # Episodes end
              [[self.reward_idle], [self.reward_long_step, self.reward_long_open], [self.reward_short_step, self.reward_short_open], [self.reward_idle, self.reward_invalid_action]],
              [[self.reward_idle, self.reward_long_close], [self.reward_idle, self.reward_long_close], [self.reward_idle, self.reward_long_close], [self.reward_idle, self.reward_long_close]],
              [[self.reward_idle, self.reward_short_close], [self.reward_idle, self.reward_short_close], [self.reward_idle, self.reward_short_close], [self.reward_idle, self.reward_short_close]]
          ]

        # Imported values
        self.granularity_list = []
        self.episode_candles_start_index_list = []
        self.primary_granularity = None
        self.episode_steps = None
        self.position_available_acitons = []
        self.position_action_to_position_table = []

        # Runtime values
        self.open_price_list = []
        self.accumulated_trade_steps_list = []
        self.total_profit_loss_list = []
        self.total_long_profit_loss_list = []
        self.total_short_profit_loss_list = []
        self.total_reward_list = []
        self.long_counts_list = []
        self.long_steps_list = []
        self.short_counts_list = []
        self.short_steps_list = []
        self.position_state_list = []
        self.concurrent_episodes = None

        # Pre calculated values
        self.diff_sum_list = []
        self.average_diff_sum_list = []
        # self.idle_punishment = None
        # self.trade_win_reward = None
        # self.trade_lose_punishment = None
        # self.episode_win_reward = None
        # self.episode_lose_punishment = None
        # self.invalid_action_punishment = None

    # def pre_calc_rewards(self):
    #     episode_steps = self.episode_steps
    #     # self.idle_punishment = self.idle_punishment_ratio/episode_steps
    #     # self.trade_win_reward = None
    #     # self.trade_lose_punishment = None
    #     # self.invalid_action_punishment = None

    def reset(self, concurrent_episodes, granularity_list, episode_candles_start_index_list, primary_granularity, episode_steps, position_available_acitons, position_action_to_position_table):

        del self.open_price_list[:]
        del self.total_profit_loss_list[:]
        del self.total_long_profit_loss_list[:]
        del self.total_short_profit_loss_list[:]
        del self.total_reward_list[:]
        del self.position_state_list[:]
        del self.long_counts_list[:]
        del self.long_steps_list[:]
        del self.short_counts_list[:]
        del self.short_steps_list[:]

        del self.diff_sum_list[:]
        del self.average_diff_sum_list[:]

        self.concurrent_episodes = concurrent_episodes

        self.granularity_list = granularity_list
        self.episode_candles_start_index_list = episode_candles_start_index_list
        self.primary_granularity = primary_granularity
        self.episode_steps = episode_steps
        self.position_available_acitons = position_available_acitons
        self.position_action_to_position_table = position_action_to_position_table

        self.open_price_list = [None for i in range(self.concurrent_episodes)]
        self.accumulated_trade_steps_list = [0 for i in range(self.concurrent_episodes)]
        self.total_profit_loss_list = [0 for i in range(self.concurrent_episodes)]
        self.total_long_profit_loss_list = [0 for i in range(self.concurrent_episodes)]
        self.total_short_profit_loss_list = [0 for i in range(self.concurrent_episodes)]
        self.total_reward_list = [0 for i in range(self.concurrent_episodes)]
        self.position_state_list = [0 for i in range(self.concurrent_episodes)]
        self.long_counts_list = [0 for i in range(self.concurrent_episodes)]
        self.long_steps_list = [0 for i in range(self.concurrent_episodes)]
        self.short_counts_list = [0 for i in range(self.concurrent_episodes)]
        self.short_steps_list = [0 for i in range(self.concurrent_episodes)]

        # Calculate diff from episode_candles_start_index_list's primary candles
        self.diff_sum_list = [(candles_list[primary_granularity].loc[start_index:].close).diff().dropna().abs().sum() for candles_list, start_index in episode_candles_start_index_list]
        self.average_diff_sum_list = [diff_sum/self.episode_steps for diff_sum in self.diff_sum_list]
        # print(self.average_diff_sum_list)
        # self.pre_calc_rewards()

    def step(self, current_episode_steps, actions):
        rewards = [None for i in range(self.concurrent_episodes)]
        done = current_episode_steps >= self.episode_steps

        for episode_index, (position_state, action) in enumerate(zip(self.position_state_list, actions)):
            available_actions = self.position_available_acitons[position_state]
            if available_actions[action]:
                self.position_state_list[episode_index] = self.position_action_to_position_table[position_state][action]

            reward = 0
            if done:
                reward_function_list = self.position_action_to_reward_function_table[position_state+3][action]
            else:
                reward_function_list = self.position_action_to_reward_function_table[position_state][action]
            for reward_function in reward_function_list:
                reward += reward_function(episode_index, current_episode_steps, action)
            rewards[episode_index] = reward
            self.total_reward_list[episode_index] += reward
                # action not available

        return rewards

    def get_summary(self):
        total_reward_average = 0
        for reward in self.total_reward_list:
            total_reward_average += reward
        total_reward_average = total_reward_average/len(self.total_reward_list)

        total_profit_loss_average = 0
        for profit_loss in self.total_profit_loss_list:
            total_profit_loss_average += profit_loss
        total_profit_loss_average = total_profit_loss_average/len(self.total_profit_loss_list)

        long_mean_steps_list = []
        for steps, counts in zip(self.long_steps_list, self.long_counts_list):
            if counts>0:
                long_mean_steps_list.append(steps/counts)
            else:
                long_mean_steps_list.append(0)

        short_mean_steps_list = []
        for steps, counts in zip(self.short_steps_list, self.short_counts_list):
            if counts>0:
                short_mean_steps_list.append(steps/counts)
            else:
                short_mean_steps_list.append(0)

        return {
            # 'idle_punishment_baseline': self.idle_punishment_ratio*self.episode_steps,

            'total_reward_average': total_reward_average,
            'total_reward_list': self.total_reward_list,

            'total_profit_loss_average': total_profit_loss_average,
            'total_profit_loss_list': self.total_profit_loss_list,

            'total_long_profit_loss_list': self.total_long_profit_loss_list,
            'long_counts_list': self.long_counts_list,
            'long_steps_list': self.long_steps_list,
            'long_mean_steps_list': long_mean_steps_list,

            'total_short_profit_loss_list': self.total_short_profit_loss_list,
            'short_counts_list': self.short_counts_list,
            'short_steps_list': self.short_steps_list,
            'short_mean_steps_list': short_mean_steps_list,
        }
