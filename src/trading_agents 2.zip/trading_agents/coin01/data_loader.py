#!/usr/bin/python3
import sys
sys.path.append('../..')

import torch, random, math

import coin_wizard.historical_pair_data as hist
from datetime import datetime, timedelta

time_delta_1_days = timedelta(days=7)


granularity_time_delta = {
    "M1": timedelta(seconds=60),
    "M5": timedelta(seconds=60*5),
    "M15": timedelta(seconds=60*15),
    "M30": timedelta(seconds=60*30),
    "H1": timedelta(seconds=60*60),
    "H4": timedelta(seconds=60*240),
    "D": timedelta(seconds=60*60*24),
}


class DataLoader(object):
    def __init__(self, instrument_list, granularity_list=None, primary_granularity=None, input_period_list=None, from_datetime=None, to_datetime=None, episode_steps=None):
        self.instrument_list = []
        instrument_list_ = []
        self.primary_granularity = primary_granularity
        self.input_period_list = input_period_list
        self.granularity_list = granularity_list
        self.hist_data_granularities = [[None for g in granularity_list] for i in range(2*len(instrument_list))]
        self.episode_steps = episode_steps

        timestamp_series_granularities_instrument = [[None for g in granularity_list] for i in range(2*len(instrument_list))]

        # Initialize list of instruments
        for index, instrument in enumerate(instrument_list):
            self.instrument_list.append(instrument)
            self.instrument_list.append(instrument+'_inverted')
            instrument_list_.append((instrument, False))
            instrument_list_.append((instrument, True))

        for instrument_index, instrument_n_invert in enumerate(instrument_list_):
            instrument = instrument_n_invert[0]
            invert = instrument_n_invert[1]

            for granularity_index, granularity in enumerate(granularity_list):
                hist_data = hist.get_historical_pair_data_pandas(instrument, from_datetime, to_datetime, granularity=granularity, invert=invert)
                hist_data = hist_data.dropna().reset_index()
                self.hist_data_granularities[instrument_index][granularity_index] = hist_data
                timestamp_series_granularities_instrument[instrument_index][granularity_index] = hist_data.timestamp

        instrument_list = self.instrument_list

        primary_timestamp_instrument = [timestamp_series_granularities_instrument[i][primary_granularity] for i, _ in enumerate(instrument_list)]

        first_valid_timestamp_granularities_instrument = [[timestamp_series_granularities_instrument[i][granularity].iloc[input_period] for granularity, input_period in enumerate(input_period_list)] for i, _ in enumerate(instrument_list)]
        first_valid_timestamp_instrument = [max(first_valid_timestamp_granularities_instrument[i]) for i, _ in enumerate(instrument_list)]
        self.first_valid_index_instrument = [primary_timestamp_instrument[i][primary_timestamp_instrument[i]>=first_valid_timestamp_instrument[i]].index[0] for i, _ in enumerate(instrument_list)]
        latest_valid_timestamp_instrument = [min([timestamp_series_granularities_instrument[i][index].iloc[-1] for index, g in enumerate(granularity_list)]) for i, _ in enumerate(instrument_list)]
        latest_valid_timestamp_instrument = [min([latest_valid_timestamp_instrument[i], timestamp_series_granularities_instrument[i][primary_granularity].iloc[-episode_steps-1]]) for i, _ in enumerate(instrument_list)]
        self.latest_valid_index_instrument = [primary_timestamp_instrument[i][primary_timestamp_instrument[i]>=latest_valid_timestamp_instrument[i]].index[0] for i, _ in enumerate(instrument_list)]

        # print(self.first_valid_index_instrument)
        # # print(first_valid_timestamp_instrument)
        # print(self.latest_valid_index_instrument)
        # # print(latest_valid_timestamp_instrument)

    def generateEpisode(self):
        instrument_list = self.instrument_list
        primary_granularity = self.primary_granularity
        input_period_list = self.input_period_list
        granularity_list = self.granularity_list
        random_instrument_index = random.randint(0, len(instrument_list)-1)
        hist_data_granularities = self.hist_data_granularities[random_instrument_index]
        episode_steps = self.episode_steps
        first_valid_index = self.first_valid_index_instrument[random_instrument_index]
        latest_valid_index = self.latest_valid_index_instrument[random_instrument_index]

        # print(123)
        # print(self.first_valid_index_instrument)
        # print(self.latest_valid_index_instrument)
        # print(123)
        random_index = random.randint(first_valid_index, latest_valid_index)
        # print(hist_data_granularities[primary_granularity])

        random_index_start_timestamp = (hist_data_granularities[primary_granularity].timestamp)[random_index]
        random_index_end_timestamp = (hist_data_granularities[primary_granularity].timestamp)[random_index+episode_steps]

        # print(random_index_start_timestamp, random_index_end_timestamp)

        result = []
        for index, granularity in enumerate(granularity_list):
            hist_data = hist_data_granularities[index]
            timestamp_series = hist_data.timestamp
            input_period = input_period_list[index]

            granularity_random_start_index = timestamp_series.searchsorted(random_index_start_timestamp-granularity_time_delta[granularity], side='right') - 1
            granularity_random_end_index = timestamp_series.searchsorted(random_index_end_timestamp-granularity_time_delta[granularity], side='right') - 1

            # print(granularity_random_start_index, granularity_random_end_index)
            # print(hist_data.iloc[granularity_random_start_index], hist_data.iloc[granularity_random_end_index])
            result.append(hist_data.iloc[granularity_random_start_index+1-input_period:granularity_random_end_index+1])

        return result, random_index
