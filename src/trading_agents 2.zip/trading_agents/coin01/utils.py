import pytz
import json
from datetime import datetime
from multiprocessing import Manager
from multiprocessing.dummy import Pool as ThreadPool

import matplotlib.pyplot as plt

import torch, jsbeautifier, json

utc = pytz.utc


class TechnicalIndicators(object):
    def __init__(self):
        pass

    # Moving average
    def ma(self, series, period=10):
        return series.rolling(window=period, min_periods=period).mean()

    # Exponential moving average
    def ema(self, series, period=10):
        return series.ewm(span=period, min_periods=period).mean()

    # Moving average convergence divergence
    def macd(self, series, short=12, long=26):
        return series.ewm(span=short).mean() - series.ewm(span=long).mean()

    # Rate of change
    def roc(self, series, period=2):
        return series.diff(period-1)/series.shift(period-1)

    # Momentum
    def momentum(self, series, period=4):
        return series.diff(period)

    # Relative strength index ma
    def rsi_ma(self, series, period=10):
        delta = series.diff()
        # delta = delta[1:]

        up, down = delta.copy(), delta.copy()
        up[up < 0] = 0
        down[down > 0] = 0

        roll_up = up.rolling(period).mean()
        roll_down = down.abs().rolling(period).mean()

        rs = roll_up / roll_down
        return 100.0 - (100.0 / (1.0 + rs))

    # Relative strength index ema
    def rsi_ema(self, series, period=10):
        delta = series.diff()
        # delta = delta[1:]

        up, down = delta.copy(), delta.copy()
        up[up < 0] = 0
        down[down > 0] = 0

        roll_up = up.ewm(span=period).mean()
        roll_down = down.abs().ewm(span=period).mean()

        rs = roll_up / roll_down
        return 100.0 - (100.0 / (1.0 + rs))

    # Bollinger bands
    def bb(self, series, period=20, std_num=2):
        rolling_mean = series.rolling(window=period).mean()
        rolling_std  = series.rolling(window=period).std()
        return rolling_mean + (rolling_std*std_num), rolling_mean - (rolling_std*std_num)

    # Commodity channel index
    def cci(self, high_series, low_series, close_series, period=20):
        pp = (high_series + low_series + close_series) / 3
        return (pp - pp.rolling(period, min_periods=period).mean()) / (0.015 * pp.rolling(period, min_periods=period).std())


def pretty_print(x):
    options = jsbeautifier.default_options()
    options.indent_size = 2
    options.wrap_line_length = 100
    print(jsbeautifier.beautify(json.dumps(x), options))

def plot_list(list):
    x = [i+1 for i in range(len(list))]
    plt.plot(x, list, label='list')
    plt.title(str(123))
    plt.legend()
    plt.show()

class ConfigLoader(object):
    def __init__(self, config_path):
        with open(config_path) as json_file:
            self.config = json.load(json_file)

    def get(self, key):
        return self.config[key]

    def getDate(self, *args):
        args = list(args)
        for i, arg in enumerate(args):
            args[i] = self.config[arg]
        return utc.localize(datetime(*args))

    # def getDictionary(self):
    #     return self.config

class InputDataPreProcessor(object):
    def __init__(self, primary_granularity=0, position_substitution=[0, 1, -1], cuda=False):
        self.primary_granularity = primary_granularity
        self.device = torch.device('cuda:0') if cuda else torch.device('cpu')
        self.position_substitution = position_substitution
        # self.mt_pool = Pool(8)
        self.ti = TechnicalIndicators()

    def _process_candles(self, granularity, candles, recent_positions):
        # rsi_period=14
        cci_period=14

        open = candles.open
        high = candles.high
        low = candles.low
        close = candles.close
        # plot_list(close.tolist())

        close_min = close.min()
        close_max_min = close.max()-close.min()

        open_norm = (open-close_min)/close_max_min
        high_norm = (high-close_min)/close_max_min
        low_norm = (low-close_min)/close_max_min
        close_norm = (close-close_min)/close_max_min
        # plot_list(close_norm.tolist())
        # rsi = self.ti.rsi_ema(close, rsi_period).fillna(50)/50 - 1
        # plot_list(rsi.tolist())
        cci = self.ti.cci(high, low, close, cci_period).fillna(0)/100
        # plot_list(cci.tolist())

        list = [open_norm.tolist(), high_norm.tolist(), low_norm.tolist(), close_norm.tolist(), cci.tolist()]
        if granularity == self.primary_granularity:
            recent_positions = [self.position_substitution[pos] for pos in recent_positions]
            # plot_list(recent_positions)
            list.append(recent_positions)
        return list

    def toTensor(self, candles_list, recent_positions_list):
        num_episodes = len(candles_list)
        num_granularities = len(candles_list[0])

        candles_tensors_list = [] # granularity-wise

        for i in range(num_granularities):
            candles_tensors_list.append(torch.tensor([self._process_candles(i, candles_list[j][i], recent_positions_list[j]) for j in range(num_episodes)], device=self.device).swapaxes(1, 2))

        available_actions_tensor = None

        return candles_tensors_list


class TradingPositionTracker:
    def __init__(self, concurrent_episodes, position_to_available_actions, padding=288, cuda=False):
        self.concurrent_episodes = concurrent_episodes
        self.padding = padding
        self.positions_list = [[0 for j in range(padding)] for i in range(concurrent_episodes)]
        self.position_to_available_actions = position_to_available_actions
        self.device = torch.device('cuda:0') if cuda else torch.device('cpu')

    def reset(self):
        del self.positions_list[:]
        self.positions_list = [[0 for j in range(self.padding)] for i in range(self.concurrent_episodes)]

    def getAvailableActionsTensor(self):
        return torch.tensor([self.position_to_available_actions[self.positions_list[i][-1]] for i in range(self.concurrent_episodes)], device=self.device)

    def getRecentPositions(self, length):
        return [positions[-length:] for positions in self.positions_list]

    def pushPositionList(self, position_list):
        # print(position_list)
        for i, position in enumerate(position_list):
            self.positions_list[i].append(position)

def calculate_gamma(horizon, t_len):
    return 1 - (t_len/horizon)
