#!/usr/bin/python3

import torch, math
import torch.nn as nn
from trading_agents.dc011.informer.model import GranularityInformer

class DcNet(nn.Module):
    def __init__(self, decode_predict_len):
        super(DcNet, self).__init__()
        self.informer = GranularityInformer([6, 6, 6], 6, decode_predict_len, factor=5, e_layers=4, d_layers=2,
                                            dropout=0.1, data_dropout_k=0.5, data_dropout=0.2, structure_dropout=0.1, granularities_dropout=[True, True, True],
                                            d_model=512, d_ff=2048, embed='timeF', freq='t')

    def forward(self, encode_input, encode_time, decode_input, decode_time):
        x = self.informer(encode_input, encode_time, decode_input, decode_time)
        return x

    def fine_tune(self):
        d_model = 512

        for param in self.informer.parameters():
            param.requires_grad = False

        for i, x in enumerate(self.informer.decoder.projection_list):
            self.informer.decoder.projection_list[i] = nn.Linear(d_model, 2, bias=True)
        for i, x in enumerate(self.informer.decoder.norm_layer_list):
            self.informer.decoder.norm_layer_list[i] = nn.LayerNorm(d_model)

        # for param in self.informer.decoder.parameters():
        #     param.requires_grad = True

        return
