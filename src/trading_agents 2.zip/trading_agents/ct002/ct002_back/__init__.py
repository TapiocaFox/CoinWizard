#!/usr/bin/python3

import pytz, torch
from datetime import datetime

import numpy as np
import trading_agents.ct002.nets as nets
import trading_agents.ct002.dataloader as dataloader
import matplotlib.pyplot as plt

from coin_wizard.technical_indicators import TechnicalIndicators

utc = pytz.utc

selected_net = 'backup.net'
# selected_net = 'back.net'

verbose = False
cuda_enabled = True
# cuda_enabled = False
learning_rate = 0.001
epoch_counts = 512*8
batch_counts = 16
batch_size = 512
# batch_counts = 1
# batch_size = 1
# batch_size = 64
training_batches_update_epochs = 32

confidence_threshold = 0.9
macd_threshold = 0.00004
macd_diff_threshold = 0.00001
win_rate_threshold = 0.5
movement_threshold = 0.0015

import coin_wizard.plotter as plotter

ti = TechnicalIndicators()

def calc_confusion_matrix(answers, outputs, labels_length):
    answers = answers.tolist()
    outputs = outputs.tolist()
    array = np.zeros((labels_length, labels_length))
    for i, item in enumerate(answers):
        array[item, outputs[i]] += 1

    # print(array)
    # print(np.sum(array, axis=1))
    array = array / np.sum(array, axis=1)[:, None]
    return array

class TradingAgent(object):
    def __init__(self, agent_directory):
        print(agent_directory)
        self.agent_directory = agent_directory
        self.every_15_second_loop_count = 1
        self.net = None
        self.move_avg_list = [None, None]
        self.position = 2
        self.yeh_n = 0
        self.yeh_m = 30
        self.yeh_steps = 0
        self.total_yeh_steps = 0
        self.buy_cd = 0
        self.sell_cd = 0
        self.current_trade = None
        self.best_profit = 0
        self.dragged_long_conf = 0
        self.dragged_short_conf = 0
        self.max_macd_diff_abs = 0
        self.consider_to_close_trade = False

        self.buy_pl = 0
        self.buy_counts = 0
        self.sell_pl = 0
        self.sell_counts = 0

        self.confidence = 0.99

    def _order_canceled_listener(self, order, reason):
        self.position = 2
        self.yeh_steps = 0

    def _order_filled_listener(self, order, trade):
        self.current_trade = trade
        trade.onReduced(self._trade_reduced_listener)
        trade.onClosed(self._trade_closed_listener)

    def _trade_reduced_listener(self, trade, units, realized_pl, close_price, spread, timestamp):
        pass

    def _trade_closed_listener(self, trade, realized_pl, close_price, spread, timestamp):
        # print(self.yeh_steps, self.best_profit)
        print('Trade closed after %d yeh steps. Best profit: %.5f. PL:  %.5f. Max abs macd diff:  %.5f.' % (
            self.total_yeh_steps, self.best_profit, realized_pl, self.max_macd_diff_abs))
        self.position = 2
        self.yeh_steps = 0
        self.max_macd_diff_abs = 0
        self.total_yeh_steps = 0
        self.consider_to_close_trade = False
        if trade.getTradeSettings()['units'] > 0:
            self.buy_pl += realized_pl
            if realized_pl < 0:
                self.confidence -= 0.95*(self.confidence)
                self.confidence = max(self.confidence, confidence_threshold*1.05)
                self.buy_cd = 0
                # self.buy_cd = 30
                self.sell_cd = 0
            else:
                self.confidence += 0.1*(1 - self.confidence)
        else:
            self.sell_pl += realized_pl
            if realized_pl < 0:
                self.confidence -= 0.95*(self.confidence)
                self.confidence = max(self.confidence, confidence_threshold*1.05)
                self.sell_cd = 0
                # self.sell_cd = 30
                self.buy_cd = 0
            else:
                self.confidence += 0.1*(1 - self.confidence)

    def _every_15_second_loop(self, BrokerAPI):
        if not self.eurusd_inst.isTradable():
            return
        # raise
        if self.every_15_second_loop_count % 4 == 0:
            if self.buy_cd > 0:
                self.buy_cd -= 1
            if self.sell_cd > 0:
                self.sell_cd -= 1

            in_len = 60*24

            eurusd_hist_data = self.eurusd_inst.getRecent1MCandles(in_len+250)

            usdjpy_hist_data = self.usdjpy_inst.getRecent1MCandles(in_len+250)
            usdjpy_hist_data['close_usdjpy'] = usdjpy_hist_data['close']
            del usdjpy_hist_data['close']
            del usdjpy_hist_data['open']
            del usdjpy_hist_data['high']
            del usdjpy_hist_data['low']

            eurjpy_hist_data = self.eurjpy_inst.getRecent1MCandles(in_len+250)
            eurjpy_hist_data['close_eurjpy'] = eurjpy_hist_data['close']
            del eurjpy_hist_data['close']
            del eurjpy_hist_data['open']
            del eurjpy_hist_data['high']
            del eurjpy_hist_data['low']

            eurusd_hist_data['ma'] = ti.ma(eurusd_hist_data.close, 10)
            eurusd_hist_data['macd'] = ti.macd(eurusd_hist_data.close, 12, 26)
            eurusd_hist_data['macd_diff'] = eurusd_hist_data['macd'] - eurusd_hist_data['macd'].ewm(span=9).mean()
            eurusd_hist_data['roc'] = ti.roc(eurusd_hist_data.close, 2)
            eurusd_hist_data['momentum'] = ti.momentum(eurusd_hist_data.close, 4)
            eurusd_hist_data['rsi'] = ti.rsi_ema(eurusd_hist_data.close, 10)
            eurusd_hist_data['bb_upper'], eurusd_hist_data['bb_lower'] = ti.bb(eurusd_hist_data.close, 20, 2)
            eurusd_hist_data['cci'] = ti.cci(eurusd_hist_data.high, eurusd_hist_data.low, eurusd_hist_data.close, 20)
            del eurusd_hist_data['open']
            del eurusd_hist_data['high']
            del eurusd_hist_data['low']

            self.first_valid_idex = 26

            hist_data = eurusd_hist_data.merge(usdjpy_hist_data, left_on='timestamp', right_on='timestamp')
            hist_data = hist_data.merge(eurjpy_hist_data, left_on='timestamp', right_on='timestamp')
            macd = eurusd_hist_data['macd']
            input = np.array([
                hist_data.close.to_list(),
                hist_data.ma.to_list(),
                hist_data.macd.to_list(),
                hist_data.roc.to_list(),
                hist_data.momentum.to_list(),
                hist_data.rsi.to_list(),
                hist_data.bb_upper.to_list(),
                hist_data.bb_lower.to_list(),
                hist_data.cci.to_list(),
                hist_data.close_usdjpy.to_list(),
                hist_data.close_eurjpy.to_list()

            ], dtype=np.float32)

            input = np.swapaxes(input, 0, 1)
            # input = input[-721:, :]
            input = input[-(in_len+1):, :]
            # print(input.shape)
            input = torch.tensor([input], dtype=torch.float32)
            input = torch.swapaxes(input, 0, 1)
            bid, ask, timestamp = self.eurusd_inst.getCurrentCloseoutBidAsk()

            if cuda_enabled:
                input = input.cuda()

            outputs = self.net(input)
            output = outputs[-1, 0]
            long_confidence = output[0].item()
            short_confidence = output[1].item()

            last_1_macd_diff = eurusd_hist_data['macd_diff'][eurusd_hist_data.index[-1]]
            last_2_macd_diff = eurusd_hist_data['macd_diff'][eurusd_hist_data.index[-2]]
            current_macd = macd[macd.index[-1]]
            # long_confidence = output[1].item()
            # short_confidence = output[0].item()

            self.dragged_long_conf = 0.5 * long_confidence + 0.5 * self.dragged_long_conf
            self.dragged_short_conf = 0.5 * short_confidence + 0.5 * self.dragged_short_conf

            # self.dragged_long_conf = long_confidence
            # self.dragged_short_conf = short_confidence

            # units = int(0.8 * self.account.getMarginAvailable() / self.account.getMarginRate())

            units = 1000/0.02

            if self.position == 2:
                if self.dragged_long_conf > confidence_threshold and self.buy_cd <= 0:
                    self.buy_counts += 1
                    print(timestamp, 'BUY with confidence: %.5f' %
                          (long_confidence))
                    self.position = 0
                    # self.best_profit = units*movement_threshold*0.1
                    self.best_profit = 0
                    self.yeh_steps = 0
                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": units, "stop_lost": bid - 0.5 * movement_threshold, "take_profit": bid + movement_threshold})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)
                    if verbose:
                        plotter.plot_candles(
                            'buy future', self.eurusd_inst.foreseeFutureCandles1M(self.yeh_n + 1*self.yeh_m))
                elif self.dragged_short_conf > confidence_threshold and self.sell_cd <= 0:
                    self.sell_counts += 1
                    print(timestamp, 'SELL with confidence: %.5f' %
                          (short_confidence))
                    self.position = 1
                    # self.best_profit = units*movement_threshold*0.1
                    self.best_profit = 0
                    self.yeh_steps = 0
                    order = BrokerAPI.order('EUR_USD', {"type": "market"}, {
                                            "units": -units, "stop_lost": ask + 0.5 * movement_threshold, "take_profit": ask - movement_threshold})
                    order.onCanceled(self._order_canceled_listener)
                    order.onFilled(self._order_filled_listener)
                    if verbose:
                        plotter.plot_candles(
                            'sell future', self.eurusd_inst.foreseeFutureCandles1M(self.yeh_n + 1*self.yeh_m))

            elif self.position == 0:
                self.yeh_steps += 1
                self.total_yeh_steps += 1

                if current_macd > ((self.yeh_m-0.5*(self.yeh_steps-1-self.yeh_n))/self.yeh_m)*macd_threshold and bid - self.current_trade.getOpenPrice() > 0.33 * movement_threshold and last_1_macd_diff > 0 and self.yeh_steps > self.yeh_n:
                    self.consider_to_close_trade = True

                if self.yeh_steps > self.yeh_n + 0.8*self.yeh_m:
                    self.consider_to_close_trade = True

                if self.best_profit < self.current_trade.getUnrealizedPL():
                    self.best_profit = self.current_trade.getUnrealizedPL()

                if self.consider_to_close_trade and current_macd <= 0.9 * macd_threshold:
                    print('00')
                    self.current_trade.close()
                elif self.consider_to_close_trade and last_1_macd_diff < macd_diff_threshold:
                    print('01')
                    self.current_trade.close()
                elif self.yeh_steps >= self.yeh_n + self.yeh_m:
                    print('02')
                    self.current_trade.close()

            elif self.position == 1:
                self.yeh_steps += 1
                self.total_yeh_steps += 1

                if current_macd < -((self.yeh_m-0.5*(self.yeh_steps-1-self.yeh_n))/self.yeh_m)*macd_threshold and self.current_trade.getOpenPrice() - ask > 0.33 * movement_threshold and last_1_macd_diff < 0 and self.yeh_steps > self.yeh_n:
                    self.consider_to_close_trade = True

                if self.yeh_steps > self.yeh_n + 0.8*self.yeh_m:
                    self.consider_to_close_trade = True

                if self.best_profit < self.current_trade.getUnrealizedPL():
                    self.best_profit = self.current_trade.getUnrealizedPL()

                if self.consider_to_close_trade and current_macd >= -0.9 * macd_threshold:
                    print('10')
                    self.current_trade.close()
                elif self.consider_to_close_trade and last_1_macd_diff > -macd_diff_threshold:
                    print('11')
                    self.current_trade.close()
                elif self.yeh_steps >= self.yeh_n + self.yeh_m:
                    print('12')
                    self.current_trade.close()
            if verbose:
                print(timestamp, ' b: %.6f, a: %.6f ' % (bid, ask),
                      ' l: %.5f, s: %.5f, h: %.5f' % tuple(output.tolist()))
            # print(outputs)
            # output = outputs[0]
            # mv_avg_sum = outputs[0].clone()
            # for i in range(len(self.move_avg_list)-1):
            #     self.move_avg_list[i] = self.move_avg_list[i+1]
            #     if self.move_avg_list[i]!= None:
            #         mv_avg_sum += self.move_avg_list[i]
            # self.move_avg_list[-1] = output
            # # print(mv_avg_sum)
            #
            # mv_avg = mv_avg_sum / len(self.move_avg_list)
            # print(mv_avg)
            # print(self.move_avg_list)
            # plotter.plot_candles('recent_candles', recent_candles_df)
        self.every_15_second_loop_count += 1

    def run(self, BrokerAPI):
        net = nets.CtNet(11, 160, 3)
        net.load_state_dict(torch.load(
            self.agent_directory + '/' + selected_net))
        net.eval()

        if cuda_enabled:
            print(net.cuda())

        self.net = net
        BrokerAPI.onEvery15Second(self._every_15_second_loop)
        self.eurusd_inst = BrokerAPI.getInstrument('EUR_USD')
        self.usdjpy_inst = BrokerAPI.getInstrument('USD_JPY')
        self.eurjpy_inst = BrokerAPI.getInstrument('EUR_JPY')
        self.account = BrokerAPI.getAccount()

        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2020, 12, 1, 0, 0)), utc.localize(datetime(2021, 4, 8, 23, 59)))

        test_batches = test_dl.generateBatches(1, batch_size, cuda=cuda_enabled)
        test_batch = test_batches[0]
        test_inputs, test_labels = test_batch

        outputs = net(test_inputs)
        output_max_value, output_max_indices = torch.max(outputs[-1, :, :], 1)
        answer_max_value, answer_max_indices = torch.max(test_labels[-1, :, :], 1)
        t_trend = torch.eq(answer_max_indices, output_max_indices)

        print(outputs.shape, test_labels.shape)
        print(outputs, test_labels)

        # t_trend = torch.eq(test_labels, output_max_indices)
        # print(output_max_value)
        # print(outputs[-1, :, :])
        counts = torch.sum(t_trend.int()).item()
        print(' accuracy:', counts / batch_size)
        print(' avg conf:', torch.sum(output_max_value) / batch_size)
        m = calc_confusion_matrix(answer_max_indices, output_max_indices, 3)
        a = m / np.sum(m, axis=0)[None, :]

        print(m)
        # plt.matshow(m)
        # plt.colorbar()
        # plt.show()

        print(a)

        buy_win_rate = a[0, 0] / (a[0, 0] + a[1, 0])
        sell_win_rate = a[1, 1] / (a[0, 1] + a[1, 1])
        self.buy_win_rate = buy_win_rate
        self.sell_win_rate = sell_win_rate
        print('Win rate: buy(%.5f), sell(%.5f)' %
              (buy_win_rate, sell_win_rate))

        if verbose or True:
            plt.matshow(a, vmin=0, vmax=1)
            plt.colorbar()
            plt.show()



        # if buy_win_rate < win_rate_threshold or sell_win_rate < win_rate_threshold:
        #     print('Bad model imported, abort.')
        #     raise

    def stop_running(self, BrokerAPI):
        print('Win rate: buy(%.5f), sell(%.5f)' %
              (self.buy_win_rate, self.sell_win_rate))
        print('Buy Pl: %.5f, Counts: %d, Avg: %.5f.\nSell Pl: %.5f, Counts: %d, Avg: %.5f.' % (
            self.buy_pl, self.buy_counts, self.buy_pl/self.buy_counts, self.sell_pl, self.sell_counts, self.sell_pl/self.sell_counts))

    def train(self, BrokerAPI):
        # dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2002, 1, 1, 0, 0)), utc.localize(datetime(2020, 11, 29, 23, 59)))
        net = nets.CtNet(11, 160, 3)
        # net.load_state_dict(torch.load(
        #     self.agent_directory + '/' + selected_net))
        # net.eval()
        # net.train()
        if cuda_enabled:
            print(net.cuda())

        dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2007, 1, 1, 0, 0)), utc.localize(datetime(2020, 11, 29, 23, 59)))
        test_dl = dataloader.EurUsdDataLoader(utc.localize(datetime(2020, 12, 1, 0, 0)), utc.localize(datetime(2021, 4, 8, 23, 59)))
        # print(dl.generateBatches(2, 2))

        criterion = torch.nn.MSELoss()
        optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate)

        training_batches = dl.generateBatches(batch_counts, batch_size, cuda=cuda_enabled)
        test_batches = test_dl.generateBatches(1, batch_size, cuda=cuda_enabled)
        test_inputs, test_labels = test_batches[0]

        for epoch in range(epoch_counts):
            if (epoch - 1) % training_batches_update_epochs == training_batches_update_epochs-1 and epoch != 0:
                torch.save(net.state_dict(), self.agent_directory +
                           datetime.now().strftime("/backup.net"))

                del training_batches
                training_batches = dl.generateBatches(batch_counts, batch_size, cuda=cuda_enabled)
                print('Training batches updated.')

            for inputs, labels in training_batches:
                outputs = net(inputs)
                optimizer.zero_grad()

                # obtain the loss function
                loss = criterion(outputs, labels)
                loss.backward()

                optimizer.step()

            # print(outputs.shape, labels.shape)

            test_outputs = net(test_inputs)
            test_loss = criterion(test_outputs, test_labels)

            answer_max_value, answer_max_indices = torch.max(labels[-1, :, :], 1)
            output_max_value, output_max_indices = torch.max(outputs[-1, :, :], 1)
            trend = torch.eq(answer_max_indices, output_max_indices)
            trend_int = trend.int()
            trend_counts = torch.sum(trend_int).item()


            answer_max_value, answer_max_indices = torch.max(test_labels[-1, :, :], 1)
            output_max_value, output_max_indices = torch.max(test_outputs[-1, :, :], 1)
            t_trend = torch.eq(answer_max_indices, output_max_indices)
            t_trend_int = t_trend.int()
            t_trend_counts = torch.sum(t_trend_int).item()
            # print(test_labels)
            # print(answer_max_indices)
            # print(answer_max_value)

            m = calc_confusion_matrix(answer_max_indices, output_max_indices, 3)
            m = m / np.sum(m, axis=0)[None, :]
            print(m)
            # plt.matshow(m, vmin=0, vmax=1)
            # plt.colorbar()
            # plt.show()
            # if epoch % 10 == 0:
            print("Epoch: %d, loss: %1.8f, accuracy: %1.5f, test loss: %1.8f,  accuracy: %1.5f" % (epoch, loss.item(), trend_counts/batch_size, test_loss.item(), t_trend_counts/batch_size))
            # print(torch.swapaxes(outputs, 0, 1)[0])
            # print(torch.swapaxes(labels, 0, 1)[0])
            # print(labels)

        outputs = net(test_inputs)

        answer_max_value, answer_max_indices = torch.max(test_labels[-1, :, :], 1)
        output_max_value, output_max_indices = torch.max(outputs[-1, :, :], 1)

        m = calc_confusion_matrix(answer_max_indices, output_max_indices, 3)
        print(m)
        plt.matshow(m, vmin=0, vmax=1)
        plt.colorbar()
        plt.show()

        print(self.agent_directory + datetime.now().strftime("/CT_%Y_%m_%d_%H_%M.net"))
        torch.save(net.state_dict(), self.agent_directory + datetime.now().strftime("/CT_%Y_%m_%d_%H_%M.net"))

    def stop_training(self, BrokerAPI):
        pass

    def test(self, BacktestBrokerAPI):
        self.run(BacktestBrokerAPI)

    def stop_testing(self, BacktestBrokerAPI):
        self.stop_running(BacktestBrokerAPI)
